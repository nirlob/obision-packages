#!/usr/bin/env gjs

imports.gi.versions.Gtk = '4.0';
imports.gi.versions.Adw = '1';

const { Gio } = imports.gi;
const { Gtk } = imports.gi;
const { Gdk } = imports.gi;
const { Adw } = imports.gi;
const { GLib } = imports.gi;
const { Pango } = imports.gi;

class SettingsService {
    constructor() {
        this.settings = new Gio.Settings({
            schema_id: 'com.obision.app.system',
        });
    }
    static get instance() {
        if (!SettingsService._instance) {
            SettingsService._instance = new SettingsService();
        }
        return SettingsService._instance;
    }
    // Window state
    getWindowWidth() {
        return this.settings.get_int('window-width');
    }
    setWindowWidth(width) {
        this.settings.set_int('window-width', width);
    }
    getWindowHeight() {
        return this.settings.get_int('window-height');
    }
    setWindowHeight(height) {
        this.settings.set_int('window-height', height);
    }
    getWindowX() {
        return this.settings.get_int('window-x');
    }
    setWindowX(x) {
        this.settings.set_int('window-x', x);
    }
    getWindowY() {
        return this.settings.get_int('window-y');
    }
    setWindowY(y) {
        this.settings.set_int('window-y', y);
    }
    getWindowMaximized() {
        return this.settings.get_boolean('window-maximized');
    }
    setWindowMaximized(maximized) {
        this.settings.set_boolean('window-maximized', maximized);
    }
    // Refresh interval
    getRefreshInterval() {
        return this.settings.get_int('refresh-interval');
    }
    setRefreshInterval(interval) {
        this.settings.set_int('refresh-interval', interval);
    }
    // Last selected menu
    getLastSelectedMenu() {
        return this.settings.get_int('last-selected-menu');
    }
    setLastSelectedMenu(index) {
        this.settings.set_int('last-selected-menu', index);
    }
    // Connect to changes
    connectRefreshIntervalChanged(callback) {
        return this.settings.connect('changed::refresh-interval', () => {
            callback(this.getRefreshInterval());
        });
    }
    disconnect(handlerId) {
        this.settings.disconnect(handlerId);
    }
}
 SettingsService;
class UtilsService {
    static get instance() {
        if (!UtilsService._instance) {
            UtilsService._instance = new UtilsService();
        }
        return UtilsService._instance;
    }
    executeCommand(command, args = []) {
        try {
            const process = new Gio.Subprocess({
                argv: [command, ...args],
                flags: Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_PIPE,
            });
            process.init(null);
            const [ok, stdout, stderr] = process.communicate_utf8(null, null);
            if (ok) {
                return [stdout, stderr];
            }
            else {
                throw new Error('Failed to execute command');
            }
        }
        catch (error) {
            throw error;
        }
    }
    formatBytes(bytes) {
        if (bytes === 0)
            return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return `${(bytes / Math.pow(k, i)).toFixed(2)} ${sizes[i]}`;
    }
    capitalizeWords(str) {
        return str.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(' ');
    }
    /**
     * Authenticate as root using pkexec.
     * @returns true if authentication succeeded, false if cancelled or failed
     */
    authenticateAsRoot() {
        try {
            const [stdout, stderr] = this.executeCommand('pkexec', ['true']);
            // Check if authentication was cancelled or dismissed
            if (stderr && (stderr.includes('dismissed') || stderr.includes('Error executing command'))) {
                return false;
            }
            // If no errors, authentication succeeded
            return true;
        }
        catch (error) {
            return false;
        }
    }
}
 UtilsService;
class ResumeService {
    constructor() {
        this.updateTimeoutId = null;
        this.dataCallbacks = [];
        this.previousNetworkStats = null;
        this.utils = UtilsService.instance;
        this.settings = SettingsService.instance;
    }
    static get instance() {
        if (!ResumeService._instance) {
            ResumeService._instance = new ResumeService();
        }
        return ResumeService._instance;
    }
    subscribeToUpdates(callback) {
        this.dataCallbacks.push(callback);
        // If this is the first subscriber, start the update loop
        if (this.dataCallbacks.length === 1) {
            this.startUpdateLoop();
        }
        // Immediately provide initial data
        this.updateData();
    }
    unsubscribe(callback) {
        const index = this.dataCallbacks.indexOf(callback);
        if (index > -1) {
            this.dataCallbacks.splice(index, 1);
        }
        // If no more subscribers, stop the update loop
        if (this.dataCallbacks.length === 0) {
            this.stopUpdateLoop();
        }
    }
    startUpdateLoop() {
        if (this.updateTimeoutId !== null) {
            return;
        }
        const refreshInterval = this.settings.getRefreshInterval();
        this.updateTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, refreshInterval * 1000, () => {
            this.updateData();
            return GLib.SOURCE_CONTINUE;
        });
        // Listen for refresh interval changes
        this.settings.connectRefreshIntervalChanged((newInterval) => {
            if (this.updateTimeoutId !== null) {
                GLib.source_remove(this.updateTimeoutId);
                this.updateTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, newInterval * 1000, () => {
                    this.updateData();
                    return GLib.SOURCE_CONTINUE;
                });
            }
        });
    }
    stopUpdateLoop() {
        if (this.updateTimeoutId !== null) {
            GLib.source_remove(this.updateTimeoutId);
            this.updateTimeoutId = null;
        }
    }
    updateData() {
        const data = {
            cpu: this.updateCpuUsage(),
            gpu: this.updateGpuUsage(),
            memory: this.updateMemoryUsage(),
            disk: this.updateDiskUsage(),
            network: this.updateNetworkUsage(),
            cpuTemp: this.updateCpuTemperature(),
            gpuTemp: this.updateGpuTemperature(),
            systemLoad: this.updateSystemLoad(),
            topProcesses: this.updateTopProcesses(),
            systemInfo: this.updateSystemInfo(),
        };
        // Notify all subscribers
        this.dataCallbacks.forEach(callback => callback(data));
    }
    updateCpuUsage() {
        try {
            const [stdout] = this.utils.executeCommand('cat', ['/proc/stat']);
            const lines = stdout.split('\n');
            const cpuLine = lines[0];
            const values = cpuLine.split(/\s+/).slice(1).map(Number);
            const idle = values[3];
            const total = values.reduce((a, b) => a + b, 0);
            const usage = total > 0 ? ((total - idle) / total) * 100 : 0;
            // Get CPU model and cores
            const [cpuInfo] = this.utils.executeCommand('lscpu');
            const modelMatch = cpuInfo.match(/Model name:\s*(.+)/);
            const coresMatch = cpuInfo.match(/CPU\(s\):\s*(\d+)/);
            return {
                usage: Math.round(usage),
                model: modelMatch ? modelMatch[1].trim() : 'Unknown',
                cores: coresMatch ? parseInt(coresMatch[1]) : 0,
            };
        }
        catch (error) {
            console.error('Error reading CPU usage:', error);
            return { usage: 0, model: 'Unknown', cores: 0 };
        }
    }
    updateGpuUsage() {
        try {
            const [stdout] = this.utils.executeCommand('nvidia-smi', [
                '--query-gpu=utilization.gpu,name',
                '--format=csv,noheader,nounits'
            ]);
            const [usage, name] = stdout.trim().split(',');
            return {
                usage: parseInt(usage.trim()) || 0,
                name: name ? name.trim() : 'Unknown GPU',
            };
        }
        catch (error) {
            return { usage: 0, name: 'N/A' };
        }
    }
    updateMemoryUsage() {
        try {
            const [stdout] = this.utils.executeCommand('free', ['-b']);
            const lines = stdout.split('\n');
            const memLine = lines[1].split(/\s+/);
            const total = parseInt(memLine[1]);
            const used = parseInt(memLine[2]);
            const percentage = total > 0 ? (used / total) * 100 : 0;
            return {
                used,
                total,
                percentage: Math.round(percentage),
            };
        }
        catch (error) {
            console.error('Error reading memory usage:', error);
            return { used: 0, total: 0, percentage: 0 };
        }
    }
    updateDiskUsage() {
        try {
            const [stdout] = this.utils.executeCommand('df', ['-B1', '/']);
            const lines = stdout.split('\n');
            const diskLine = lines[1].split(/\s+/);
            const total = parseInt(diskLine[1]);
            const used = parseInt(diskLine[2]);
            const percentage = total > 0 ? (used / total) * 100 : 0;
            return {
                used,
                total,
                percentage: Math.round(percentage),
            };
        }
        catch (error) {
            console.error('Error reading disk usage:', error);
            return { used: 0, total: 0, percentage: 0 };
        }
    }
    updateNetworkUsage() {
        try {
            const [stdout] = this.utils.executeCommand('cat', ['/proc/net/dev']);
            const lines = stdout.split('\n');
            let totalDownload = 0;
            let totalUpload = 0;
            for (const line of lines) {
                if (line.includes(':') && !line.includes('lo:')) {
                    const parts = line.split(/\s+/);
                    totalDownload += parseInt(parts[1]) || 0;
                    totalUpload += parseInt(parts[9]) || 0;
                }
            }
            const currentTime = Date.now();
            let downloadSpeed = '0 B/s';
            let uploadSpeed = '0 B/s';
            if (this.previousNetworkStats) {
                const timeDiff = (currentTime - this.previousNetworkStats.timestamp) / 1000;
                const downloadDiff = totalDownload - this.previousNetworkStats.download;
                const uploadDiff = totalUpload - this.previousNetworkStats.upload;
                if (timeDiff > 0) {
                    downloadSpeed = this.utils.formatBytes(downloadDiff / timeDiff) + '/s';
                    uploadSpeed = this.utils.formatBytes(uploadDiff / timeDiff) + '/s';
                }
            }
            this.previousNetworkStats = {
                download: totalDownload,
                upload: totalUpload,
                timestamp: currentTime,
            };
            return {
                download: downloadSpeed,
                upload: uploadSpeed,
            };
        }
        catch (error) {
            console.error('Error reading network usage:', error);
            return { download: '0 B/s', upload: '0 B/s' };
        }
    }
    updateCpuTemperature() {
        try {
            // Try thermal_zone0 first
            try {
                const [stdout] = this.utils.executeCommand('cat', ['/sys/class/thermal/thermal_zone0/temp']);
                const temp = parseInt(stdout.trim()) / 1000;
                if (!isNaN(temp)) {
                    return Math.round(temp);
                }
            }
            catch (e) {
                // Try other thermal zones
                for (let i = 1; i <= 5; i++) {
                    try {
                        const [stdout] = this.utils.executeCommand('cat', [`/sys/class/thermal/thermal_zone${i}/temp`]);
                        const temp = parseInt(stdout.trim()) / 1000;
                        if (!isNaN(temp)) {
                            return Math.round(temp);
                        }
                    }
                    catch (e) {
                        continue;
                    }
                }
            }
            return -1; // Not available
        }
        catch (error) {
            return -1;
        }
    }
    updateGpuTemperature() {
        try {
            const [stdout] = this.utils.executeCommand('nvidia-smi', [
                '--query-gpu=temperature.gpu',
                '--format=csv,noheader,nounits'
            ]);
            const temp = parseInt(stdout.trim());
            return (!isNaN(temp) && temp > 0) ? temp : -1;
        }
        catch (error) {
            return -1;
        }
    }
    updateSystemLoad() {
        try {
            const [stdout] = this.utils.executeCommand('cat', ['/proc/loadavg']);
            const loads = stdout.split(' ');
            return {
                load1: parseFloat(loads[0]) || 0,
                load5: parseFloat(loads[1]) || 0,
                load15: parseFloat(loads[2]) || 0,
            };
        }
        catch (error) {
            console.error('Error reading system load:', error);
            return { load1: 0, load5: 0, load15: 0 };
        }
    }
    updateTopProcesses() {
        try {
            const [stdout] = this.utils.executeCommand('ps', [
                'aux',
                '--sort=-%cpu',
                '--no-headers'
            ]);
            const lines = stdout.split('\n');
            // Filter out 'ps' process and get top 5
            const processes = lines
                .map(line => {
                const parts = line.split(/\s+/);
                return {
                    name: parts[10] || 'Unknown',
                    cpu: parseFloat(parts[2]) || 0,
                    memory: parseFloat(parts[3]) || 0,
                };
            })
                .filter(proc => proc.name !== 'Unknown' && proc.name !== 'ps')
                .slice(0, 5);
            return processes;
        }
        catch (error) {
            console.error('Error reading top processes:', error);
            return [];
        }
    }
    updateSystemInfo() {
        try {
            const [osInfo] = this.utils.executeCommand('cat', ['/etc/os-release']);
            const osMatch = osInfo.match(/PRETTY_NAME="(.+)"/);
            const [kernelInfo] = this.utils.executeCommand('uname', ['-r']);
            const [uptimeInfo] = this.utils.executeCommand('uptime', ['-p']);
            return {
                os: osMatch ? osMatch[1] : 'Unknown',
                kernel: kernelInfo.trim(),
                uptime: uptimeInfo.trim(),
            };
        }
        catch (error) {
            console.error('Error reading system info:', error);
            return { os: 'Unknown', kernel: 'Unknown', uptime: 'Unknown' };
        }
    }
}
 ResumeService;
class NetworkService {
    constructor() {
        this.updateTimeoutId = null;
        this.dataCallbacks = [];
        this.previousStats = new Map();
        this.utils = UtilsService.instance;
    }
    static get instance() {
        if (!NetworkService._instance) {
            NetworkService._instance = new NetworkService();
        }
        return NetworkService._instance;
    }
    subscribeToUpdates(callback) {
        this.dataCallbacks.push(callback);
        if (this.dataCallbacks.length === 1) {
            this.startUpdateLoop();
        }
        this.updateData();
    }
    unsubscribe(callback) {
        const index = this.dataCallbacks.indexOf(callback);
        if (index > -1) {
            this.dataCallbacks.splice(index, 1);
        }
        if (this.dataCallbacks.length === 0) {
            this.stopUpdateLoop();
        }
    }
    startUpdateLoop() {
        if (this.updateTimeoutId !== null) {
            return;
        }
        this.updateTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2000, () => {
            this.updateData();
            return GLib.SOURCE_CONTINUE;
        });
    }
    stopUpdateLoop() {
        if (this.updateTimeoutId !== null) {
            GLib.source_remove(this.updateTimeoutId);
            this.updateTimeoutId = null;
        }
    }
    updateData() {
        const data = {
            interfaces: this.getNetworkInterfaces(),
        };
        this.dataCallbacks.forEach(callback => callback(data));
    }
    getNetworkInterfaces() {
        const interfaces = [];
        try {
            const [stdout] = this.utils.executeCommand('ip', ['-j', 'addr']);
            const ipData = JSON.parse(stdout);
            for (const iface of ipData) {
                if (iface.ifname === 'lo')
                    continue;
                let ipv4 = '';
                let ipv6 = '';
                if (iface.addr_info) {
                    for (const addr of iface.addr_info) {
                        if (addr.family === 'inet') {
                            ipv4 = `${addr.local}/${addr.prefixlen}`;
                        }
                        else if (addr.family === 'inet6' && addr.scope === 'global') {
                            ipv6 = `${addr.local}/${addr.prefixlen}`;
                        }
                    }
                }
                const stats = this.getInterfaceStats(iface.ifname);
                interfaces.push({
                    name: iface.ifname,
                    type: this.getInterfaceType(iface.ifname),
                    state: iface.operstate || 'unknown',
                    ipv4: ipv4 || 'Not assigned',
                    ipv6: ipv6 || 'Not assigned',
                    mac: iface.address || '',
                    rxBytes: stats.rx,
                    txBytes: stats.tx,
                    rxSpeed: stats.rxSpeed,
                    txSpeed: stats.txSpeed,
                });
            }
        }
        catch (error) {
            console.error('Error reading network interfaces:', error);
        }
        return interfaces;
    }
    getInterfaceType(ifname) {
        if (ifname.startsWith('wl'))
            return 'Wi-Fi';
        if (ifname.startsWith('en') || ifname.startsWith('eth'))
            return 'Ethernet';
        if (ifname.startsWith('ww'))
            return 'Mobile';
        if (ifname.startsWith('docker') || ifname.startsWith('br'))
            return 'Bridge';
        if (ifname.startsWith('veth'))
            return 'Virtual';
        return 'Unknown';
    }
    getInterfaceStats(ifname) {
        try {
            const [rxBytes] = this.utils.executeCommand('cat', [`/sys/class/net/${ifname}/statistics/rx_bytes`]);
            const [txBytes] = this.utils.executeCommand('cat', [`/sys/class/net/${ifname}/statistics/tx_bytes`]);
            const rx = parseInt(rxBytes.trim()) || 0;
            const tx = parseInt(txBytes.trim()) || 0;
            const currentTime = Date.now();
            let rxSpeed = '0 B/s';
            let txSpeed = '0 B/s';
            const previousStat = this.previousStats.get(ifname);
            if (previousStat) {
                const timeDiff = (currentTime - previousStat.timestamp) / 1000;
                const rxDiff = rx - previousStat.rx;
                const txDiff = tx - previousStat.tx;
                if (timeDiff > 0) {
                    rxSpeed = this.utils.formatBytes(rxDiff / timeDiff) + '/s';
                    txSpeed = this.utils.formatBytes(txDiff / timeDiff) + '/s';
                }
            }
            this.previousStats.set(ifname, { rx, tx, timestamp: currentTime });
            return { rx, tx, rxSpeed, txSpeed };
        }
        catch (error) {
            return { rx: 0, tx: 0, rxSpeed: '0 B/s', txSpeed: '0 B/s' };
        }
    }
}
 NetworkService;
class ProcessesService {
    constructor() {
        this.updateTimeoutId = null;
        this.dataCallbacks = [];
        this.currentSortColumn = 'cpu';
        this.currentSortAscending = false;
        this.currentSearchQuery = '';
        this.utils = UtilsService.instance;
    }
    static get instance() {
        if (!ProcessesService._instance) {
            ProcessesService._instance = new ProcessesService();
        }
        return ProcessesService._instance;
    }
    subscribeToUpdates(callback) {
        this.dataCallbacks.push(callback);
        if (this.dataCallbacks.length === 1) {
            this.startUpdateLoop();
        }
        this.updateData();
    }
    unsubscribe(callback) {
        const index = this.dataCallbacks.indexOf(callback);
        if (index > -1) {
            this.dataCallbacks.splice(index, 1);
        }
        if (this.dataCallbacks.length === 0) {
            this.stopUpdateLoop();
        }
    }
    setSortColumn(column, ascending) {
        this.currentSortColumn = column;
        this.currentSortAscending = ascending;
        this.updateData();
    }
    setSearchQuery(query) {
        this.currentSearchQuery = query;
        this.updateData();
    }
    killProcess(pid) {
        try {
            this.utils.executeCommand('kill', ['-9', pid]);
            this.updateData();
            return true;
        }
        catch (error) {
            console.error('Error killing process:', error);
            return false;
        }
    }
    startUpdateLoop() {
        if (this.updateTimeoutId !== null) {
            return;
        }
        this.updateTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 10000, () => {
            this.updateData();
            return GLib.SOURCE_CONTINUE;
        });
    }
    stopUpdateLoop() {
        if (this.updateTimeoutId !== null) {
            GLib.source_remove(this.updateTimeoutId);
            this.updateTimeoutId = null;
        }
    }
    updateData() {
        const processes = this.loadProcesses();
        const data = {
            processes,
            totalCount: processes.length,
        };
        this.dataCallbacks.forEach(callback => callback(data));
    }
    loadProcesses() {
        try {
            const sortMap = {
                'pid': '-p',
                'user': '-U',
                'cpu': '-%cpu',
                'memory': '-%mem',
                'command': '-c',
            };
            const sortOption = sortMap[this.currentSortColumn] || '-%cpu';
            const [stdout] = this.utils.executeCommand('ps', [
                'aux',
                `--sort=${sortOption}`,
                '--no-headers'
            ]);
            const lines = stdout.trim().split('\n');
            let processes = [];
            for (const line of lines) {
                const parts = line.split(/\s+/);
                if (parts.length < 11)
                    continue;
                const processInfo = {
                    user: parts[0],
                    pid: parts[1],
                    cpu: parts[2],
                    memory: parts[3],
                    vsz: parts[4],
                    rss: parts[5],
                    tty: parts[6],
                    stat: parts[7],
                    start: parts[8],
                    time: parts[9],
                    command: parts.slice(10).join(' '),
                };
                if (this.currentSearchQuery) {
                    const query = this.currentSearchQuery.toLowerCase();
                    if (!processInfo.command.toLowerCase().includes(query) &&
                        !processInfo.pid.includes(query) &&
                        !processInfo.user.toLowerCase().includes(query)) {
                        continue;
                    }
                }
                processes.push(processInfo);
            }
            if (this.currentSortAscending) {
                processes.reverse();
            }
            return processes;
        }
        catch (error) {
            console.error('Error loading processes:', error);
            return [];
        }
    }
}
 ProcessesService;
class LogsService {
    constructor() {
        this.updateTimeoutId = null;
        this.dataCallbacks = [];
        this.isAutoRefreshEnabled = false;
        this.systemLogFilter = 0;
        this.systemPriority = 0;
        this.systemLines = 200;
        this.userLogFilter = 0;
        this.userPriority = 0;
        this.userLines = 200;
        this.systemLogsAuthenticated = false;
        this.utils = UtilsService.instance;
    }
    static get instance() {
        if (!LogsService._instance) {
            LogsService._instance = new LogsService();
        }
        return LogsService._instance;
    }
    subscribeToUpdates(callback) {
        this.dataCallbacks.push(callback);
        this.updateData();
    }
    unsubscribe(callback) {
        const index = this.dataCallbacks.indexOf(callback);
        if (index > -1) {
            this.dataCallbacks.splice(index, 1);
        }
        if (this.dataCallbacks.length === 0) {
            this.stopAutoRefresh();
        }
    }
    setSystemLogFilter(filter, priority, lines) {
        this.systemLogFilter = filter;
        this.systemPriority = priority;
        this.systemLines = lines;
        this.updateData();
    }
    setUserLogFilter(filter, priority, lines) {
        this.userLogFilter = filter;
        this.userPriority = priority;
        this.userLines = lines;
        this.updateData();
    }
    toggleAutoRefresh() {
        this.isAutoRefreshEnabled = !this.isAutoRefreshEnabled;
        if (this.isAutoRefreshEnabled) {
            this.startAutoRefresh();
        }
        else {
            this.stopAutoRefresh();
        }
        return this.isAutoRefreshEnabled;
    }
    loadSystemLogsWithSudo() {
        const result = this.loadSystemLogsInternal(true);
        return { success: true, data: result };
    }
    setSystemLogsAuthenticated(authenticated) {
        this.systemLogsAuthenticated = authenticated;
    }
    isSystemLogsAuthenticated() {
        return this.systemLogsAuthenticated;
    }
    requestSystemLogsWithElevation() {
        // Try to load with sudo, but only update if successful
        const result = this.loadSystemLogsInternal(true);
        if (result && !result.includes('cancelled by user') && !result.includes('dismissed')) {
            // Update all callbacks with elevated logs
            const data = {
                systemLogs: result,
                userLogs: this.loadUserLogs(),
            };
            this.dataCallbacks.forEach(callback => callback(data));
        }
        // If cancelled or failed, keep showing the normal logs (already loaded)
    }
    startAutoRefresh() {
        if (this.updateTimeoutId !== null) {
            return;
        }
        this.updateData();
        this.updateTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 10000, () => {
            this.updateData();
            return GLib.SOURCE_CONTINUE;
        });
    }
    stopAutoRefresh() {
        if (this.updateTimeoutId !== null) {
            GLib.source_remove(this.updateTimeoutId);
            this.updateTimeoutId = null;
        }
    }
    requestUpdate() {
        this.updateData();
    }
    updateData() {
        const data = {
            systemLogs: this.systemLogsAuthenticated ? this.loadSystemLogsInternal(true) : '',
            userLogs: this.loadUserLogs(),
        };
        this.dataCallbacks.forEach(callback => callback(data));
    }
    loadSystemLogsInternal(useSudo) {
        try {
            let args = ['--no-pager', '-n', this.systemLines.toString(), '-o', 'short'];
            if (this.systemPriority > 0) {
                const priorities = ['emerg', 'alert', 'crit', 'err', 'warning', 'notice', 'info', 'debug'];
                args.push('-p');
                args.push(priorities[this.systemPriority - 1]);
            }
            switch (this.systemLogFilter) {
                case 0: // All Logs
                    break;
                case 1: // Kernel Logs
                    args.push('-k');
                    break;
                case 2: // Boot Logs
                    args.push('-b');
                    break;
                case 3: // System Services
                    args.push('-u', 'systemd');
                    break;
                case 4: // Authentication
                    args.push('-u', 'systemd-logind');
                    break;
                case 5: // Cron Jobs
                    args.push('-u', 'cron');
                    break;
                case 6: // Network Manager
                    args.push('-u', 'NetworkManager');
                    break;
                case 7: // Bluetooth
                    args.push('-u', 'bluetooth');
                    break;
                case 8: // USB Events
                    args.push('-k');
                    break;
            }
            const command = useSudo ? 'pkexec' : 'journalctl';
            const finalArgs = useSudo ? ['journalctl', ...args] : args;
            const [stdout, stderr] = this.utils.executeCommand(command, finalArgs);
            if (useSudo && stderr && (stderr.includes('dismissed') || stderr.includes('Error executing command'))) {
                return 'AUTH_CANCELLED';
            }
            else if (stderr && stderr.includes('insufficient permissions')) {
                return `System logs require elevated permissions.\n\n` +
                    `To view system logs, you can:\n` +
                    `1. Add your user to the 'systemd-journal' group:\n` +
                    `   sudo usermod -a -G systemd-journal $USER\n` +
                    `   (requires logout/login to take effect)\n\n` +
                    `2. Or run journalctl manually in terminal:\n` +
                    `   journalctl -n 200 --no-pager\n\n` +
                    `Showing accessible logs instead:\n\n${stdout || 'No accessible logs found'}`;
            }
            // Return logs directly without hints
            return stdout && stdout.trim() ? stdout : 'No logs found';
        }
        catch (error) {
            return `Error loading logs: ${error}\n\nNote: journalctl may require additional permissions.`;
        }
    }
    loadUserLogs() {
        try {
            let args = ['--no-pager', '--user', '-n', this.userLines.toString(), '-o', 'short'];
            if (this.userPriority > 0) {
                const priorities = ['emerg', 'alert', 'crit', 'err', 'warning', 'notice', 'info', 'debug'];
                args.push('-p');
                args.push(priorities[this.userPriority - 1]);
            }
            switch (this.userLogFilter) {
                case 0: // All User Logs
                    break;
                case 1: // User Services
                    break;
                case 2: // Desktop Session
                    args.push('_SYSTEMD_USER_UNIT=gnome-session.target');
                    break;
                case 3: // Applications
                    args.push('_COMM=gjs');
                    break;
                case 4: // Shell
                    args.push('_COMM=gnome-shell');
                    break;
            }
            const [stdout, stderr] = this.utils.executeCommand('journalctl', args);
            // Return logs directly without hints
            return stdout && stdout.trim() ? stdout : 'No user logs found';
        }
        catch (error) {
            return `Error loading user logs: ${error}\n\nNote: User logs may not be available or require additional permissions.`;
        }
    }
}
 LogsService;
class DataService {
    constructor() {
        this.utils = UtilsService.instance;
    }
    static get instance() {
        if (!DataService._instance) {
            DataService._instance = new DataService();
        }
        return DataService._instance;
    }
    getCpuInfo() {
        const info = {
            model: 'Unknown',
            cores: 0,
            logicalCores: 0,
            threads: 0,
            architecture: 'Unknown',
            vendor: 'Unknown',
            family: 'Unknown',
            modelId: 'Unknown',
            stepping: 'Unknown',
            l1dCache: 'Unknown',
            l1iCache: 'Unknown',
            l2Cache: 'Unknown',
            l3Cache: 'Unknown',
            virtualization: 'Unknown',
            bogomips: 'Unknown',
            maxFrequency: 'Unknown',
            currentFrequency: 'Unknown',
        };
        try {
            const [lscpuOut] = this.utils.executeCommand('sh', ['-c', 'LC_ALL=C lscpu']);
            const lines = lscpuOut.split('\n');
            for (const line of lines) {
                if (line.includes('Model name:')) {
                    info.model = line.split(':')[1]?.trim() || 'Unknown';
                }
                else if (line.includes('Architecture:')) {
                    info.architecture = line.split(':')[1]?.trim() || 'Unknown';
                }
                else if (line.includes('Vendor ID:')) {
                    info.vendor = line.split(':')[1]?.trim() || 'Unknown';
                }
                else if (line.includes('CPU family:')) {
                    info.family = line.split(':')[1]?.trim() || 'Unknown';
                }
                else if (line.includes('Model:') && !line.includes('Model name:')) {
                    info.modelId = line.split(':')[1]?.trim() || 'Unknown';
                }
                else if (line.includes('Stepping:')) {
                    info.stepping = line.split(':')[1]?.trim() || 'Unknown';
                }
                else if (line.includes('CPU(s):') && !line.includes('NUMA') && !line.includes('On-line')) {
                    info.logicalCores = parseInt(line.split(':')[1]?.trim() || '0');
                }
                else if (line.includes('Core(s) per socket:')) {
                    const coresPerSocket = parseInt(line.split(':')[1]?.trim() || '0');
                    const socketsMatch = lscpuOut.match(/Socket\(s\):\s+(\d+)/);
                    const sockets = socketsMatch ? parseInt(socketsMatch[1]) : 1;
                    info.cores = coresPerSocket * sockets;
                }
                else if (line.includes('Thread(s) per core:')) {
                    info.threads = parseInt(line.split(':')[1]?.trim() || '0');
                }
                else if (line.includes('L1d cache:')) {
                    info.l1dCache = line.split(':')[1]?.trim() || 'Unknown';
                }
                else if (line.includes('L1i cache:')) {
                    info.l1iCache = line.split(':')[1]?.trim() || 'Unknown';
                }
                else if (line.includes('L2 cache:')) {
                    info.l2Cache = line.split(':')[1]?.trim() || 'Unknown';
                }
                else if (line.includes('L3 cache:')) {
                    info.l3Cache = line.split(':')[1]?.trim() || 'Unknown';
                }
                else if (line.includes('Virtualization:')) {
                    info.virtualization = line.split(':')[1]?.trim() || 'Unknown';
                }
                else if (line.includes('BogoMIPS:')) {
                    info.bogomips = line.split(':')[1]?.trim() || 'Unknown';
                }
                else if (line.includes('CPU max MHz:')) {
                    const mhz = parseFloat(line.split(':')[1]?.trim() || '0');
                    info.maxFrequency = `${(mhz / 1000).toFixed(2)} GHz`;
                }
                else if (line.includes('CPU MHz:')) {
                    const mhz = parseFloat(line.split(':')[1]?.trim() || '0');
                    info.currentFrequency = `${(mhz / 1000).toFixed(2)} GHz`;
                }
            }
        }
        catch (error) {
            console.error('Error getting CPU info:', error);
        }
        return info;
    }
    getGpuInfo() {
        const gpus = [];
        // Try NVIDIA first
        try {
            const [whichOut] = this.utils.executeCommand('which', ['nvidia-smi']);
            if (whichOut.trim()) {
                const [smiOut] = this.utils.executeCommand('nvidia-smi', [
                    '--query-gpu=name,driver_version,memory.total,memory.used,temperature.gpu,power.draw,clocks.gr,pci.bus_id',
                    '--format=csv,noheader,nounits'
                ]);
                const lines = smiOut.trim().split('\n');
                for (const line of lines) {
                    if (line.trim()) {
                        const parts = line.split(',').map(p => p.trim());
                        gpus.push({
                            name: parts[0] || 'Unknown',
                            driver: parts[1] || 'Unknown',
                            memoryTotal: `${parts[2]} MB`,
                            memoryUsed: `${parts[3]} MB`,
                            temperature: `${parts[4]}°C`,
                            power: `${parts[5]} W`,
                            clockSpeed: `${parts[6]} MHz`,
                            pciId: parts[7] || 'Unknown',
                            type: 'nvidia',
                            vendor: 'NVIDIA',
                        });
                    }
                }
                if (gpus.length > 0)
                    return gpus;
            }
        }
        catch (error) {
            console.log('NVIDIA GPU not detected or nvidia-smi failed');
        }
        // Try AMD (limited info available without rocm-smi)
        try {
            const [lspciOut] = this.utils.executeCommand('lspci', ['-v']);
            const gpuBlocks = lspciOut.split('\n\n').filter(block => (block.includes('VGA') || block.includes('3D')) &&
                (block.includes('AMD') || block.includes('ATI') || block.includes('Radeon')));
            for (const block of gpuBlocks) {
                const nameMatch = block.match(/VGA compatible controller: (.+)/);
                const driverMatch = block.match(/Kernel driver in use: (.+)/);
                gpus.push({
                    name: nameMatch ? nameMatch[1].trim() : 'AMD GPU',
                    driver: driverMatch ? driverMatch[1].trim() : 'Unknown',
                    memoryTotal: 'N/A',
                    memoryUsed: 'N/A',
                    temperature: 'N/A',
                    power: 'N/A',
                    clockSpeed: 'N/A',
                    pciId: 'N/A',
                    type: 'amd',
                    vendor: 'AMD',
                });
            }
            if (gpus.length > 0)
                return gpus;
        }
        catch (error) {
            console.log('AMD GPU not detected');
        }
        // Try Intel
        try {
            const [lspciOut] = this.utils.executeCommand('lspci', ['-v']);
            const gpuBlocks = lspciOut.split('\n\n').filter(block => (block.includes('VGA') || block.includes('3D')) && block.includes('Intel'));
            for (const block of gpuBlocks) {
                const nameMatch = block.match(/VGA compatible controller: (.+)/);
                const driverMatch = block.match(/Kernel driver in use: (.+)/);
                gpus.push({
                    name: nameMatch ? nameMatch[1].trim() : 'Intel GPU',
                    driver: driverMatch ? driverMatch[1].trim() : 'Unknown',
                    memoryTotal: 'Shared',
                    memoryUsed: 'N/A',
                    temperature: 'N/A',
                    power: 'N/A',
                    clockSpeed: 'N/A',
                    pciId: 'N/A',
                    type: 'intel',
                    vendor: 'Intel',
                });
            }
            if (gpus.length > 0)
                return gpus;
        }
        catch (error) {
            console.log('Intel GPU not detected');
        }
        // Fallback: Generic GPU detection
        try {
            const [lspciOut] = this.utils.executeCommand('lspci', ['-v']);
            const gpuBlocks = lspciOut.split('\n\n').filter(block => block.includes('VGA') || block.includes('3D'));
            for (const block of gpuBlocks) {
                const nameMatch = block.match(/VGA compatible controller: (.+)/);
                const driverMatch = block.match(/Kernel driver in use: (.+)/);
                gpus.push({
                    name: nameMatch ? nameMatch[1].trim() : 'Unknown GPU',
                    driver: driverMatch ? driverMatch[1].trim() : 'Unknown',
                    memoryTotal: 'N/A',
                    memoryUsed: 'N/A',
                    temperature: 'N/A',
                    power: 'N/A',
                    clockSpeed: 'N/A',
                    pciId: 'N/A',
                    type: 'unknown',
                    vendor: 'Unknown',
                });
            }
        }
        catch (error) {
            console.log('Error detecting GPUs');
        }
        return gpus;
    }
    getMemoryInfo() {
        const info = {
            total: 0,
            free: 0,
            available: 0,
            used: 0,
            buffers: 0,
            cached: 0,
            shared: 0,
            slab: 0,
            active: 0,
            inactive: 0,
            dirty: 0,
            writeback: 0,
            mapped: 0,
            pageTables: 0,
            kernelStack: 0,
            swapTotal: 0,
            swapFree: 0,
            swapUsed: 0,
            swapCached: 0,
        };
        try {
            const [memInfoOut] = this.utils.executeCommand('cat', ['/proc/meminfo']);
            const lines = memInfoOut.split('\n');
            for (const line of lines) {
                const parts = line.split(/\s+/);
                const key = parts[0]?.replace(':', '');
                const value = parseInt(parts[1]) || 0;
                switch (key) {
                    case 'MemTotal':
                        info.total = value;
                        break;
                    case 'MemFree':
                        info.free = value;
                        break;
                    case 'MemAvailable':
                        info.available = value;
                        break;
                    case 'Buffers':
                        info.buffers = value;
                        break;
                    case 'Cached':
                        info.cached = value;
                        break;
                    case 'Shmem':
                        info.shared = value;
                        break;
                    case 'Slab':
                        info.slab = value;
                        break;
                    case 'Active':
                        info.active = value;
                        break;
                    case 'Inactive':
                        info.inactive = value;
                        break;
                    case 'Dirty':
                        info.dirty = value;
                        break;
                    case 'Writeback':
                        info.writeback = value;
                        break;
                    case 'Mapped':
                        info.mapped = value;
                        break;
                    case 'PageTables':
                        info.pageTables = value;
                        break;
                    case 'KernelStack':
                        info.kernelStack = value;
                        break;
                    case 'SwapTotal':
                        info.swapTotal = value;
                        break;
                    case 'SwapFree':
                        info.swapFree = value;
                        break;
                    case 'SwapCached':
                        info.swapCached = value;
                        break;
                }
            }
            // Calculate used memory
            info.used = info.total - info.free - info.buffers - info.cached;
            info.swapUsed = info.swapTotal - info.swapFree;
        }
        catch (error) {
            console.error('Error getting memory info:', error);
        }
        return info;
    }
    hasBattery() {
        try {
            // Check using UPower
            const [upowerOut] = this.utils.executeCommand('upower', ['-e']);
            if (upowerOut && upowerOut.includes('battery')) {
                return true;
            }
            // Fallback: check /sys/class/power_supply/
            const [lsOut] = this.utils.executeCommand('ls', ['/sys/class/power_supply/']);
            if (lsOut) {
                const devices = lsOut.split('\n').filter(d => d.trim());
                for (const device of devices) {
                    const [typeOut] = this.utils.executeCommand('cat', [`/sys/class/power_supply/${device}/type`]);
                    if (typeOut && typeOut.trim() === 'Battery') {
                        return true;
                    }
                }
            }
            // Fallback: check with fastfetch
            const [fastfetchOut] = this.utils.executeCommand('fastfetch', ['--format', 'json']);
            if (fastfetchOut) {
                const data = JSON.parse(fastfetchOut);
                const batteryModule = data.find((item) => item.type === 'Battery');
                if (batteryModule?.result) {
                    const batteryArray = Array.isArray(batteryModule.result) ? batteryModule.result : [batteryModule.result];
                    return batteryArray.length > 0 && batteryArray[0] !== null && batteryArray[0] !== undefined;
                }
            }
        }
        catch (error) {
            console.log('Battery detection error:', error);
        }
        return false;
    }
    getSystemInfo() {
        const systemInfo = {
            hostname: '',
            os: {},
            kernel: {},
            uptime: {},
            displays: []
        };
        try {
            const [stdout] = this.utils.executeCommand('fastfetch', ['--format', 'json']);
            const fastfetchData = JSON.parse(stdout);
            for (const item of fastfetchData) {
                if (!item.result)
                    continue;
                switch (item.type) {
                    case 'Title':
                    case 'Host':
                        systemInfo.hostname = item.result;
                        break;
                    case 'OS':
                        systemInfo.os = {
                            name: item.result.name,
                            prettyName: item.result.prettyName,
                            version: item.result.version,
                            versionID: item.result.versionID,
                            id: item.result.id,
                            idLike: item.result.idLike
                        };
                        break;
                    case 'Kernel':
                        systemInfo.kernel = {
                            name: item.result.name,
                            release: item.result.release,
                            version: item.result.version
                        };
                        break;
                    case 'Uptime':
                        systemInfo.uptime = item.result;
                        break;
                    case 'Display':
                        if (Array.isArray(item.result)) {
                            systemInfo.displays = item.result.map((d) => ({
                                name: d.name,
                                resolution: `${d.output.width}x${d.output.height}`,
                                refreshRate: d.output.refreshRate,
                                type: d.type
                            }));
                        }
                        break;
                }
            }
        }
        catch (error) {
            console.error('Error getting system info:', error);
        }
        return systemInfo;
    }
    getSoftwareInfo() {
        const softwareInfo = {
            packages: {},
            shell: {},
            desktopEnvironment: {},
            windowManager: {},
            terminal: ''
        };
        try {
            const [stdout] = this.utils.executeCommand('fastfetch', ['--format', 'json']);
            const fastfetchData = JSON.parse(stdout);
            for (const item of fastfetchData) {
                if (!item.result)
                    continue;
                switch (item.type) {
                    case 'Packages':
                        softwareInfo.packages = item.result;
                        break;
                    case 'Shell':
                        softwareInfo.shell = {
                            name: item.result.exeName,
                            version: item.result.version
                        };
                        break;
                    case 'DE':
                        softwareInfo.desktopEnvironment = {
                            name: item.result.name || item.result.prettyName,
                            version: item.result.version
                        };
                        break;
                    case 'WM':
                        softwareInfo.windowManager = {
                            name: item.result.prettyName || item.result.name
                        };
                        break;
                    case 'Terminal':
                        softwareInfo.terminal = item.result;
                        break;
                }
            }
        }
        catch (error) {
            console.error('Error getting software info:', error);
        }
        return softwareInfo;
    }
    getBatteryHistory() {
        const history = [];
        try {
            // Get battery device path
            const [deviceOut] = this.utils.executeCommand('upower', ['-e']);
            const devices = deviceOut.split('\n').filter(d => d.includes('battery'));
            if (devices.length > 0) {
                const batteryDevice = devices[0].trim();
                // Use gdbus to call GetHistory method directly from UPower D-Bus API
                // This returns the actual stored history from UPower's database
                const [historyOut] = this.utils.executeCommand('gdbus', [
                    'call',
                    '--system',
                    '--dest', 'org.freedesktop.UPower',
                    '--object-path', batteryDevice,
                    '--method', 'org.freedesktop.UPower.Device.GetHistory',
                    'charge', // history type: charge, rate, or time-full
                    '0', // timespec (0 = all available data)
                    '1000' // resolution (maximum number of points)
                ]);
                if (historyOut) {
                    // Parse D-Bus array output format: [(uint32 timestamp, double value, uint32 state), ...]
                    // Filter last 24 hours
                    const now = Math.floor(Date.now() / 1000);
                    const twentyFourHoursAgo = now - (24 * 60 * 60);
                    // Extract tuples using regex: (timestamp, percentage, state)
                    const tupleRegex = /\((\d+),\s*([\d.]+),\s*\d+\)/g;
                    let match;
                    while ((match = tupleRegex.exec(historyOut)) !== null) {
                        const timestamp = parseInt(match[1]);
                        const percentage = parseFloat(match[2]);
                        // Filter out invalid data (0.0 percentage) and old data
                        if (percentage > 0 && timestamp >= twentyFourHoursAgo) {
                            history.push({
                                timestamp: timestamp * 1000, // Convert to milliseconds for JavaScript Date
                                level: percentage
                            });
                        }
                    }
                }
            }
        }
        catch (error) {
            console.log('Error getting battery history:', error);
        }
        return history;
    }
}
 DataService;
class InfoRow {
    constructor(title, value, description) {
        // Create main container box
        const mainBox = new Gtk.Box({
            orientation: Gtk.Orientation.HORIZONTAL,
            spacing: 12,
            margin_start: 40,
            margin_end: 12,
            margin_top: 8,
            margin_bottom: 8,
        });
        if (description) {
            // Left side: Title and description (vertically stacked)
            const leftBox = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
                spacing: 2,
                hexpand: true,
                valign: Gtk.Align.CENTER,
            });
            const titleLabel = new Gtk.Label({
                label: title,
                xalign: 0,
                wrap: false,
                ellipsize: 3, // Pango.EllipsizeMode.END
            });
            // Don't add title-4 class to keep title not bold
            const descriptionLabel = new Gtk.Label({
                label: description,
                xalign: 0,
                wrap: false,
                ellipsize: 3, // Pango.EllipsizeMode.END
            });
            descriptionLabel.add_css_class('dim-label');
            descriptionLabel.add_css_class('caption');
            leftBox.append(titleLabel);
            leftBox.append(descriptionLabel);
            mainBox.append(leftBox);
        }
        else {
            // No description: Title centered vertically on the left
            const titleLabel = new Gtk.Label({
                label: title,
                xalign: 0,
                wrap: false,
                ellipsize: 3, // Pango.EllipsizeMode.END
                hexpand: true,
                valign: Gtk.Align.CENTER,
            });
            // Don't add title-4 class to keep title not bold
            mainBox.append(titleLabel);
        }
        // Right side: Value
        const valueLabel = new Gtk.Label({
            label: value,
            xalign: 1,
            wrap: false,
            ellipsize: 3, // Pango.EllipsizeMode.END
            valign: Gtk.Align.CENTER,
        });
        valueLabel.add_css_class('monospace');
        mainBox.append(valueLabel);
        // Create list box row to contain our custom layout
        this.row = new Gtk.ListBoxRow({
            child: mainBox,
            activatable: false,
        });
    }
    getWidget() {
        return this.row;
    }
}
 InfoRow;
class TopProcessesList {
    constructor(sortBy = 'cpu', maxLines = 5) {
        this.sortBy = sortBy;
        this.maxLines = maxLines;
        this.utils = UtilsService.instance;
        // Create container
        this.container = new Gtk.Box({
            orientation: Gtk.Orientation.VERTICAL,
            spacing: 0,
            margin_top: 6,
            margin_start: 6,
            margin_end: 6,
        });
        // Create list box
        this.listBox = new Gtk.ListBox({
            selection_mode: Gtk.SelectionMode.NONE,
        });
        this.listBox.add_css_class('boxed-list');
        this.container.append(this.listBox);
    }
    getTitleText() {
        switch (this.sortBy) {
            case 'cpu':
                return 'Top CPU Processes';
            case 'memory':
                return 'Top Memory Processes';
            default:
                return 'Top Processes';
        }
    }
    getWidget() {
        return this.container;
    }
    setSortBy(sortBy) {
        this.sortBy = sortBy;
    }
    setMaxLines(maxLines) {
        this.maxLines = maxLines;
    }
    updateProcesses(processes) {
        // Clear current list
        let child = this.listBox.get_first_child();
        while (child) {
            const next = child.get_next_sibling();
            this.listBox.remove(child);
            child = next;
        }
        // Sort processes based on sortBy
        const sortedProcesses = [...processes].sort((a, b) => {
            if (this.sortBy === 'cpu') {
                return b.cpu - a.cpu;
            }
            else {
                return b.memory - a.memory;
            }
        });
        // Take only maxLines processes
        const topProcesses = sortedProcesses.slice(0, this.maxLines);
        // Add processes to list
        for (const process of topProcesses) {
            const row = new Gtk.Box({
                orientation: Gtk.Orientation.HORIZONTAL,
                spacing: 8,
                margin_start: 8,
                margin_end: 8,
                margin_top: 4,
                margin_bottom: 4,
            });
            const nameLabel = new Gtk.Label({
                label: process.name,
                halign: Gtk.Align.START,
                hexpand: true,
                ellipsize: 3, // PANGO_ELLIPSIZE_END
                max_width_chars: 20,
            });
            const valueLabel = new Gtk.Label({
                label: this.sortBy === 'cpu'
                    ? `${process.cpu.toFixed(1)}%`
                    : this.utils.formatBytes(process.memory * 1024), // Convert KB to bytes
                halign: Gtk.Align.END,
            });
            row.append(nameLabel);
            row.append(valueLabel);
            this.listBox.append(row);
        }
    }
    destroy() {
        // Cleanup if needed
    }
}
 TopProcessesList;
class ResumeComponent {
    constructor() {
        this.cpuUsage = 0;
        this.gpuUsage = 0;
        this.memoryUsage = 0;
        this.diskUsage = 0;
        this.networkDownloadSpeed = 0;
        this.networkUploadSpeed = 0;
        this.cpuTemp = 0;
        this.gpuTemp = 0;
        this.hasBattery = false;
        this.batteryHourlyData = new Map();
        this.resumeService = ResumeService.instance;
        this.utils = UtilsService.instance;
        this.dataService = DataService.instance;
        this.hasBattery = this.dataService.hasBattery();
        const builder = Gtk.Builder.new();
        try {
            try {
                builder.add_from_file('/usr/share/com.obision.app.system/ui/resume.ui');
            }
            catch (e) {
                builder.add_from_file('data/ui/resume.ui');
            }
        }
        catch (e) {
            console.error('Could not load resume.ui:', e);
            this.container = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
                spacing: 12,
            });
            return;
        }
        this.container = builder.get_object('resume_container');
        this.cpuLabel = builder.get_object('cpu_value');
        this.gpuLabel = builder.get_object('gpu_value_resume');
        this.memoryLabel = builder.get_object('memory_value');
        this.diskLabel = builder.get_object('disk_value');
        this.networkLabel = builder.get_object('network_value');
        this.cpuChart = builder.get_object('cpu_chart');
        this.gpuChart = builder.get_object('gpu_chart_resume');
        this.memoryChart = builder.get_object('memory_chart');
        this.diskChart = builder.get_object('disk_chart');
        this.networkChart = builder.get_object('network_chart');
        this.cpuTempChart = builder.get_object('cpu_temp_chart');
        this.gpuTempChart = builder.get_object('gpu_temp_chart');
        this.cpuTempLabel = builder.get_object('cpu_temp_value');
        this.gpuTempLabel = builder.get_object('gpu_temp_value');
        this.batteryBox = builder.get_object('battery_box');
        this.batteryPercentage = builder.get_object('battery_percentage');
        this.batteryStatusTime = builder.get_object('battery_status_time');
        this.batteryHistoryChart = builder.get_object('battery_history_chart');
        this.topProcessesBox = builder.get_object('top_processes_box');
        this.systemLoadBox = builder.get_object('system_load_box');
        this.load1minLabel = builder.get_object('load_1min');
        this.load5minLabel = builder.get_object('load_5min');
        this.load15minLabel = builder.get_object('load_15min');
        this.load1minBar = builder.get_object('load_1min_bar');
        this.load5minBar = builder.get_object('load_5min_bar');
        this.load15minBar = builder.get_object('load_15min_bar');
        this.topProcessesBox = builder.get_object('top_processes_box');
        this.systemInfoList = builder.get_object('system_info_list');
        // Create AdwPreferencesGroup for system info
        this.systemInfoGroup = new Adw.PreferencesGroup();
        this.systemInfoList.append(this.systemInfoGroup);
        // Create and add TopProcessesList to the widget container
        this.topProcessesWidget = new TopProcessesList('cpu', 5);
        const topProcessesWidgetContainer = builder.get_object('top_processes_widget_container');
        topProcessesWidgetContainer.append(this.topProcessesWidget.getWidget());
        // Setup battery history chart drawing function
        if (this.hasBattery) {
            this.batteryHistoryChart.set_draw_func((area, cr, width, height) => {
                this.drawBatteryHistoryChart(cr, width, height);
            });
            this.loadBatteryHistoricalData();
        }
        // Configure layout based on battery presence
        this.configureBatteryLayout();
        // Setup drawing functions
        this.cpuChart.set_draw_func((area, cr, width, height) => {
            this.drawCircularChart(cr, width, height, this.cpuUsage);
        });
        this.gpuChart.set_draw_func((area, cr, width, height) => {
            this.drawCircularChart(cr, width, height, this.gpuUsage);
        });
        this.memoryChart.set_draw_func((area, cr, width, height) => {
            this.drawCircularChart(cr, width, height, this.memoryUsage);
        });
        this.diskChart.set_draw_func((area, cr, width, height) => {
            this.drawCircularChart(cr, width, height, this.diskUsage);
        });
        this.networkChart.set_draw_func((area, cr, width, height) => {
            this.drawNetworkChart(cr, width, height);
        });
        this.cpuTempChart.set_draw_func((area, cr, width, height) => {
            this.drawTemperatureChart(cr, width, height, this.cpuTemp);
        });
        this.gpuTempChart.set_draw_func((area, cr, width, height) => {
            this.drawTemperatureChart(cr, width, height, this.gpuTemp);
        });
        // Subscribe to resume service updates
        this.dataCallback = this.onDataUpdate.bind(this);
        this.resumeService.subscribeToUpdates(this.dataCallback);
    }
    loadBatteryHistoricalData() {
        // Clear existing data
        this.batteryHourlyData.clear();
        // Get battery history from DataService
        const history = this.dataService.getBatteryHistory();
        if (history.length === 0) {
            // If no historical data, create empty buckets for last 12 hours
            const now = new Date();
            for (let i = 11; i >= 0; i--) {
                const hour = new Date(now.getTime() - i * 60 * 60 * 1000).getHours();
                this.batteryHourlyData.set(hour, []);
            }
            return;
        }
        // Group battery levels by hour
        for (const entry of history) {
            const date = new Date(entry.timestamp);
            const hour = date.getHours();
            if (!this.batteryHourlyData.has(hour)) {
                this.batteryHourlyData.set(hour, []);
            }
            this.batteryHourlyData.get(hour).push(entry.level);
        }
        // Redraw chart
        this.batteryHistoryChart.queue_draw();
    }
    drawBatteryHistoryChart(cr, width, height) {
        const padding = 20;
        const bottomPadding = 25;
        const chartWidth = width - 2 * padding;
        const chartHeight = height - padding - bottomPadding;
        // Clear background
        cr.setSourceRGBA(0, 0, 0, 0);
        cr.paint();
        // Draw grid lines
        cr.setSourceRGBA(0.8, 0.8, 0.8, 0.2);
        cr.setLineWidth(0.5);
        // Horizontal grid lines (0%, 50%, 100%)
        for (let i = 0; i <= 2; i++) {
            const y = padding + (chartHeight * i / 2);
            cr.moveTo(padding, y);
            cr.lineTo(width - padding, y);
            cr.stroke();
        }
        if (this.batteryHourlyData.size === 0) {
            // No data message
            cr.setSourceRGB(0.5, 0.5, 0.5);
            cr.setFontSize(10);
            const msg = 'No data';
            const extents = cr.textExtents(msg);
            cr.moveTo((width - extents.width) / 2, height / 2);
            cr.showText(msg);
            return;
        }
        // Calculate bar width for 12 hours
        const barCount = 12;
        const barSpacing = 2;
        const barWidth = (chartWidth - (barCount - 1) * barSpacing) / barCount;
        // Get hours in order (last 12 hours)
        const currentHour = new Date().getHours();
        const hours = [];
        for (let i = 0; i < barCount; i++) {
            const hour = (currentHour - barCount + 1 + i + 24) % 24;
            hours.push(hour);
        }
        // Draw bars
        hours.forEach((hour, index) => {
            const levels = this.batteryHourlyData.get(hour) || [];
            if (levels.length === 0) {
                // Draw empty bar
                const x = padding + index * (barWidth + barSpacing);
                cr.setSourceRGBA(0.7, 0.7, 0.7, 0.15);
                cr.rectangle(x, height - bottomPadding - 3, barWidth, 3);
                cr.fill();
            }
            else {
                // Calculate average level for this hour
                const avgLevel = levels.reduce((sum, val) => sum + val, 0) / levels.length;
                const barHeight = (avgLevel / 100) * chartHeight;
                const x = padding + index * (barWidth + barSpacing);
                const y = height - bottomPadding - barHeight;
                // Color based on battery level
                if (avgLevel > 50) {
                    cr.setSourceRGB(0.2, 0.8, 0.2); // Green
                }
                else if (avgLevel > 20) {
                    cr.setSourceRGB(0.9, 0.7, 0.2); // Yellow/Orange
                }
                else {
                    cr.setSourceRGB(0.9, 0.2, 0.2); // Red
                }
                // Draw bar
                cr.rectangle(x, y, barWidth, barHeight);
                cr.fill();
            }
            // Draw hour label (every 3 hours)
            if (index % 3 === 0) {
                cr.setSourceRGB(0.5, 0.5, 0.5);
                cr.setFontSize(8);
                const label = `${hour}h`;
                const x = padding + index * (barWidth + barSpacing);
                const extents = cr.textExtents(label);
                cr.moveTo(x + (barWidth - extents.width) / 2, height - bottomPadding + 12);
                cr.showText(label);
            }
        });
    }
    configureBatteryLayout() {
        if (!this.hasBattery) {
            // Hide battery box
            this.batteryBox.set_visible(false);
            // Get the grid layout manager
            const grid = this.container.get_first_child();
            if (grid) {
                // Make top processes and system load span 2 columns (columns 0-1)
                const topProcessesLayoutChild = this.topProcessesBox.get_parent();
                if (topProcessesLayoutChild) {
                    topProcessesLayoutChild.column = 0;
                    topProcessesLayoutChild.column_span = 2;
                }
                const systemLoadLayoutChild = this.systemLoadBox.get_parent();
                if (systemLoadLayoutChild) {
                    systemLoadLayoutChild.column = 2;
                    systemLoadLayoutChild.column_span = 1;
                }
            }
        }
        else {
            // Update battery info
            this.updateBatteryInfo();
        }
    }
    updateBatteryInfo() {
        try {
            const [upowerOut] = this.utils.executeCommand('upower', ['-i', '/org/freedesktop/UPower/devices/battery_BAT0']);
            let percentage = '--';
            let state = '--';
            let timeToEmpty = '--';
            let timeToFull = '--';
            const lines = upowerOut.split('\n');
            for (const line of lines) {
                if (line.includes('percentage:')) {
                    percentage = line.split(':')[1].trim();
                }
                else if (line.includes('state:')) {
                    state = line.split(':')[1].trim();
                }
                else if (line.includes('time to empty:')) {
                    timeToEmpty = line.split(':')[1].trim();
                }
                else if (line.includes('time to full:')) {
                    timeToFull = line.split(':')[1].trim();
                }
            }
            this.batteryPercentage.set_label(percentage);
            // Combine status and time in one label (capitalized)
            let statusText = state;
            if (state === 'discharging' && timeToEmpty !== 'unknown' && timeToEmpty !== '') {
                statusText = `${this.utils.capitalizeWords(state)} - ${timeToEmpty} remaining`;
            }
            else if (state === 'charging' && timeToFull !== 'unknown' && timeToFull !== '') {
                statusText = `${this.utils.capitalizeWords(state)} - ${timeToFull} to full`;
            }
            else if (state === 'fully-charged') {
                statusText = 'Fully Charged';
            }
            else {
                statusText = this.utils.capitalizeWords(state);
            }
            this.batteryStatusTime.set_label(statusText);
        }
        catch (error) {
            console.error('Error updating battery info:', error);
        }
    }
    onDataUpdate(data) {
        // Update usage values
        this.cpuUsage = data.cpu.usage;
        this.gpuUsage = data.gpu.usage;
        this.memoryUsage = data.memory.percentage;
        this.diskUsage = data.disk.percentage;
        this.cpuTemp = data.cpuTemp;
        this.gpuTemp = data.gpuTemp;
        // Update labels
        this.cpuLabel.set_label(`${data.cpu.usage}%`);
        this.gpuLabel.set_label(`${data.gpu.usage}%`);
        this.memoryLabel.set_label(`${data.memory.percentage}%`);
        this.diskLabel.set_label(`${data.disk.percentage}%`);
        this.networkLabel.set_label(`↓ ${data.network.download}\n↑ ${data.network.upload}`);
        this.cpuTempLabel.set_label(data.cpuTemp >= 0 ? `${data.cpuTemp}°C` : 'N/A');
        this.gpuTempLabel.set_label(data.gpuTemp >= 0 ? `${data.gpuTemp}°C` : 'N/A');
        // Update battery info if present
        if (this.hasBattery) {
            this.updateBatteryInfo();
            // Refresh battery history occasionally
            this.loadBatteryHistoricalData();
        }
        // Update system load
        this.load1minLabel.set_label(data.systemLoad.load1.toFixed(2));
        this.load5minLabel.set_label(data.systemLoad.load5.toFixed(2));
        this.load15minLabel.set_label(data.systemLoad.load15.toFixed(2));
        this.load1minBar.set_value(data.systemLoad.load1);
        this.load5minBar.set_value(data.systemLoad.load5);
        this.load15minBar.set_value(data.systemLoad.load15);
        // Update top processes
        const processInfoList = data.topProcesses.map(p => ({
            name: p.name,
            cpu: p.cpu,
            memory: p.memory
        }));
        this.topProcessesWidget.updateProcesses(processInfoList);
        // Update system info - recreate preferences group to clear rows
        this.systemInfoList.remove(this.systemInfoGroup);
        this.systemInfoGroup = new Adw.PreferencesGroup();
        this.systemInfoList.append(this.systemInfoGroup);
        this.addSystemInfoRow('OS', data.systemInfo.os, 'Operating system and distribution');
        this.addSystemInfoRow('Kernel', data.systemInfo.kernel, 'Linux kernel version');
        this.addSystemInfoRow('Uptime', data.systemInfo.uptime, 'Time since last boot');
        this.addSystemInfoRow('CPU', data.cpu.model, 'Processor model name');
        this.addSystemInfoRow('Cores', `${data.cpu.cores}`, 'Number of CPU cores');
        this.addSystemInfoRow('GPU', data.gpu.name, 'Graphics processing unit');
        this.addSystemInfoRow('Memory', `${this.utils.formatBytes(data.memory.used)} / ${this.utils.formatBytes(data.memory.total)}`, 'RAM usage and total capacity');
        this.addSystemInfoRow('Disk', `${this.utils.formatBytes(data.disk.used)} / ${this.utils.formatBytes(data.disk.total)}`, 'Storage usage and total capacity');
        // Redraw charts
        this.cpuChart.queue_draw();
        this.gpuChart.queue_draw();
        this.memoryChart.queue_draw();
        this.diskChart.queue_draw();
        this.networkChart.queue_draw();
        this.cpuTempChart.queue_draw();
        this.gpuTempChart.queue_draw();
    }
    addSystemInfoRow(title, value, subtitle = '') {
        const row = new Adw.ActionRow({
            title: title,
            subtitle: subtitle,
        });
        const valueLabel = new Gtk.Label({
            label: value,
        });
        valueLabel.add_css_class('dim-label');
        row.add_suffix(valueLabel);
        this.systemInfoGroup.add(row);
    }
    drawCircularChart(cr, width, height, percentage) {
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = Math.min(width, height) / 2 - 10;
        const lineWidth = 12;
        // Gap at bottom (in radians)
        const gapAngle = Math.PI / 2.5; // 70 degrees gap at bottom
        const startAngle = Math.PI / 2 + gapAngle / 2; // Start after gap
        const backgroundEndAngle = startAngle + (2 * Math.PI - gapAngle); // End before gap
        // Background arc (open at bottom)
        cr.setSourceRGBA(0.3, 0.3, 0.3, 0.2);
        cr.setLineWidth(lineWidth);
        cr.arc(centerX, centerY, radius, startAngle, backgroundEndAngle);
        cr.stroke();
        // Progress arc
        const maxAngle = 2 * Math.PI - gapAngle;
        const progressAngle = maxAngle * percentage / 100;
        const endAngle = startAngle + progressAngle;
        // Color gradient based on percentage
        if (percentage < 50) {
            cr.setSourceRGBA(0.2, 0.7, 0.3, 1); // Green
        }
        else if (percentage < 80) {
            cr.setSourceRGBA(0.9, 0.7, 0.1, 1); // Yellow
        }
        else {
            cr.setSourceRGBA(0.9, 0.2, 0.2, 1); // Red
        }
        cr.setLineWidth(lineWidth);
        cr.arc(centerX, centerY, radius, startAngle, endAngle);
        cr.stroke();
    }
    drawNetworkChart(cr, width, height) {
        const centerX = width / 2;
        const centerY = height / 2;
        const outerRadius = Math.min(width, height) / 2 - 10;
        const innerRadius = outerRadius - 18;
        const lineWidth = 12;
        // Gap at bottom (in radians)
        const gapAngle = Math.PI / 2.5; // 70 degrees gap at bottom
        const startAngle = Math.PI / 2 + gapAngle / 2; // Start after gap
        const backgroundEndAngle = startAngle + (2 * Math.PI - gapAngle); // End before gap
        // Outer circle - Download (blue)
        // Background
        cr.setSourceRGBA(0.3, 0.3, 0.3, 0.2);
        cr.setLineWidth(lineWidth);
        cr.arc(centerX, centerY, outerRadius, startAngle, backgroundEndAngle);
        cr.stroke();
        // Progress
        const maxAngle = 2 * Math.PI - gapAngle;
        const downloadProgressAngle = maxAngle * this.networkDownloadSpeed / 100;
        const downloadEndAngle = startAngle + downloadProgressAngle;
        cr.setSourceRGBA(0.2, 0.4, 0.8, 1); // Blue for download
        cr.setLineWidth(lineWidth);
        cr.arc(centerX, centerY, outerRadius, startAngle, downloadEndAngle);
        cr.stroke();
        // Inner circle - Upload (green)
        // Background
        cr.setSourceRGBA(0.3, 0.3, 0.3, 0.2);
        cr.setLineWidth(lineWidth);
        cr.arc(centerX, centerY, innerRadius, startAngle, backgroundEndAngle);
        cr.stroke();
        // Progress
        const uploadProgressAngle = maxAngle * this.networkUploadSpeed / 100;
        const uploadEndAngle = startAngle + uploadProgressAngle;
        cr.setSourceRGBA(0.2, 0.7, 0.3, 1); // Green for upload
        cr.setLineWidth(lineWidth);
        cr.arc(centerX, centerY, innerRadius, startAngle, uploadEndAngle);
        cr.stroke();
    }
    drawTemperatureChart(cr, width, height, temperature) {
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = Math.min(width, height) / 2 - 10;
        const lineWidth = 12;
        // Gap at bottom (in radians)
        const gapAngle = Math.PI / 2.5; // 70 degrees gap at bottom
        const startAngle = Math.PI / 2 + gapAngle / 2; // Start after gap
        const backgroundEndAngle = startAngle + (2 * Math.PI - gapAngle); // End before gap
        // Background arc (open at bottom)
        cr.setSourceRGBA(0.3, 0.3, 0.3, 0.2);
        cr.setLineWidth(lineWidth);
        cr.arc(centerX, centerY, radius, startAngle, backgroundEndAngle);
        cr.stroke();
        // Only draw progress if temperature is available
        if (temperature >= 0) {
            // Progress arc (temperature scale from 0 to 100°C)
            const maxTemp = 100;
            const percentage = Math.min((temperature / maxTemp) * 100, 100);
            const maxAngle = 2 * Math.PI - gapAngle;
            const progressAngle = maxAngle * percentage / 100;
            const endAngle = startAngle + progressAngle;
            // Color gradient based on temperature
            if (temperature < 50) {
                cr.setSourceRGBA(0.2, 0.7, 0.3, 1); // Green (cool)
            }
            else if (temperature < 70) {
                cr.setSourceRGBA(0.9, 0.7, 0.1, 1); // Yellow (warm)
            }
            else {
                cr.setSourceRGBA(0.9, 0.2, 0.2, 1); // Red (hot)
            }
            cr.setLineWidth(lineWidth);
            cr.arc(centerX, centerY, radius, startAngle, endAngle);
            cr.stroke();
        }
    }
    getWidget() {
        return this.container;
    }
    destroy() {
        this.resumeService.unsubscribe(this.dataCallback);
        if (this.topProcessesWidget) {
            this.topProcessesWidget.destroy();
        }
    }
}
 ResumeComponent;
class CpuComponent {
    constructor() {
        this.updateTimeoutId = null;
        this.usageHistory = [];
        this.perCoreUsage = [];
        this.prevCoreIdle = [];
        this.prevCoreTotal = [];
        this.maxHistoryPoints = 60; // 60 data points for history
        this.prevIdle = 0;
        this.prevTotal = 0;
        this.numCores = 0;
        this.utils = UtilsService.instance;
        this.dataService = DataService.instance;
        this.processesService = ProcessesService.instance;
        const builder = Gtk.Builder.new();
        try {
            try {
                builder.add_from_file('/usr/share/com.obision.app.system/ui/cpu.ui');
            }
            catch (e) {
                builder.add_from_file('data/ui/cpu.ui');
            }
        }
        catch (e) {
            console.error('Could not load cpu.ui:', e);
            this.container = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
                spacing: 12,
            });
            return;
        }
        this.container = builder.get_object('cpu_container');
        this.cpuChart = builder.get_object('cpu_chart');
        this.cpuUsageBar = builder.get_object('cpu_usage_bar');
        this.cpuUsageTitle = builder.get_object('cpu_usage_title');
        this.cpuUsagePercent = builder.get_object('cpu_usage_percent');
        this.cpuPerCoreChart = builder.get_object('cpu_percore_chart');
        this.chartStack = builder.get_object('chart_stack');
        this.generalButton = builder.get_object('general_button');
        this.coresButton = builder.get_object('cores_button');
        this.cpuModelValue = builder.get_object('cpu_model_value');
        this.cpuCoresValue = builder.get_object('cpu_cores_value');
        this.cpuLogicalCoresValue = builder.get_object('cpu_logical_cores_value');
        this.cpuThreadsValue = builder.get_object('cpu_threads_value');
        this.cpuUsageValue = builder.get_object('cpu_usage_value');
        this.cpuFrequencyValue = builder.get_object('cpu_frequency_value');
        this.cpuMaxFrequencyValue = builder.get_object('cpu_max_frequency_value');
        this.cpuArchitectureValue = builder.get_object('cpu_architecture_value');
        this.cpuVendorValue = builder.get_object('cpu_vendor_value');
        this.cpuFamilyValue = builder.get_object('cpu_family_value');
        this.cpuModelIdValue = builder.get_object('cpu_model_id_value');
        this.cpuSteppingValue = builder.get_object('cpu_stepping_value');
        this.cpuL1dCacheValue = builder.get_object('cpu_l1d_cache_value');
        this.cpuL1iCacheValue = builder.get_object('cpu_l1i_cache_value');
        this.cpuL2CacheValue = builder.get_object('cpu_l2_cache_value');
        this.cpuL3CacheValue = builder.get_object('cpu_l3_cache_value');
        this.cpuVirtualizationValue = builder.get_object('cpu_virtualization_value');
        this.cpuBogomipsValue = builder.get_object('cpu_bogomips_value');
        // Create and add TopProcessesList
        this.topProcessesList = new TopProcessesList('cpu', 8);
        const topProcessesContainer = builder.get_object('top_processes_container');
        if (topProcessesContainer) {
            topProcessesContainer.append(this.topProcessesList.getWidget());
        }
        // Initialize history with zeros
        for (let i = 0; i < this.maxHistoryPoints; i++) {
            this.usageHistory.push(0);
        }
        // Setup drawing function for overall chart
        this.cpuChart.set_draw_func((area, cr, width, height) => {
            this.drawLineChart(cr, width, height);
        });
        // Setup drawing function for per-core chart
        this.cpuPerCoreChart.set_draw_func((area, cr, width, height) => {
            this.drawPerCoreChart(cr, width, height);
        });
        // Setup toggle button handlers
        this.generalButton.connect('toggled', () => {
            if (this.generalButton.get_active()) {
                this.chartStack.set_visible_child_name('overall');
            }
        });
        this.coresButton.connect('toggled', () => {
            if (this.coresButton.get_active()) {
                this.chartStack.set_visible_child_name('percore');
            }
        });
        // Load static CPU info
        this.loadCpuInfo();
        // Initial update
        this.updateData();
        // Update every 2 seconds
        this.updateTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2000, () => {
            this.updateData();
            return GLib.SOURCE_CONTINUE;
        });
    }
    loadCpuInfo() {
        try {
            const cpuInfo = this.dataService.getCpuInfo();
            if (cpuInfo.model) {
                this.cpuModelValue.set_label(cpuInfo.model);
            }
            if (cpuInfo.cores) {
                this.cpuCoresValue.set_label(cpuInfo.cores.toString());
            }
            if (cpuInfo.threads) {
                this.cpuThreadsValue.set_label(cpuInfo.threads.toString());
            }
            if (cpuInfo.logicalCores) {
                this.cpuLogicalCoresValue.set_label(cpuInfo.logicalCores.toString());
            }
            if (cpuInfo.architecture) {
                this.cpuArchitectureValue.set_label(cpuInfo.architecture);
            }
            if (cpuInfo.vendor) {
                this.cpuVendorValue.set_label(cpuInfo.vendor);
            }
            if (cpuInfo.family) {
                this.cpuFamilyValue.set_label(cpuInfo.family);
            }
            if (cpuInfo.modelId) {
                this.cpuModelIdValue.set_label(cpuInfo.modelId);
            }
            if (cpuInfo.stepping) {
                this.cpuSteppingValue.set_label(cpuInfo.stepping);
            }
            if (cpuInfo.l1dCache) {
                this.cpuL1dCacheValue.set_label(cpuInfo.l1dCache);
            }
            if (cpuInfo.l1iCache) {
                this.cpuL1iCacheValue.set_label(cpuInfo.l1iCache);
            }
            if (cpuInfo.l2Cache) {
                this.cpuL2CacheValue.set_label(cpuInfo.l2Cache);
            }
            if (cpuInfo.l3Cache) {
                this.cpuL3CacheValue.set_label(cpuInfo.l3Cache);
            }
            if (cpuInfo.virtualization) {
                this.cpuVirtualizationValue.set_label(cpuInfo.virtualization);
            }
            if (cpuInfo.bogomips) {
                this.cpuBogomipsValue.set_label(cpuInfo.bogomips);
            }
            if (cpuInfo.maxFrequency) {
                this.cpuMaxFrequencyValue.set_label(`${cpuInfo.maxFrequency} GHz`);
            }
        }
        catch (error) {
            console.error('Error loading CPU info:', error);
        }
    }
    updateData() {
        try {
            // Get current CPU usage
            const cpuUsage = this.getCpuUsage();
            this.cpuUsageValue.set_label(`${cpuUsage.toFixed(1)}%`);
            // Update CPU usage bar and percent label
            if (this.cpuUsageBar) {
                this.cpuUsageBar.set_value(Math.min(1, Math.max(0, cpuUsage / 100)));
            }
            if (this.cpuUsageTitle) {
                this.cpuUsageTitle.set_label('Actual Load');
            }
            if (this.cpuUsagePercent) {
                this.cpuUsagePercent.set_label(`${cpuUsage.toFixed(1)}%`);
            }
            // Update history
            this.usageHistory.push(cpuUsage);
            if (this.usageHistory.length > this.maxHistoryPoints) {
                this.usageHistory.shift();
            }
            // Get current frequency
            try {
                const [freqOut] = this.utils.executeCommand('cat', ['/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq']);
                const freqKhz = parseInt(freqOut.trim());
                if (!isNaN(freqKhz)) {
                    const freqGhz = (freqKhz / 1000000).toFixed(2);
                    this.cpuFrequencyValue.set_label(`${freqGhz} GHz`);
                }
            }
            catch (e) {
                // Frequency info not available
                this.cpuFrequencyValue.set_label('N/A');
            }
            // Update top processes
            this.updateTopProcesses();
            // Redraw charts
            this.cpuChart.queue_draw();
            this.cpuPerCoreChart.queue_draw();
        }
        catch (error) {
            console.error('Error updating CPU data:', error);
        }
    }
    updateTopProcesses() {
        try {
            const allProcesses = this.processesService['loadProcesses']();
            const processInfoList = allProcesses.map(p => ({
                name: p.command.split(' ')[0].split('/').pop() || p.command,
                cpu: parseFloat(p.cpu) || 0,
                memory: parseFloat(p.rss) || 0
            }));
            this.topProcessesList.updateProcesses(processInfoList);
        }
        catch (error) {
            console.error('Error updating top processes:', error);
        }
    }
    getCpuUsage() {
        try {
            const [stdout] = this.utils.executeCommand('cat', ['/proc/stat']);
            const lines = stdout.split('\n');
            const cpuLine = lines.find(line => line.startsWith('cpu '));
            // Get per-core usage
            const cpuLines = lines.filter(line => /^cpu\d+/.test(line));
            this.numCores = cpuLines.length;
            if (this.perCoreUsage.length === 0) {
                this.perCoreUsage = new Array(this.numCores).fill(0);
                this.prevCoreIdle = new Array(this.numCores).fill(0);
                this.prevCoreTotal = new Array(this.numCores).fill(0);
            }
            cpuLines.forEach((line, index) => {
                const values = line.split(/\s+/).slice(1).map(v => parseInt(v));
                const idle = values[3] + values[4]; // idle + iowait
                const total = values.reduce((a, b) => a + b, 0);
                if (this.prevCoreTotal[index] !== 0) {
                    const diffIdle = idle - this.prevCoreIdle[index];
                    const diffTotal = total - this.prevCoreTotal[index];
                    this.perCoreUsage[index] = diffTotal > 0 ? ((diffTotal - diffIdle) / diffTotal) * 100 : 0;
                }
                this.prevCoreIdle[index] = idle;
                this.prevCoreTotal[index] = total;
            });
            // Get overall usage
            if (cpuLine) {
                const values = cpuLine.split(/\s+/).slice(1).map(v => parseInt(v));
                const idle = values[3] + values[4]; // idle + iowait
                const total = values.reduce((a, b) => a + b, 0);
                if (this.prevTotal !== 0) {
                    const diffIdle = idle - this.prevIdle;
                    const diffTotal = total - this.prevTotal;
                    const usage = diffTotal > 0 ? ((diffTotal - diffIdle) / diffTotal) * 100 : 0;
                    this.prevIdle = idle;
                    this.prevTotal = total;
                    return usage;
                }
                this.prevIdle = idle;
                this.prevTotal = total;
            }
        }
        catch (error) {
            console.error('Error getting CPU usage:', error);
        }
        return 0;
    }
    drawLineChart(cr, width, height) {
        const padding = 20;
        const chartWidth = width - 2 * padding;
        const chartHeight = height - 2 * padding;
        // Clear background with transparent color
        cr.setSourceRGBA(0, 0, 0, 0);
        cr.paint();
        // Draw grid lines
        cr.setSourceRGBA(0.8, 0.8, 0.8, 0.5);
        cr.setLineWidth(1);
        // Horizontal grid lines (0%, 25%, 50%, 75%, 100%)
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            cr.moveTo(padding, y);
            cr.lineTo(width - padding, y);
            cr.stroke();
        }
        // Draw axes
        cr.setSourceRGB(0.5, 0.5, 0.5);
        cr.setLineWidth(2);
        cr.moveTo(padding, padding);
        cr.lineTo(padding, height - padding);
        cr.lineTo(width - padding, height - padding);
        cr.stroke();
        // Draw data line
        if (this.usageHistory.length > 1) {
            cr.setSourceRGB(0.2, 0.6, 1.0);
            cr.setLineWidth(2);
            const pointSpacing = chartWidth / (this.maxHistoryPoints - 1);
            cr.moveTo(padding, height - padding - (this.usageHistory[0] / 100) * chartHeight);
            for (let i = 1; i < this.usageHistory.length; i++) {
                const x = padding + i * pointSpacing;
                const y = height - padding - (this.usageHistory[i] / 100) * chartHeight;
                cr.lineTo(x, y);
            }
            cr.stroke();
            // Fill area under the line
            cr.setSourceRGBA(0.2, 0.6, 1.0, 0.2);
            cr.lineTo(width - padding, height - padding);
            cr.lineTo(padding, height - padding);
            cr.closePath();
            cr.fill();
        }
        // Draw labels
        cr.setSourceRGB(0.3, 0.3, 0.3);
        cr.selectFontFace('Sans', 0, 0);
        cr.setFontSize(10);
        // Y-axis labels
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            const label = `${100 - (i * 25)}%`;
            cr.moveTo(5, y + 3);
            cr.showText(label);
        }
    }
    drawPerCoreChart(cr, width, height) {
        if (this.numCores === 0)
            return;
        const padding = 20;
        const chartWidth = width - 2 * padding;
        const chartHeight = height - 2 * padding;
        // Clear background
        cr.setSourceRGBA(0, 0, 0, 0);
        cr.paint();
        // Draw grid lines
        cr.setSourceRGBA(0.8, 0.8, 0.8, 0.5);
        cr.setLineWidth(1);
        // Horizontal grid lines
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            cr.moveTo(padding, y);
            cr.lineTo(width - padding, y);
            cr.stroke();
        }
        // Draw axes
        cr.setSourceRGB(0.5, 0.5, 0.5);
        cr.setLineWidth(2);
        cr.moveTo(padding, padding);
        cr.lineTo(padding, height - padding);
        cr.lineTo(width - padding, height - padding);
        cr.stroke();
        // Calculate bar dimensions
        const barSpacing = 4;
        const totalSpacing = barSpacing * (this.numCores - 1);
        const barWidth = (chartWidth - totalSpacing) / this.numCores;
        // Draw bars for each core
        for (let i = 0; i < this.numCores; i++) {
            const x = padding + (barWidth + barSpacing) * i;
            const usage = this.perCoreUsage[i] || 0;
            const barHeight = (usage / 100) * chartHeight;
            const y = height - padding - barHeight;
            // Color gradient based on usage
            if (usage < 50) {
                cr.setSourceRGB(0.2, 0.8, 0.4); // Green
            }
            else if (usage < 80) {
                cr.setSourceRGB(0.9, 0.7, 0.2); // Yellow
            }
            else {
                cr.setSourceRGB(0.9, 0.3, 0.3); // Red
            }
            cr.rectangle(x, y, barWidth, barHeight);
            cr.fill();
            // Draw usage percentage on top of bar
            cr.setSourceRGB(0.3, 0.3, 0.3);
            cr.selectFontFace('Sans', 0, 0);
            cr.setFontSize(9);
            const usageText = `${usage.toFixed(0)}%`;
            const textExtents = cr.textExtents(usageText);
            const textX = x + (barWidth - textExtents.width) / 2;
            const textY = y - 4;
            if (textY > padding) {
                cr.moveTo(textX, textY);
                cr.showText(usageText);
            }
            // Draw core label below bar (starting from 1)
            cr.setFontSize(8);
            const coreLabel = `${i + 1}`;
            const labelExtents = cr.textExtents(coreLabel);
            const labelX = x + (barWidth - labelExtents.width) / 2;
            cr.moveTo(labelX, height - padding + 12);
            cr.showText(coreLabel);
        }
        // Draw Y-axis labels
        cr.setSourceRGB(0.3, 0.3, 0.3);
        cr.setFontSize(10);
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            const label = `${100 - (i * 25)}%`;
            cr.moveTo(5, y + 3);
            cr.showText(label);
        }
    }
    getWidget() {
        return this.container;
    }
    destroy() {
        if (this.updateTimeoutId !== null) {
            GLib.source_remove(this.updateTimeoutId);
            this.updateTimeoutId = null;
        }
        if (this.topProcessesList) {
            this.topProcessesList.destroy();
        }
    }
}
 CpuComponent;
class GpuComponent {
    constructor() {
        this.updateTimeoutId = null;
        this.usageHistory = [];
        this.maxHistoryPoints = 60;
        this.hasNvidiaGpu = false;
        this.gpuType = 'unknown';
        this.gpuCount = 0;
        this.utils = UtilsService.instance;
        this.dataService = DataService.instance;
        this.processesService = ProcessesService.instance;
        const builder = Gtk.Builder.new();
        try {
            try {
                builder.add_from_file('/usr/share/com.obision.app.system/ui/gpu.ui');
            }
            catch (e) {
                builder.add_from_file('data/ui/gpu.ui');
            }
        }
        catch (e) {
            console.error('Could not load gpu.ui:', e);
            this.container = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
                spacing: 12,
            });
            return;
        }
        this.container = builder.get_object('gpu_container');
        this.gpuChart = builder.get_object('gpu_chart');
        this.gpuNameValue = builder.get_object('gpu_name_value');
        this.gpuDriverValue = builder.get_object('gpu_driver_value');
        this.gpuMemoryTotalValue = builder.get_object('gpu_memory_total_value');
        this.gpuMemoryUsedValue = builder.get_object('gpu_memory_used_value');
        this.gpuUsageValue = builder.get_object('gpu_usage_value');
        this.gpuTemperatureValue = builder.get_object('gpu_temperature_value');
        this.gpuPowerValue = builder.get_object('gpu_power_value');
        // Create and add TopProcessesList
        this.topProcessesList = new TopProcessesList('cpu', 8);
        const topProcessesContainer = builder.get_object('top_processes_container');
        if (topProcessesContainer) {
            topProcessesContainer.append(this.topProcessesList.getWidget());
        }
        // Initialize history with zeros
        for (let i = 0; i < this.maxHistoryPoints; i++) {
            this.usageHistory.push(0);
        }
        // Setup drawing function for chart
        this.gpuChart.set_draw_func((area, cr, width, height) => {
            this.drawLineChart(cr, width, height);
        });
        // Detect GPU type and count
        this.detectGPU();
        // Load static GPU info
        this.loadGpuInfo();
        // Initial update
        this.updateData();
        // Update every 2 seconds
        this.updateTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2000, () => {
            this.updateData();
            return GLib.SOURCE_CONTINUE;
        });
    }
    detectGPU() {
        // Try NVIDIA first
        try {
            const [whichOut] = this.utils.executeCommand('which', ['nvidia-smi']);
            if (whichOut.trim()) {
                try {
                    const [testOut] = this.utils.executeCommand('nvidia-smi', ['-L']);
                    if (testOut.trim()) {
                        this.hasNvidiaGpu = true;
                        this.gpuType = 'nvidia';
                        this.gpuCount = testOut.trim().split('\n').filter(l => l.trim()).length;
                        console.log(`NVIDIA GPU detected: ${this.gpuCount} GPU(s)`);
                        return;
                    }
                }
                catch (testError) {
                    console.error('nvidia-smi test failed:', testError);
                }
            }
        }
        catch (error) {
            console.log('nvidia-smi not found');
        }
        // Try AMD
        try {
            const [lspciOut] = this.utils.executeCommand('lspci', []);
            const amdLines = lspciOut.split('\n').filter(line => (line.includes('VGA') || line.includes('3D')) &&
                (line.includes('AMD') || line.includes('ATI') || line.includes('Radeon')));
            if (amdLines.length > 0) {
                this.gpuType = 'amd';
                this.gpuCount = amdLines.length;
                console.log(`AMD GPU detected: ${this.gpuCount} GPU(s)`);
                return;
            }
        }
        catch (error) {
            console.log('Error checking for AMD GPU:', error);
        }
        // Try Intel
        try {
            const [lspciOut] = this.utils.executeCommand('lspci', []);
            const intelLines = lspciOut.split('\n').filter(line => (line.includes('VGA') || line.includes('3D')) && line.includes('Intel'));
            if (intelLines.length > 0) {
                this.gpuType = 'intel';
                this.gpuCount = intelLines.length;
                console.log(`Intel GPU detected: ${this.gpuCount} GPU(s)`);
                return;
            }
        }
        catch (error) {
            console.log('Error checking for Intel GPU:', error);
        }
        // Fallback: count all VGA devices
        try {
            const [lspciOut] = this.utils.executeCommand('lspci', []);
            const gpuLines = lspciOut.split('\n').filter(line => line.includes('VGA') || line.includes('3D'));
            this.gpuCount = gpuLines.length;
            if (this.gpuCount > 0) {
                console.log(`Generic GPU(s) detected: ${this.gpuCount}`);
            }
        }
        catch (error) {
            console.log('Error detecting GPUs:', error);
        }
    }
    loadGpuInfo() {
        try {
            const gpuInfoArray = this.dataService.getGpuInfo();
            if (gpuInfoArray && gpuInfoArray.length > 0) {
                const gpuInfo = gpuInfoArray[0];
                if (gpuInfo.name) {
                    const label = gpuInfoArray.length > 1 ? `${gpuInfo.name} (${gpuInfoArray.length}x)` : gpuInfo.name;
                    this.gpuNameValue.set_label(label);
                }
                if (gpuInfo.driver) {
                    this.gpuDriverValue.set_label(gpuInfo.driver);
                }
                if (gpuInfo.memoryTotal) {
                    this.gpuMemoryTotalValue.set_label(gpuInfo.memoryTotal);
                }
            }
        }
        catch (error) {
            console.error('Error loading GPU info:', error);
            this.gpuNameValue.set_label('Unable to detect GPU');
        }
    }
    updateData() {
        try {
            if (this.hasNvidiaGpu) {
                try {
                    // Get GPU utilization (average if multiple GPUs)
                    const [utilizationOut] = this.utils.executeCommand('nvidia-smi', ['--query-gpu=utilization.gpu', '--format=csv,noheader,nounits']);
                    const utilizationValues = utilizationOut.trim().split('\n').map(v => parseFloat(v));
                    const avgUtilization = utilizationValues.reduce((a, b) => a + b, 0) / utilizationValues.length;
                    if (!isNaN(avgUtilization)) {
                        const label = this.gpuCount > 1 ?
                            `${avgUtilization.toFixed(1)}% (avg of ${this.gpuCount})` :
                            `${avgUtilization.toFixed(1)}%`;
                        this.gpuUsageValue.set_label(label);
                        this.usageHistory.push(avgUtilization);
                        if (this.usageHistory.length > this.maxHistoryPoints) {
                            this.usageHistory.shift();
                        }
                    }
                    // Get memory used (sum if multiple GPUs)
                    const [memoryUsedOut] = this.utils.executeCommand('nvidia-smi', ['--query-gpu=memory.used', '--format=csv,noheader']);
                    if (memoryUsedOut.trim()) {
                        const memValues = memoryUsedOut.trim().split('\n');
                        this.gpuMemoryUsedValue.set_label(memValues[0]);
                    }
                    // Get temperature (average if multiple GPUs)
                    const [tempOut] = this.utils.executeCommand('nvidia-smi', ['--query-gpu=temperature.gpu', '--format=csv,noheader,nounits']);
                    if (tempOut.trim()) {
                        const temps = tempOut.trim().split('\n').map(v => parseFloat(v));
                        const avgTemp = temps.reduce((a, b) => a + b, 0) / temps.length;
                        const label = this.gpuCount > 1 ?
                            `${avgTemp.toFixed(0)}°C (avg)` :
                            `${temps[0]}°C`;
                        this.gpuTemperatureValue.set_label(label);
                    }
                    // Get power usage (sum if multiple GPUs)
                    const [powerOut] = this.utils.executeCommand('nvidia-smi', ['--query-gpu=power.draw', '--format=csv,noheader']);
                    if (powerOut.trim()) {
                        const powers = powerOut.trim().split('\n');
                        this.gpuPowerValue.set_label(powers[0]);
                    }
                }
                catch (cmdError) {
                    console.error('nvidia-smi command failed, disabling GPU monitoring:', cmdError);
                    this.hasNvidiaGpu = false;
                    this.gpuUsageValue.set_label('N/A (nvidia-smi error)');
                    this.gpuMemoryUsedValue.set_label('N/A');
                    this.gpuTemperatureValue.set_label('N/A');
                    this.gpuPowerValue.set_label('N/A');
                }
            }
            else if (this.gpuType === 'amd') {
                // AMD GPUs: Try to read from sysfs
                try {
                    const [drmOut] = this.utils.executeCommand('ls', ['/sys/class/drm']);
                    const cards = drmOut.split('\n').filter(line => line.startsWith('card'));
                    if (cards.length > 0) {
                        // Try to read GPU usage from first card
                        try {
                            const [usageOut] = this.utils.executeCommand('cat', [`/sys/class/drm/${cards[0]}/device/gpu_busy_percent`]);
                            const usage = parseFloat(usageOut.trim());
                            if (!isNaN(usage)) {
                                this.gpuUsageValue.set_label(`${usage.toFixed(1)}%`);
                                this.usageHistory.push(usage);
                                if (this.usageHistory.length > this.maxHistoryPoints) {
                                    this.usageHistory.shift();
                                }
                            }
                            else {
                                throw new Error('Invalid usage value');
                            }
                        }
                        catch {
                            this.gpuUsageValue.set_label('N/A (install radeontop)');
                            this.usageHistory.push(0);
                            if (this.usageHistory.length > this.maxHistoryPoints) {
                                this.usageHistory.shift();
                            }
                        }
                    }
                }
                catch {
                    this.gpuUsageValue.set_label('N/A');
                }
                this.gpuMemoryUsedValue.set_label('N/A');
                this.gpuTemperatureValue.set_label('N/A');
                this.gpuPowerValue.set_label('N/A');
            }
            else if (this.gpuType === 'intel') {
                // Intel GPUs: Limited monitoring available
                this.gpuUsageValue.set_label('N/A (intel_gpu_top required)');
                this.gpuMemoryUsedValue.set_label('N/A');
                this.gpuTemperatureValue.set_label('N/A');
                this.gpuPowerValue.set_label('N/A');
                this.usageHistory.push(0);
                if (this.usageHistory.length > this.maxHistoryPoints) {
                    this.usageHistory.shift();
                }
            }
            else {
                this.gpuUsageValue.set_label('N/A');
                this.gpuMemoryUsedValue.set_label('N/A');
                this.gpuTemperatureValue.set_label('N/A');
                this.gpuPowerValue.set_label('N/A');
                this.usageHistory.push(0);
                if (this.usageHistory.length > this.maxHistoryPoints) {
                    this.usageHistory.shift();
                }
            }
            // Update top processes
            this.updateTopProcesses();
            // Redraw chart
            this.gpuChart.queue_draw();
        }
        catch (error) {
            console.error('Error updating GPU data:', error);
            this.usageHistory.push(0);
            if (this.usageHistory.length > this.maxHistoryPoints) {
                this.usageHistory.shift();
            }
            this.gpuChart.queue_draw();
        }
    }
    drawLineChart(cr, width, height) {
        const padding = 20;
        const chartWidth = width - 2 * padding;
        const chartHeight = height - 2 * padding;
        // Clear background with transparent color
        cr.setSourceRGBA(0, 0, 0, 0);
        cr.paint();
        // Draw grid lines
        cr.setSourceRGBA(0.8, 0.8, 0.8, 0.5);
        cr.setLineWidth(1);
        // Horizontal grid lines (0%, 25%, 50%, 75%, 100%)
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            cr.moveTo(padding, y);
            cr.lineTo(width - padding, y);
            cr.stroke();
        }
        // Draw axes
        cr.setSourceRGB(0.5, 0.5, 0.5);
        cr.setLineWidth(2);
        cr.moveTo(padding, padding);
        cr.lineTo(padding, height - padding);
        cr.lineTo(width - padding, height - padding);
        cr.stroke();
        // Draw data line
        if (this.usageHistory.length > 1) {
            cr.setSourceRGB(0.1, 0.8, 0.3);
            cr.setLineWidth(2);
            const pointSpacing = chartWidth / (this.maxHistoryPoints - 1);
            cr.moveTo(padding, height - padding - (this.usageHistory[0] / 100) * chartHeight);
            for (let i = 1; i < this.usageHistory.length; i++) {
                const x = padding + i * pointSpacing;
                const y = height - padding - (this.usageHistory[i] / 100) * chartHeight;
                cr.lineTo(x, y);
            }
            cr.stroke();
            // Fill area under the line
            cr.setSourceRGBA(0.1, 0.8, 0.3, 0.2);
            cr.lineTo(width - padding, height - padding);
            cr.lineTo(padding, height - padding);
            cr.closePath();
            cr.fill();
        }
        // Draw labels
        cr.setSourceRGB(0.3, 0.3, 0.3);
        cr.selectFontFace('Sans', 0, 0);
        cr.setFontSize(10);
        // Y-axis labels
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            const label = `${100 - (i * 25)}%`;
            cr.moveTo(5, y + 3);
            cr.showText(label);
        }
    }
    updateTopProcesses() {
        try {
            const allProcesses = this.processesService['loadProcesses']();
            const processInfoList = allProcesses.map(p => ({
                name: p.command.split(' ')[0].split('/').pop() || p.command,
                cpu: parseFloat(p.cpu) || 0,
                memory: parseFloat(p.rss) || 0
            }));
            this.topProcessesList.updateProcesses(processInfoList);
        }
        catch (error) {
            console.error('Error updating top processes:', error);
        }
    }
    getWidget() {
        return this.container;
    }
    destroy() {
        if (this.updateTimeoutId !== null) {
            GLib.source_remove(this.updateTimeoutId);
            this.updateTimeoutId = null;
        }
        if (this.topProcessesList) {
            this.topProcessesList.destroy();
        }
    }
}
 GpuComponent;
class MemoryComponent {
    constructor() {
        this.updateTimeoutId = null;
        this.usageHistory = [];
        this.maxHistoryPoints = 60;
        this.utils = UtilsService.instance;
        this.dataService = DataService.instance;
        this.processesService = ProcessesService.instance;
        const builder = Gtk.Builder.new();
        try {
            try {
                builder.add_from_file('/usr/share/com.obision.app.system/ui/memory.ui');
            }
            catch (e) {
                builder.add_from_file('data/ui/memory.ui');
            }
        }
        catch (e) {
            console.error('Could not load memory.ui:', e);
            this.container = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
                spacing: 12,
            });
            return;
        }
        this.container = builder.get_object('memory_container');
        this.memoryChart = builder.get_object('memory_chart');
        this.memoryUsageBar = builder.get_object('memory_usage_bar');
        this.memoryUsageTitle = builder.get_object('memory_usage_title');
        this.memoryUsagePercent = builder.get_object('memory_usage_percent');
        this.memoryTotalValue = builder.get_object('memory_total_value');
        this.memoryUsedValue = builder.get_object('memory_used_value');
        this.memoryFreeValue = builder.get_object('memory_free_value');
        this.memoryAvailableValue = builder.get_object('memory_available_value');
        this.memoryCachedValue = builder.get_object('memory_cached_value');
        this.memoryBuffersValue = builder.get_object('memory_buffers_value');
        this.memorySwapTotalValue = builder.get_object('memory_swap_total_value');
        this.memorySwapUsedValue = builder.get_object('memory_swap_used_value');
        this.memoryUsageValue = builder.get_object('memory_usage_value');
        this.memorySharedValue = builder.get_object('memory_shared_value');
        this.memorySlabValue = builder.get_object('memory_slab_value');
        this.memoryActiveValue = builder.get_object('memory_active_value');
        this.memoryInactiveValue = builder.get_object('memory_inactive_value');
        this.memoryDirtyValue = builder.get_object('memory_dirty_value');
        this.memoryWritebackValue = builder.get_object('memory_writeback_value');
        this.memoryMappedValue = builder.get_object('memory_mapped_value');
        this.memoryPageTablesValue = builder.get_object('memory_pagetables_value');
        this.memoryKernelStackValue = builder.get_object('memory_kernelstack_value');
        this.memorySwapCachedValue = builder.get_object('memory_swap_cached_value');
        // Create and add TopProcessesList
        this.topProcessesList = new TopProcessesList('memory', 8);
        const topProcessesContainer = builder.get_object('top_processes_container');
        if (topProcessesContainer) {
            topProcessesContainer.append(this.topProcessesList.getWidget());
        }
        // Initialize history with zeros
        for (let i = 0; i < this.maxHistoryPoints; i++) {
            this.usageHistory.push(0);
        }
        // Setup drawing function for chart
        this.memoryChart.set_draw_func((area, cr, width, height) => {
            this.drawLineChart(cr, width, height);
        });
        // Load memory info
        this.loadMemoryInfo();
        // Initial update
        this.updateData();
        // Update every 2 seconds
        this.updateTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2000, () => {
            this.updateData();
            return GLib.SOURCE_CONTINUE;
        });
    }
    loadMemoryInfo() {
        try {
            const memInfo = this.dataService.getMemoryInfo();
            if (memInfo.total) {
                this.memoryTotalValue.set_label(this.utils.formatBytes(memInfo.total * 1024));
            }
        }
        catch (error) {
            console.error('Error loading memory info:', error);
        }
    }
    updateData() {
        try {
            const memInfo = this.dataService.getMemoryInfo();
            const memTotal = memInfo.total || 0;
            const memFree = memInfo.free || 0;
            const memAvailable = memInfo.available || 0;
            const cached = memInfo.cached || 0;
            const buffers = memInfo.buffers || 0;
            const swapTotal = memInfo.swapTotal || 0;
            const swapFree = memInfo.swapFree || 0;
            const shared = memInfo.shared || 0;
            const slab = memInfo.slab || 0;
            const active = memInfo.active || 0;
            const inactive = memInfo.inactive || 0;
            const dirty = memInfo.dirty || 0;
            const writeback = memInfo.writeback || 0;
            const mapped = memInfo.mapped || 0;
            const pageTables = memInfo.pageTables || 0;
            const kernelStack = memInfo.kernelStack || 0;
            const swapCached = memInfo.swapCached || 0;
            // Calculate used memory
            const memUsed = memTotal - memFree - buffers - cached;
            const swapUsed = swapTotal - swapFree;
            // Calculate usage percentage
            const usagePercentage = memTotal > 0 ? (memUsed / memTotal) * 100 : 0;
            // Update labels
            this.memoryUsedValue.set_label(this.utils.formatBytes(memUsed * 1024));
            this.memoryFreeValue.set_label(this.utils.formatBytes(memFree * 1024));
            this.memoryAvailableValue.set_label(this.utils.formatBytes(memAvailable * 1024));
            this.memoryCachedValue.set_label(this.utils.formatBytes(cached * 1024));
            this.memoryBuffersValue.set_label(this.utils.formatBytes(buffers * 1024));
            this.memorySwapTotalValue.set_label(this.utils.formatBytes(swapTotal * 1024));
            this.memorySwapUsedValue.set_label(this.utils.formatBytes(swapUsed * 1024));
            this.memoryUsageValue.set_label(`${usagePercentage.toFixed(1)}%`);
            this.memorySharedValue.set_label(this.utils.formatBytes(shared * 1024));
            this.memorySlabValue.set_label(this.utils.formatBytes(slab * 1024));
            this.memoryActiveValue.set_label(this.utils.formatBytes(active * 1024));
            this.memoryInactiveValue.set_label(this.utils.formatBytes(inactive * 1024));
            this.memoryDirtyValue.set_label(this.utils.formatBytes(dirty * 1024));
            this.memoryWritebackValue.set_label(this.utils.formatBytes(writeback * 1024));
            this.memoryMappedValue.set_label(this.utils.formatBytes(mapped * 1024));
            this.memoryPageTablesValue.set_label(this.utils.formatBytes(pageTables * 1024));
            this.memoryKernelStackValue.set_label(this.utils.formatBytes(kernelStack * 1024));
            this.memorySwapCachedValue.set_label(this.utils.formatBytes(swapCached * 1024));
            // Update progress bar (0.0 to 1.0)
            if (this.memoryUsageBar) {
                this.memoryUsageBar.set_value(Math.min(1, Math.max(0, memTotal > 0 ? memUsed / memTotal : 0)));
            }
            // Update usage title and percent
            if (this.memoryUsageTitle) {
                this.memoryUsageTitle.set_label('Usage Actual');
            }
            if (this.memoryUsagePercent) {
                this.memoryUsagePercent.set_label(`${usagePercentage.toFixed(1)}%`);
            }
            // Update history
            this.usageHistory.push(usagePercentage);
            if (this.usageHistory.length > this.maxHistoryPoints) {
                this.usageHistory.shift();
            }
            // Update top processes
            this.updateTopProcesses();
            // Redraw chart
            this.memoryChart.queue_draw();
        }
        catch (error) {
            console.error('Error updating memory data:', error);
        }
    }
    updateTopProcesses() {
        try {
            const allProcesses = this.processesService['loadProcesses']();
            const processInfoList = allProcesses.map(p => ({
                name: p.command.split(' ')[0].split('/').pop() || p.command,
                cpu: parseFloat(p.cpu) || 0,
                memory: parseFloat(p.rss) || 0
            }));
            this.topProcessesList.updateProcesses(processInfoList);
        }
        catch (error) {
            console.error('Error updating top processes:', error);
        }
    }
    drawLineChart(cr, width, height) {
        const padding = 20;
        const chartWidth = width - 2 * padding;
        const chartHeight = height - 2 * padding;
        // Clear background with transparent color
        cr.setSourceRGBA(0, 0, 0, 0);
        cr.paint();
        // Draw grid lines
        cr.setSourceRGBA(0.8, 0.8, 0.8, 0.5);
        cr.setLineWidth(1);
        // Horizontal grid lines (0%, 25%, 50%, 75%, 100%)
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            cr.moveTo(padding, y);
            cr.lineTo(width - padding, y);
            cr.stroke();
        }
        // Draw axes
        cr.setSourceRGB(0.5, 0.5, 0.5);
        cr.setLineWidth(2);
        cr.moveTo(padding, padding);
        cr.lineTo(padding, height - padding);
        cr.lineTo(width - padding, height - padding);
        cr.stroke();
        // Draw data line
        if (this.usageHistory.length > 1) {
            cr.setSourceRGB(0.8, 0.3, 0.1);
            cr.setLineWidth(2);
            const pointSpacing = chartWidth / (this.maxHistoryPoints - 1);
            cr.moveTo(padding, height - padding - (this.usageHistory[0] / 100) * chartHeight);
            for (let i = 1; i < this.usageHistory.length; i++) {
                const x = padding + i * pointSpacing;
                const y = height - padding - (this.usageHistory[i] / 100) * chartHeight;
                cr.lineTo(x, y);
            }
            cr.stroke();
            // Fill area under the line
            cr.setSourceRGBA(0.8, 0.3, 0.1, 0.2);
            cr.lineTo(width - padding, height - padding);
            cr.lineTo(padding, height - padding);
            cr.closePath();
            cr.fill();
        }
        // Draw labels
        cr.setSourceRGB(0.3, 0.3, 0.3);
        cr.selectFontFace('Sans', 0, 0);
        cr.setFontSize(10);
        // Y-axis labels
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            const label = `${100 - (i * 25)}%`;
            cr.moveTo(5, y + 3);
            cr.showText(label);
        }
    }
    getWidget() {
        return this.container;
    }
    destroy() {
        if (this.updateTimeoutId !== null) {
            GLib.source_remove(this.updateTimeoutId);
            this.updateTimeoutId = null;
        }
        if (this.topProcessesList) {
            this.topProcessesList.destroy();
        }
    }
}
 MemoryComponent;
class DiskComponent {
    constructor() {
        this.updateTimeoutId = null;
        this.readHistory = [];
        this.writeHistory = [];
        this.previousStats = new Map();
        this.filesystemRows = new Map();
        this.totalBytesRead = 0;
        this.totalBytesWritten = 0;
        this.utils = UtilsService.instance;
        this.processesService = ProcessesService.instance;
        const builder = Gtk.Builder.new();
        try {
            builder.add_from_file('/usr/share/com.obision.app.system/ui/disk.ui');
        }
        catch (e) {
            builder.add_from_file('data/ui/disk.ui');
        }
        this.container = builder.get_object('disk_container');
        this.diskChart = builder.get_object('disk_chart');
        this.readSpeedLabel = builder.get_object('read_speed_label');
        this.writeSpeedLabel = builder.get_object('write_speed_label');
        this.totalReadLabel = builder.get_object('total_read_label');
        this.totalWriteLabel = builder.get_object('total_write_label');
        this.filesystemsGroup = builder.get_object('disk_filesystems_group');
        this.physicalDrivesGroup = builder.get_object('disk_physical_group');
        // Create and add TopProcessesList
        this.topProcessesList = new TopProcessesList('cpu', 8);
        const topProcessesContainer = builder.get_object('top_processes_container');
        if (topProcessesContainer) {
            topProcessesContainer.append(this.topProcessesList.getWidget());
        }
        // Initialize history arrays
        for (let i = 0; i < 60; i++) {
            this.readHistory.push(0);
            this.writeHistory.push(0);
        }
        this.setupChart();
        this.loadFilesystems();
        this.loadPhysicalDrives();
        this.updateData();
        // Update every 2 seconds
        this.updateTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2000, () => {
            this.updateData();
            return GLib.SOURCE_CONTINUE;
        });
    }
    setupChart() {
        this.diskChart.set_draw_func((area, cr, width, height) => {
            this.drawLineChart(cr, width, height);
        });
    }
    drawLineChart(cr, width, height) {
        const padding = 20;
        const chartWidth = width - 2 * padding;
        const chartHeight = height - 2 * padding;
        // Clear background with transparent color
        cr.setSourceRGBA(0, 0, 0, 0);
        cr.paint();
        // Find max value for scaling
        const allValues = [...this.readHistory, ...this.writeHistory];
        const maxValue = Math.max(...allValues, 10); // Minimum 10 MB/s for scale
        // Draw grid lines
        cr.setSourceRGBA(0.8, 0.8, 0.8, 0.5);
        cr.setLineWidth(1);
        // Horizontal grid lines
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            cr.moveTo(padding, y);
            cr.lineTo(width - padding, y);
            cr.stroke();
        }
        // Draw axes
        cr.setSourceRGB(0.5, 0.5, 0.5);
        cr.setLineWidth(2);
        cr.moveTo(padding, padding);
        cr.lineTo(padding, height - padding);
        cr.lineTo(width - padding, height - padding);
        cr.stroke();
        const pointSpacing = chartWidth / (this.readHistory.length - 1);
        // Draw read line (blue)
        if (this.readHistory.length > 1) {
            cr.setSourceRGB(0.2, 0.6, 1.0);
            cr.setLineWidth(2);
            cr.moveTo(padding, height - padding - (this.readHistory[0] / maxValue) * chartHeight);
            for (let i = 1; i < this.readHistory.length; i++) {
                const x = padding + i * pointSpacing;
                const y = height - padding - (this.readHistory[i] / maxValue) * chartHeight;
                cr.lineTo(x, y);
            }
            cr.stroke();
            // Fill area under read line
            cr.setSourceRGBA(0.2, 0.6, 1.0, 0.2);
            cr.lineTo(width - padding, height - padding);
            cr.lineTo(padding, height - padding);
            cr.closePath();
            cr.fill();
        }
        // Draw write line (green)
        if (this.writeHistory.length > 1) {
            cr.setSourceRGB(0.2, 0.8, 0.4);
            cr.setLineWidth(2);
            cr.moveTo(padding, height - padding - (this.writeHistory[0] / maxValue) * chartHeight);
            for (let i = 1; i < this.writeHistory.length; i++) {
                const x = padding + i * pointSpacing;
                const y = height - padding - (this.writeHistory[i] / maxValue) * chartHeight;
                cr.lineTo(x, y);
            }
            cr.stroke();
            // Fill area under write line
            cr.setSourceRGBA(0.2, 0.8, 0.4, 0.2);
            cr.lineTo(width - padding, height - padding);
            cr.lineTo(padding, height - padding);
            cr.closePath();
            cr.fill();
        }
        // Draw labels
        cr.setSourceRGB(0.3, 0.3, 0.3);
        cr.selectFontFace('Sans', 0, 0);
        cr.setFontSize(10);
        // Y-axis labels
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            const value = maxValue * (1 - i / 4);
            const label = `${value.toFixed(1)}`;
            cr.moveTo(5, y + 3);
            cr.showText(label);
        }
        // Legend
        cr.setFontSize(10);
        cr.selectFontFace('Sans', 0, 0); // Normal font
        // Read legend
        cr.setSourceRGB(0.2, 0.6, 1.0);
        cr.rectangle(width - 170, 7, 15, 10);
        cr.fill();
        cr.setSourceRGB(0.5, 0.5, 0.5);
        cr.setLineWidth(1);
        cr.rectangle(width - 170, 7, 15, 10);
        cr.stroke();
        cr.setSourceRGB(1, 1, 1);
        cr.moveTo(width - 150, 15);
        cr.showText('Read');
        // Write legend
        cr.setSourceRGB(0.2, 0.8, 0.4);
        cr.rectangle(width - 90, 7, 15, 10);
        cr.fill();
        cr.setSourceRGB(0.5, 0.5, 0.5);
        cr.setLineWidth(1);
        cr.rectangle(width - 90, 7, 15, 10);
        cr.stroke();
        cr.setSourceRGB(1, 1, 1);
        cr.moveTo(width - 70, 15);
        cr.showText('Write');
    }
    loadFilesystems() {
        try {
            const [stdout] = this.utils.executeCommand('df', ['-h', '--output=source,target,size,used,avail,pcent,fstype']);
            const lines = stdout.trim().split('\n').slice(1); // Skip header
            for (const line of lines) {
                const parts = line.trim().split(/\s+/);
                if (parts.length >= 7) {
                    const device = parts[0];
                    const mountPoint = parts[1];
                    const size = parts[2];
                    const used = parts[3];
                    const available = parts[4];
                    const usePercent = parts[5];
                    const fsType = parts[6];
                    // Skip special filesystems
                    if (device.startsWith('/dev/') || device.startsWith('/')) {
                        this.createFilesystemRow(device, mountPoint, size, used, available, usePercent, fsType);
                    }
                }
            }
        }
        catch (error) {
            console.error('Error loading filesystems:', error);
        }
    }
    createFilesystemRow(device, mountPoint, size, used, available, usePercent, fsType) {
        if (this.filesystemRows.has(device)) {
            return;
        }
        const expanderRow = new Adw.ExpanderRow({
            title: mountPoint,
            subtitle: device,
        });
        // Device type
        const typeRow = new InfoRow('Filesystem Type', fsType, 'Type of filesystem used').getWidget();
        expanderRow.add_row(typeRow);
        // Total size
        const sizeRow = new InfoRow('Total Size', size, 'Total capacity of the filesystem').getWidget();
        expanderRow.add_row(sizeRow);
        // Used space
        const usedRow = new InfoRow('Used Space', `${used} (${usePercent})`, 'Amount of space currently in use').getWidget();
        expanderRow.add_row(usedRow);
        // Available space
        const availRow = new InfoRow('Available Space', available, 'Free space available for use').getWidget();
        expanderRow.add_row(availRow);
        this.filesystemsGroup.add(expanderRow);
        this.filesystemRows.set(device, expanderRow);
    }
    updateData() {
        const stats = this.getDiskStats();
        let totalReadSpeed = 0;
        let totalWriteSpeed = 0;
        for (const [device, currentStats] of stats.entries()) {
            const previous = this.previousStats.get(device);
            if (previous) {
                const readDelta = currentStats.readBytes - previous.readBytes;
                const writeDelta = currentStats.writeBytes - previous.writeBytes;
                // Convert to MB/s (delta is in bytes over 2 seconds)
                const readSpeed = (readDelta / 2) / (1024 * 1024);
                const writeSpeed = (writeDelta / 2) / (1024 * 1024);
                totalReadSpeed += readSpeed;
                totalWriteSpeed += writeSpeed;
                this.totalBytesRead += readDelta;
                this.totalBytesWritten += writeDelta;
            }
            this.previousStats.set(device, currentStats);
        }
        // Update history
        this.readHistory.push(totalReadSpeed);
        this.writeHistory.push(totalWriteSpeed);
        if (this.readHistory.length > 60) {
            this.readHistory.shift();
            this.writeHistory.shift();
        }
        // Update labels
        this.readSpeedLabel.set_label(`${totalReadSpeed.toFixed(2)} MB/s`);
        this.writeSpeedLabel.set_label(`${totalWriteSpeed.toFixed(2)} MB/s`);
        this.totalReadLabel.set_label(this.utils.formatBytes(this.totalBytesRead));
        this.totalWriteLabel.set_label(this.utils.formatBytes(this.totalBytesWritten));
        // Update top processes
        this.updateTopProcesses();
        // Redraw chart
        this.diskChart.queue_draw();
    }
    updateTopProcesses() {
        try {
            const allProcesses = this.processesService['loadProcesses']();
            const processInfoList = allProcesses.map(p => ({
                name: p.command.split(' ')[0].split('/').pop() || p.command,
                cpu: parseFloat(p.cpu) || 0,
                memory: parseFloat(p.rss) || 0
            }));
            this.topProcessesList.updateProcesses(processInfoList);
        }
        catch (error) {
            console.error('Error updating top processes:', error);
        }
    }
    getDiskStats() {
        const stats = new Map();
        try {
            const [stdout] = this.utils.executeCommand('cat', ['/proc/diskstats']);
            const lines = stdout.trim().split('\n');
            for (const line of lines) {
                const parts = line.trim().split(/\s+/);
                if (parts.length >= 14) {
                    const device = parts[2];
                    // Only track physical disks (sda, nvme0n1, etc.)
                    if (device.match(/^(sd[a-z]|nvme\d+n\d+|vd[a-z])$/)) {
                        const readOps = parseInt(parts[3]);
                        const readSectors = parseInt(parts[5]);
                        const writeOps = parseInt(parts[7]);
                        const writeSectors = parseInt(parts[9]);
                        // Convert sectors to bytes (sector = 512 bytes)
                        const readBytes = readSectors * 512;
                        const writeBytes = writeSectors * 512;
                        stats.set(device, {
                            device,
                            readBytes,
                            writeBytes,
                            readOps,
                            writeOps,
                        });
                    }
                }
            }
        }
        catch (error) {
            console.error('Error reading disk stats:', error);
        }
        return stats;
    }
    loadPhysicalDrives() {
        try {
            // Get list of physical drives
            const [lsblkOut] = this.utils.executeCommand('lsblk', ['-d', '-o', 'NAME,MODEL,SIZE,ROTA,TYPE', '-n']);
            const lines = lsblkOut.trim().split('\n');
            for (const line of lines) {
                const parts = line.trim().split(/\s+/);
                if (parts.length >= 4) {
                    const device = parts[0];
                    const type = parts[parts.length - 1];
                    // Only show disk type (not partitions)
                    if (type === 'disk') {
                        const model = parts.slice(1, parts.length - 3).join(' ') || 'Unknown';
                        const size = parts[parts.length - 3];
                        const rota = parts[parts.length - 2];
                        const driveType = rota === '1' ? 'HDD' : 'SSD';
                        this.createPhysicalDriveRow(device, model, size, driveType);
                    }
                }
            }
        }
        catch (error) {
            console.error('Error loading physical drives:', error);
        }
    }
    createPhysicalDriveRow(device, model, size, driveType) {
        const expanderRow = new Adw.ExpanderRow({
            title: `/dev/${device}`,
            subtitle: model,
        });
        // Drive Type (HDD/SSD)
        const typeRow = new InfoRow('Type', driveType, 'Storage technology').getWidget();
        expanderRow.add_row(typeRow);
        // Size
        const sizeRow = new InfoRow('Size', size, 'Total drive capacity').getWidget();
        expanderRow.add_row(sizeRow);
        // Get additional information
        try {
            // Read/Write statistics
            const stats = this.previousStats.get(device);
            if (stats) {
                const totalReadRow = new InfoRow('Total Read Operations', stats.readOps.toString(), 'Number of read operations since boot').getWidget();
                expanderRow.add_row(totalReadRow);
                const totalWriteRow = new InfoRow('Total Write Operations', stats.writeOps.toString(), 'Number of write operations since boot').getWidget();
                expanderRow.add_row(totalWriteRow);
            }
            // Try to get SMART status
            try {
                const [smartOut] = this.utils.executeCommand('smartctl', ['-H', `/dev/${device}`]);
                const healthMatch = smartOut.match(/SMART overall-health self-assessment test result: (\w+)/);
                if (healthMatch) {
                    const healthRow = new InfoRow('SMART Health', healthMatch[1], 'Self-monitoring analysis and reporting technology').getWidget();
                    expanderRow.add_row(healthRow);
                }
            }
            catch {
                // SMART not available or requires sudo
            }
            // Get temperature if available
            try {
                const [tempOut] = this.utils.executeCommand('cat', [`/sys/block/${device}/device/hwmon/hwmon*/temp1_input`]);
                const temp = parseInt(tempOut.trim()) / 1000;
                if (!isNaN(temp)) {
                    const tempRow = new InfoRow('Temperature', `${temp.toFixed(1)}°C`, 'Current drive temperature').getWidget();
                    expanderRow.add_row(tempRow);
                }
            }
            catch {
                // Temperature not available
            }
        }
        catch (error) {
            console.error(`Error getting details for ${device}:`, error);
        }
        this.physicalDrivesGroup.add(expanderRow);
    }
    getWidget() {
        return this.container;
    }
    destroy() {
        if (this.updateTimeoutId !== null) {
            GLib.source_remove(this.updateTimeoutId);
        }
    }
}
 DiskComponent;
class NetworkComponent {
    constructor() {
        this.downloadHistory = [];
        this.uploadHistory = [];
        this.maxHistoryPoints = 60;
        this.interfaceRows = new Map();
        this.utils = UtilsService.instance;
        this.networkService = NetworkService.instance;
        this.processesService = ProcessesService.instance;
        const builder = Gtk.Builder.new();
        try {
            try {
                builder.add_from_file('/usr/share/com.obision.app.system/ui/network.ui');
            }
            catch (e) {
                builder.add_from_file('data/ui/network.ui');
            }
        }
        catch (e) {
            console.error('Could not load network.ui:', e);
            this.container = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
                spacing: 12,
            });
            return;
        }
        this.container = builder.get_object('network_container');
        this.networkChart = builder.get_object('network_chart');
        this.networkInterfacesGroup = builder.get_object('network_interfaces_group');
        this.networkDownloadSpeed = builder.get_object('network_download_speed');
        this.networkUploadSpeed = builder.get_object('network_upload_speed');
        this.networkTotalDownload = builder.get_object('network_total_download');
        this.networkTotalUpload = builder.get_object('network_total_upload');
        // Create and add TopProcessesList
        this.topProcessesList = new TopProcessesList('cpu', 8);
        const topProcessesContainer = builder.get_object('top_processes_container');
        if (topProcessesContainer) {
            topProcessesContainer.append(this.topProcessesList.getWidget());
        }
        // Initialize history with zeros
        for (let i = 0; i < this.maxHistoryPoints; i++) {
            this.downloadHistory.push(0);
            this.uploadHistory.push(0);
        }
        // Setup drawing function for chart
        this.networkChart.set_draw_func((area, cr, width, height) => {
            this.drawLineChart(cr, width, height);
        });
        // Subscribe to network service
        this.dataCallback = this.onDataUpdate.bind(this);
        this.networkService.subscribeToUpdates(this.dataCallback);
    }
    onDataUpdate(data) {
        // Calculate totals
        let totalRxBytes = 0;
        let totalTxBytes = 0;
        let totalDownloadSpeed = 0;
        let totalUploadSpeed = 0;
        for (const iface of data.interfaces) {
            if (iface.name === 'lo')
                continue;
            totalRxBytes += iface.rxBytes;
            totalTxBytes += iface.txBytes;
            // Parse speed strings to get bytes per second
            const rxMatch = iface.rxSpeed.match(/([\d.]+)\s*([KMGT]?B)/);
            const txMatch = iface.txSpeed.match(/([\d.]+)\s*([KMGT]?B)/);
            if (rxMatch) {
                const value = parseFloat(rxMatch[1]);
                const unit = rxMatch[2];
                const multiplier = unit === 'KB' ? 1024 : unit === 'MB' ? 1024 * 1024 : unit === 'GB' ? 1024 * 1024 * 1024 : 1;
                totalDownloadSpeed += value * multiplier;
            }
            if (txMatch) {
                const value = parseFloat(txMatch[1]);
                const unit = txMatch[2];
                const multiplier = unit === 'KB' ? 1024 : unit === 'MB' ? 1024 * 1024 : unit === 'GB' ? 1024 * 1024 * 1024 : 1;
                totalUploadSpeed += value * multiplier;
            }
        }
        // Update speed labels
        this.networkDownloadSpeed.set_label(this.formatSpeed(totalDownloadSpeed));
        this.networkUploadSpeed.set_label(this.formatSpeed(totalUploadSpeed));
        this.networkTotalDownload.set_label(this.utils.formatBytes(totalRxBytes));
        this.networkTotalUpload.set_label(this.utils.formatBytes(totalTxBytes));
        // Update history for chart (convert to Mbps)
        const downloadMbps = (totalDownloadSpeed * 8) / 1000000;
        const uploadMbps = (totalUploadSpeed * 8) / 1000000;
        this.downloadHistory.push(downloadMbps);
        if (this.downloadHistory.length > this.maxHistoryPoints) {
            this.downloadHistory.shift();
        }
        this.uploadHistory.push(uploadMbps);
        if (this.uploadHistory.length > this.maxHistoryPoints) {
            this.uploadHistory.shift();
        }
        // Update interface details
        for (const iface of data.interfaces) {
            if (iface.name === 'lo')
                continue;
            let expanderRow = this.interfaceRows.get(iface.name);
            if (!expanderRow) {
                expanderRow = this.createInterfaceRow(iface.name);
            }
            expanderRow.set_subtitle(`Status: ${iface.state}`);
            const ipLabel = expanderRow._ipLabel;
            if (ipLabel)
                ipLabel.set_label(iface.ipv4 || 'No IP');
            const macLabel = expanderRow._macLabel;
            if (macLabel)
                macLabel.set_label(iface.mac || '-');
            const speedLabel = expanderRow._speedLabel;
            if (speedLabel)
                speedLabel.set_label('-'); // Speed not in current interface
            const rxLabel = expanderRow._rxLabel;
            if (rxLabel)
                rxLabel.set_label(this.utils.formatBytes(iface.rxBytes));
            const txLabel = expanderRow._txLabel;
            if (txLabel)
                txLabel.set_label(this.utils.formatBytes(iface.txBytes));
        }
        // Update top processes
        this.updateTopProcesses();
        // Redraw chart
        this.networkChart.queue_draw();
    }
    updateTopProcesses() {
        try {
            const allProcesses = this.processesService['loadProcesses']();
            const processInfoList = allProcesses.map(p => ({
                name: p.command.split(' ')[0].split('/').pop() || p.command,
                cpu: parseFloat(p.cpu) || 0,
                memory: parseFloat(p.rss) || 0
            }));
            this.topProcessesList.updateProcesses(processInfoList);
        }
        catch (error) {
            console.error('Error updating top processes:', error);
        }
    }
    formatSpeed(bytesPerSecond) {
        if (bytesPerSecond < 1024) {
            return `${bytesPerSecond.toFixed(2)} B/s`;
        }
        else if (bytesPerSecond < 1024 * 1024) {
            return `${(bytesPerSecond / 1024).toFixed(2)} KB/s`;
        }
        else {
            return `${(bytesPerSecond / (1024 * 1024)).toFixed(2)} MB/s`;
        }
    }
    createInterfaceRow(interfaceName) {
        const expanderRow = new Adw.ExpanderRow({
            title: interfaceName,
            subtitle: 'Loading...',
        });
        // Create detail rows
        const ipRow = new InfoRow('IP Address', '-').getWidget();
        const ipLabel = ipRow.get_child().get_last_child();
        const macRow = new InfoRow('MAC Address', '-').getWidget();
        const macLabel = macRow.get_child().get_last_child();
        const speedRow = new InfoRow('Link Speed', '-', 'Maximum connection speed').getWidget();
        const speedLabel = speedRow.get_child().get_last_child();
        const rxRow = new InfoRow('Received', '-', 'Total bytes received').getWidget();
        const rxLabel = rxRow.get_child().get_last_child();
        const txRow = new InfoRow('Transmitted', '-', 'Total bytes transmitted').getWidget();
        const txLabel = txRow.get_child().get_last_child();
        expanderRow.add_row(ipRow);
        expanderRow.add_row(macRow);
        expanderRow.add_row(speedRow);
        expanderRow.add_row(rxRow);
        expanderRow.add_row(txRow);
        this.networkInterfacesGroup.add(expanderRow);
        this.interfaceRows.set(interfaceName, expanderRow);
        // Store labels for updates
        expanderRow._ipLabel = ipLabel;
        expanderRow._macLabel = macLabel;
        expanderRow._speedLabel = speedLabel;
        expanderRow._rxLabel = rxLabel;
        expanderRow._txLabel = txLabel;
        return expanderRow;
    }
    drawLineChart(cr, width, height) {
        const padding = 20;
        const chartWidth = width - 2 * padding;
        const chartHeight = height - 2 * padding;
        // Clear background with transparent color
        cr.setSourceRGBA(0, 0, 0, 0);
        cr.paint();
        // Draw grid lines
        cr.setSourceRGBA(0.8, 0.8, 0.8, 0.5);
        cr.setLineWidth(1);
        // Find max value for scaling
        const maxDownload = Math.max(...this.downloadHistory, 1);
        const maxUpload = Math.max(...this.uploadHistory, 1);
        const maxValue = Math.max(maxDownload, maxUpload);
        // Horizontal grid lines
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            cr.moveTo(padding, y);
            cr.lineTo(width - padding, y);
            cr.stroke();
        }
        // Draw axes
        cr.setSourceRGB(0.5, 0.5, 0.5);
        cr.setLineWidth(2);
        cr.moveTo(padding, padding);
        cr.lineTo(padding, height - padding);
        cr.lineTo(width - padding, height - padding);
        cr.stroke();
        const pointSpacing = chartWidth / (this.maxHistoryPoints - 1);
        // Draw download line (blue)
        if (this.downloadHistory.length > 1) {
            cr.setSourceRGB(0.2, 0.4, 0.8);
            cr.setLineWidth(2);
            cr.moveTo(padding, height - padding - (this.downloadHistory[0] / maxValue) * chartHeight);
            for (let i = 1; i < this.downloadHistory.length; i++) {
                const x = padding + i * pointSpacing;
                const y = height - padding - (this.downloadHistory[i] / maxValue) * chartHeight;
                cr.lineTo(x, y);
            }
            cr.stroke();
        }
        // Draw upload line (green)
        if (this.uploadHistory.length > 1) {
            cr.setSourceRGB(0.2, 0.7, 0.3);
            cr.setLineWidth(2);
            cr.moveTo(padding, height - padding - (this.uploadHistory[0] / maxValue) * chartHeight);
            for (let i = 1; i < this.uploadHistory.length; i++) {
                const x = padding + i * pointSpacing;
                const y = height - padding - (this.uploadHistory[i] / maxValue) * chartHeight;
                cr.lineTo(x, y);
            }
            cr.stroke();
        }
        // Draw labels
        cr.setSourceRGB(0.3, 0.3, 0.3);
        cr.selectFontFace('Sans', 0, 0);
        cr.setFontSize(10);
        // Y-axis labels (show max value at top)
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            const value = maxValue * (1 - i / 4);
            const label = `${value.toFixed(1)}`;
            cr.moveTo(5, y + 3);
            cr.showText(label);
        }
        // Legend
        cr.setFontSize(10);
        cr.selectFontFace('Sans', 0, 0); // Normal font
        // Download legend
        cr.setSourceRGB(0.2, 0.4, 0.8);
        cr.rectangle(width - 180, 7, 15, 10);
        cr.fill();
        cr.setSourceRGB(0.5, 0.5, 0.5);
        cr.setLineWidth(1);
        cr.rectangle(width - 180, 7, 15, 10);
        cr.stroke();
        cr.setSourceRGB(1, 1, 1);
        cr.moveTo(width - 160, 15);
        cr.showText('Download');
        // Upload legend
        cr.setSourceRGB(0.2, 0.7, 0.3);
        cr.rectangle(width - 85, 7, 15, 10);
        cr.fill();
        cr.setSourceRGB(0.5, 0.5, 0.5);
        cr.setLineWidth(1);
        cr.rectangle(width - 85, 7, 15, 10);
        cr.stroke();
        cr.setSourceRGB(1, 1, 1);
        cr.moveTo(width - 65, 15);
        cr.showText('Upload');
    }
    getWidget() {
        return this.container;
    }
    destroy() {
        this.networkService.unsubscribe(this.dataCallback);
        if (this.topProcessesList) {
            this.topProcessesList.destroy();
        }
    }
}
 NetworkComponent;
class SystemInfoComponent {
    constructor() {
        this.allExpanded = true;
        this.isAuthenticated = false;
        this.utils = UtilsService.instance;
        this.dataService = DataService.instance;
        const builder = Gtk.Builder.new();
        // Load UI file with fallback
        try {
            try {
                builder.add_from_file('/usr/share/com.obision.app.system/ui/system-info.ui');
            }
            catch (e) {
                builder.add_from_file('data/ui/system-info.ui');
            }
        }
        catch (e) {
            console.error('Could not load system-info.ui:', e);
            this.container = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
                spacing: 12,
            });
            return;
        }
        this.container = builder.get_object('system_info_container');
        this.scrolledWindow = builder.get_object('system_info_scrolled');
        this.authenticateButton = builder.get_object('authenticate_button');
        this.expandCollapseButton = builder.get_object('expand_collapse_button');
        this.exportButton = builder.get_object('export_button');
        // Setup button handlers
        this.setupButtons();
        // Create category expanders
        this.createCategoryExpanders();
        // Load system info
        this.loadSystemInfo();
        // Load software info
        this.loadSoftwareInfo();
    }
    setupButtons() {
        // Authenticate button
        this.authenticateButton.connect('clicked', () => {
            this.authenticate();
        });
        // Expand/Collapse button
        this.expandCollapseButton.connect('clicked', () => {
            this.allExpanded = !this.allExpanded;
            this.systemExpander.set_expanded(this.allExpanded);
            this.hardwareExpander.set_expanded(this.allExpanded);
            this.softwareExpander.set_expanded(this.allExpanded);
            this.networkExpander.set_expanded(this.allExpanded);
            // Update icon
            const iconName = this.allExpanded ? 'view-sort-descending-symbolic' : 'view-sort-ascending-symbolic';
            this.expandCollapseButton.set_icon_name(iconName);
        });
        // Export button
        this.exportButton.connect('clicked', () => {
            this.exportToJSON();
        });
    }
    authenticate() {
        try {
            // Try to authenticate using pkexec
            const [stdout, stderr] = this.utils.executeCommand('pkexec', ['true']);
            if (!stderr || (!stderr.includes('dismissed') && !stderr.includes('Error executing command'))) {
                this.isAuthenticated = true;
                this.authenticateButton.set_sensitive(false);
                this.authenticateButton.set_label('Authenticated');
                // Refresh all information
                this.refreshAllInfo();
            }
            else {
                // Authentication cancelled or failed
                console.log('Authentication cancelled by user');
            }
        }
        catch (e) {
            console.error('Authentication error:', e);
            const dialog = new Adw.MessageDialog({
                heading: 'Authentication Failed',
                body: 'Could not authenticate as root user.',
            });
            dialog.add_response('ok', 'OK');
            dialog.present();
        }
    }
    refreshAllInfo() {
        // Clear all existing rows from expanders
        this.clearExpanderRows(this.systemExpander);
        this.clearExpanderRows(this.hardwareExpander);
        this.clearExpanderRows(this.softwareExpander);
        this.clearExpanderRows(this.networkExpander);
        // Reload all information
        this.loadSystemInfo();
        this.loadNetworkInterfaces();
    }
    clearExpanderRows(expander) {
        // Remove all child rows
        let child = expander.get_first_child();
        while (child) {
            const next = child.get_next_sibling();
            if (child instanceof Adw.ActionRow || child instanceof Adw.ExpanderRow || child instanceof Adw.PreferencesGroup) {
                expander.remove(child);
            }
            child = next;
        }
    }
    createCategoryExpanders() {
        const contentBox = new Gtk.Box({
            orientation: Gtk.Orientation.VERTICAL,
            spacing: 0,
        });
        const listBox = new Gtk.ListBox({
            selection_mode: Gtk.SelectionMode.NONE,
        });
        listBox.add_css_class('boxed-list');
        // System expander
        this.systemExpander = new Adw.ExpanderRow({
            title: 'System',
            subtitle: 'Operating system and kernel information',
            icon_name: 'computer-symbolic',
            expanded: true,
        });
        listBox.append(this.systemExpander);
        // Hardware expander
        this.hardwareExpander = new Adw.ExpanderRow({
            title: 'Hardware',
            subtitle: 'CPU, GPU, memory, and storage information',
            icon_name: 'drive-harddisk-solidstate-symbolic',
            expanded: true,
        });
        listBox.append(this.hardwareExpander);
        // Software expander
        this.softwareExpander = new Adw.ExpanderRow({
            title: 'Software',
            subtitle: 'Installed packages and development tools',
            icon_name: 'application-x-executable-symbolic',
            expanded: true,
        });
        listBox.append(this.softwareExpander);
        // Network expander
        this.networkExpander = new Adw.ExpanderRow({
            title: 'Network',
            subtitle: 'Network interfaces and connectivity',
            icon_name: 'network-wired-symbolic',
            expanded: true,
        });
        listBox.append(this.networkExpander);
        // Load network interfaces
        this.loadNetworkInterfaces();
        contentBox.append(listBox);
        this.scrolledWindow.set_child(contentBox);
    }
    loadSystemInfo() {
        try {
            const [stdout] = this.utils.executeCommand('fastfetch', ['--format', 'json']);
            const data = JSON.parse(stdout);
            // Process each entry from fastfetch
            for (const item of data) {
                if (item.error || item.type === 'Separator' || item.type === 'Title') {
                    continue;
                }
                const result = item.result;
                let title = '';
                let subtitle = '';
                let icon = '';
                let category = 'system';
                switch (item.type) {
                    case 'OS':
                        title = 'OS';
                        subtitle = result.prettyName || result.name;
                        icon = 'computer-symbolic';
                        category = 'system';
                        break;
                    case 'Host':
                        title = 'Host';
                        subtitle = result.name;
                        icon = 'computer-symbolic';
                        category = 'system';
                        break;
                    case 'Kernel':
                        title = 'Kernel';
                        subtitle = `${result.name} ${result.release}`;
                        icon = 'emblem-system-symbolic';
                        category = 'system';
                        break;
                    case 'Uptime':
                        title = 'Uptime';
                        subtitle = this.formatUptime(result.uptime);
                        icon = 'document-open-recent-symbolic';
                        category = 'system';
                        break;
                    case 'Packages':
                        // Skip packages - shown in Software section instead
                        continue;
                    case 'Shell':
                        title = 'Shell';
                        subtitle = result.version ? `${result.exeName} ${result.version}` : result.exeName;
                        icon = 'utilities-terminal-symbolic';
                        category = 'system';
                        break;
                    case 'Display':
                        // Create PreferencesGroup for Display details
                        const displayGroup = new Adw.PreferencesGroup();
                        displayGroup.set_margin_start(40);
                        displayGroup.set_margin_end(12);
                        displayGroup.set_margin_top(6);
                        displayGroup.set_margin_bottom(6);
                        if (!result || result.length === 0) {
                            // No Display detected
                            const noDisplayRow = this.createDetailRow('Display', 'No display detected');
                            noDisplayRow.set_margin_start(40);
                            this.hardwareExpander.add_row(noDisplayRow);
                            continue;
                        }
                        if (result.length === 1) {
                            // Single Display - simple expander
                            const display = result[0];
                            const resolution = display.output.refreshRate
                                ? `${display.output.width}x${display.output.height}@${display.output.refreshRate} Hz`
                                : `${display.output.width}x${display.output.height}`;
                            const displayExpander = new Adw.ExpanderRow({
                                title: 'Display',
                                subtitle: `${display.name} - ${resolution}`,
                                icon_name: 'video-display-symbolic',
                                show_enable_switch: false,
                            });
                            // Add Display information rows
                            const nameRow = this.createDetailRow('Name', display.name);
                            displayExpander.add_row(nameRow);
                            const resolutionRow = this.createDetailRow('Resolution', `${display.output.width}x${display.output.height}`);
                            displayExpander.add_row(resolutionRow);
                            if (display.output.refreshRate) {
                                const refreshRow = this.createDetailRow('Refresh Rate', `${display.output.refreshRate} Hz`);
                                displayExpander.add_row(refreshRow);
                            }
                            if (display.type) {
                                const typeRow = this.createDetailRow('Type', display.type);
                                displayExpander.add_row(typeRow);
                            }
                            displayGroup.add(displayExpander);
                        }
                        else {
                            // Multiple Displays - main expander with sub-expanders
                            const mainDisplayExpander = new Adw.ExpanderRow({
                                title: 'Displays',
                                subtitle: `${result.length} display${result.length !== 1 ? 's' : ''} detected`,
                                icon_name: 'video-display-symbolic',
                                show_enable_switch: false,
                            });
                            result.forEach((display, index) => {
                                const resolution = display.output.refreshRate
                                    ? `${display.output.width}x${display.output.height}@${display.output.refreshRate} Hz`
                                    : `${display.output.width}x${display.output.height}`;
                                const displaySubExpander = new Adw.ExpanderRow({
                                    title: display.name,
                                    subtitle: resolution,
                                    show_enable_switch: false,
                                });
                                // Add Display information rows
                                const nameRow = this.createDetailRow('Name', display.name);
                                displaySubExpander.add_row(nameRow);
                                const resolutionRow = this.createDetailRow('Resolution', `${display.output.width}x${display.output.height}`);
                                displaySubExpander.add_row(resolutionRow);
                                if (display.output.refreshRate) {
                                    const refreshRow = this.createDetailRow('Refresh Rate', `${display.output.refreshRate} Hz`);
                                    displaySubExpander.add_row(refreshRow);
                                }
                                if (display.type) {
                                    const typeRow = this.createDetailRow('Type', display.type);
                                    displaySubExpander.add_row(typeRow);
                                }
                                mainDisplayExpander.add_row(displaySubExpander);
                            });
                            displayGroup.add(mainDisplayExpander);
                        }
                        const displayWrapper = new Gtk.Box({
                            orientation: Gtk.Orientation.VERTICAL,
                        });
                        displayWrapper.append(displayGroup);
                        const displayGroupRow = new Gtk.ListBoxRow();
                        displayGroupRow.set_child(displayWrapper);
                        displayGroupRow.set_activatable(false);
                        displayGroupRow.set_selectable(false);
                        this.hardwareExpander.add_row(displayGroupRow);
                        continue;
                    case 'DE':
                        title = 'Desktop Environment';
                        subtitle = result.version ? `${result.prettyName} ${result.version}` : result.prettyName || result.name;
                        icon = 'computer-symbolic';
                        category = 'system';
                        break;
                    case 'WM':
                        title = 'Window Manager';
                        subtitle = `${result.prettyName} (${result.protocolName})`;
                        icon = 'computer-apple-ipad-symbolic';
                        category = 'system';
                        break;
                    case 'Theme':
                        title = 'Theme';
                        subtitle = result.pretty || result.name;
                        icon = 'preferences-desktop-theme-symbolic';
                        category = 'system';
                        break;
                    case 'Icons':
                        title = 'Icons';
                        subtitle = result.pretty || result.name;
                        icon = 'preferences-desktop-icons-symbolic';
                        category = 'system';
                        break;
                    case 'Font':
                        if (result.pretty || result.name) {
                            title = 'Font';
                            subtitle = result.pretty || result.name;
                            icon = 'font-x-generic-symbolic';
                            category = 'system';
                        }
                        break;
                    case 'Cursor':
                        if (result.name) {
                            title = 'Cursor';
                            subtitle = result.size ? `${result.name} (${result.size}px)` : result.name;
                            icon = 'input-mouse-symbolic';
                            category = 'system';
                        }
                        break;
                    case 'CPU':
                        // Create PreferencesGroup for CPU details
                        const cpuGroup = new Adw.PreferencesGroup();
                        cpuGroup.set_margin_start(40);
                        cpuGroup.set_margin_end(12);
                        cpuGroup.set_margin_top(6);
                        cpuGroup.set_margin_bottom(6);
                        const cpuInfo = this.dataService.getCpuInfo();
                        const cpuExpander = new Adw.ExpanderRow({
                            title: 'CPU',
                            subtitle: `${cpuInfo.model}`,
                            icon_name: 'drive-harddisk-solidstate-symbolic',
                            show_enable_switch: false,
                        });
                        // Add CPU information rows
                        if (cpuInfo.model && cpuInfo.model !== 'Unknown') {
                            const modelRow = this.createDetailRow('Model', cpuInfo.model, 'CPU model name');
                            cpuExpander.add_row(modelRow);
                        }
                        if (cpuInfo.vendor && cpuInfo.vendor !== 'Unknown') {
                            const vendorRow = this.createDetailRow('Vendor', cpuInfo.vendor);
                            cpuExpander.add_row(vendorRow);
                        }
                        if (cpuInfo.architecture && cpuInfo.architecture !== 'Unknown') {
                            const archRow = this.createDetailRow('Architecture', cpuInfo.architecture);
                            cpuExpander.add_row(archRow);
                        }
                        if (cpuInfo.cores > 0) {
                            const coresRow = this.createDetailRow('Cores', cpuInfo.cores.toString(), 'Physical processor cores');
                            cpuExpander.add_row(coresRow);
                        }
                        if (cpuInfo.logicalCores > 0) {
                            const logicalCoresRow = this.createDetailRow('Logical Cores', cpuInfo.logicalCores.toString());
                            cpuExpander.add_row(logicalCoresRow);
                        }
                        if (cpuInfo.threads > 0) {
                            const threadsRow = this.createDetailRow('Threads', cpuInfo.threads.toString(), 'Threads per core');
                            cpuExpander.add_row(threadsRow);
                        }
                        if (cpuInfo.currentFrequency && cpuInfo.currentFrequency !== 'Unknown') {
                            const freqRow = this.createDetailRow('Frequency', cpuInfo.currentFrequency, 'Current operating frequency');
                            cpuExpander.add_row(freqRow);
                        }
                        if (cpuInfo.maxFrequency && cpuInfo.maxFrequency !== 'Unknown') {
                            const maxFreqRow = this.createDetailRow('Max Frequency', cpuInfo.maxFrequency);
                            cpuExpander.add_row(maxFreqRow);
                        }
                        if (cpuInfo.family && cpuInfo.family !== 'Unknown') {
                            const familyRow = this.createDetailRow('Family', cpuInfo.family);
                            cpuExpander.add_row(familyRow);
                        }
                        if (cpuInfo.modelId && cpuInfo.modelId !== 'Unknown') {
                            const modelIdRow = this.createDetailRow('Model ID', cpuInfo.modelId);
                            cpuExpander.add_row(modelIdRow);
                        }
                        if (cpuInfo.stepping && cpuInfo.stepping !== 'Unknown') {
                            const steppingRow = this.createDetailRow('Stepping', cpuInfo.stepping);
                            cpuExpander.add_row(steppingRow);
                        }
                        // Cache information
                        if (cpuInfo.l1dCache && cpuInfo.l1dCache !== 'Unknown') {
                            const l1dRow = this.createDetailRow('L1d Cache', cpuInfo.l1dCache);
                            cpuExpander.add_row(l1dRow);
                        }
                        if (cpuInfo.l1iCache && cpuInfo.l1iCache !== 'Unknown') {
                            const l1iRow = this.createDetailRow('L1i Cache', cpuInfo.l1iCache);
                            cpuExpander.add_row(l1iRow);
                        }
                        if (cpuInfo.l2Cache && cpuInfo.l2Cache !== 'Unknown') {
                            const l2Row = this.createDetailRow('L2 Cache', cpuInfo.l2Cache);
                            cpuExpander.add_row(l2Row);
                        }
                        if (cpuInfo.l3Cache && cpuInfo.l3Cache !== 'Unknown') {
                            const l3Row = this.createDetailRow('L3 Cache', cpuInfo.l3Cache);
                            cpuExpander.add_row(l3Row);
                        }
                        if (cpuInfo.virtualization && cpuInfo.virtualization !== 'Unknown') {
                            const virtRow = this.createDetailRow('Virtualization', cpuInfo.virtualization);
                            cpuExpander.add_row(virtRow);
                        }
                        if (cpuInfo.bogomips && cpuInfo.bogomips !== 'Unknown') {
                            const bogomipsRow = this.createDetailRow('BogoMIPS', cpuInfo.bogomips);
                            cpuExpander.add_row(bogomipsRow);
                        }
                        cpuGroup.add(cpuExpander);
                        // Wrap in a box and listboxrow to add to hardware expander
                        const cpuWrapper = new Gtk.Box({
                            orientation: Gtk.Orientation.VERTICAL,
                        });
                        cpuWrapper.append(cpuGroup);
                        const cpuGroupRow = new Gtk.ListBoxRow();
                        cpuGroupRow.set_child(cpuWrapper);
                        cpuGroupRow.set_activatable(false);
                        cpuGroupRow.set_selectable(false);
                        this.hardwareExpander.add_row(cpuGroupRow);
                        continue;
                    case 'GPU':
                        // Create PreferencesGroup for GPU details
                        const gpuGroup = new Adw.PreferencesGroup();
                        gpuGroup.set_margin_start(40);
                        gpuGroup.set_margin_end(12);
                        gpuGroup.set_margin_top(6);
                        gpuGroup.set_margin_bottom(6);
                        const gpuInfoList = this.dataService.getGpuInfo();
                        if (gpuInfoList.length === 0) {
                            // No GPU detected
                            const noGpuRow = this.createDetailRow('GPU', 'No GPU detected');
                            noGpuRow.set_margin_start(40);
                            this.hardwareExpander.add_row(noGpuRow);
                            continue;
                        }
                        if (gpuInfoList.length === 1) {
                            // Single GPU - simple expander
                            const gpuInfo = gpuInfoList[0];
                            const gpuExpander = new Adw.ExpanderRow({
                                title: 'GPU',
                                subtitle: gpuInfo.name,
                                icon_name: 'video-display-symbolic',
                                show_enable_switch: false,
                            });
                            // Add GPU information rows
                            if (gpuInfo.name) {
                                const nameRow = this.createDetailRow('Name', gpuInfo.name);
                                gpuExpander.add_row(nameRow);
                            }
                            if (gpuInfo.vendor && gpuInfo.vendor !== 'Unknown') {
                                const vendorRow = this.createDetailRow('Vendor', gpuInfo.vendor);
                                gpuExpander.add_row(vendorRow);
                            }
                            if (gpuInfo.driver && gpuInfo.driver !== 'Unknown') {
                                const driverRow = this.createDetailRow('Driver', gpuInfo.driver);
                                gpuExpander.add_row(driverRow);
                            }
                            if (gpuInfo.memoryTotal && gpuInfo.memoryTotal !== 'N/A') {
                                const memTotalRow = this.createDetailRow('Memory Total', gpuInfo.memoryTotal);
                                gpuExpander.add_row(memTotalRow);
                            }
                            if (gpuInfo.memoryUsed && gpuInfo.memoryUsed !== 'N/A') {
                                const memUsedRow = this.createDetailRow('Memory Used', gpuInfo.memoryUsed);
                                gpuExpander.add_row(memUsedRow);
                            }
                            if (gpuInfo.clockSpeed && gpuInfo.clockSpeed !== 'N/A') {
                                const clockRow = this.createDetailRow('Clock Speed', gpuInfo.clockSpeed);
                                gpuExpander.add_row(clockRow);
                            }
                            if (gpuInfo.temperature && gpuInfo.temperature !== 'N/A') {
                                const tempRow = this.createDetailRow('Temperature', gpuInfo.temperature);
                                gpuExpander.add_row(tempRow);
                            }
                            if (gpuInfo.power && gpuInfo.power !== 'N/A') {
                                const powerRow = this.createDetailRow('Power Draw', gpuInfo.power);
                                gpuExpander.add_row(powerRow);
                            }
                            if (gpuInfo.pciId && gpuInfo.pciId !== 'N/A') {
                                const pciRow = this.createDetailRow('PCI ID', gpuInfo.pciId);
                                gpuExpander.add_row(pciRow);
                            }
                            gpuGroup.add(gpuExpander);
                        }
                        else {
                            // Multiple GPUs - main expander with sub-expanders
                            const mainGpuExpander = new Adw.ExpanderRow({
                                title: 'GPUs',
                                subtitle: `${gpuInfoList.length} graphics card${gpuInfoList.length !== 1 ? 's' : ''} detected`,
                                icon_name: 'video-display-symbolic',
                                show_enable_switch: false,
                            });
                            gpuInfoList.forEach((gpuInfo, index) => {
                                const gpuSubExpander = new Adw.ExpanderRow({
                                    title: `GPU ${index + 1}`,
                                    subtitle: gpuInfo.name,
                                    show_enable_switch: false,
                                });
                                // Add GPU information rows
                                if (gpuInfo.name) {
                                    const nameRow = this.createDetailRow('Name', gpuInfo.name);
                                    gpuSubExpander.add_row(nameRow);
                                }
                                if (gpuInfo.vendor && gpuInfo.vendor !== 'Unknown') {
                                    const vendorRow = this.createDetailRow('Vendor', gpuInfo.vendor);
                                    gpuSubExpander.add_row(vendorRow);
                                }
                                if (gpuInfo.driver && gpuInfo.driver !== 'Unknown') {
                                    const driverRow = this.createDetailRow('Driver', gpuInfo.driver);
                                    gpuSubExpander.add_row(driverRow);
                                }
                                if (gpuInfo.memoryTotal && gpuInfo.memoryTotal !== 'N/A') {
                                    const memTotalRow = this.createDetailRow('Memory Total', gpuInfo.memoryTotal);
                                    gpuSubExpander.add_row(memTotalRow);
                                }
                                if (gpuInfo.memoryUsed && gpuInfo.memoryUsed !== 'N/A') {
                                    const memUsedRow = this.createDetailRow('Memory Used', gpuInfo.memoryUsed);
                                    gpuSubExpander.add_row(memUsedRow);
                                }
                                if (gpuInfo.clockSpeed && gpuInfo.clockSpeed !== 'N/A') {
                                    const clockRow = this.createDetailRow('Clock Speed', gpuInfo.clockSpeed);
                                    gpuSubExpander.add_row(clockRow);
                                }
                                if (gpuInfo.temperature && gpuInfo.temperature !== 'N/A') {
                                    const tempRow = this.createDetailRow('Temperature', gpuInfo.temperature);
                                    gpuSubExpander.add_row(tempRow);
                                }
                                if (gpuInfo.power && gpuInfo.power !== 'N/A') {
                                    const powerRow = this.createDetailRow('Power Draw', gpuInfo.power);
                                    gpuSubExpander.add_row(powerRow);
                                }
                                if (gpuInfo.pciId && gpuInfo.pciId !== 'N/A') {
                                    const pciRow = this.createDetailRow('PCI ID', gpuInfo.pciId);
                                    gpuSubExpander.add_row(pciRow);
                                }
                                mainGpuExpander.add_row(gpuSubExpander);
                            });
                            gpuGroup.add(mainGpuExpander);
                        }
                        // Wrap in a box and listboxrow to add to hardware expander
                        const gpuWrapper = new Gtk.Box({
                            orientation: Gtk.Orientation.VERTICAL,
                        });
                        gpuWrapper.append(gpuGroup);
                        const gpuGroupRow = new Gtk.ListBoxRow();
                        gpuGroupRow.set_child(gpuWrapper);
                        gpuGroupRow.set_activatable(false);
                        gpuGroupRow.set_selectable(false);
                        this.hardwareExpander.add_row(gpuGroupRow);
                        continue;
                    case 'Memory':
                        // Create PreferencesGroup for memory details
                        const memoryGroup = new Adw.PreferencesGroup();
                        memoryGroup.set_margin_start(40);
                        memoryGroup.set_margin_end(12);
                        memoryGroup.set_margin_top(6);
                        memoryGroup.set_margin_bottom(6);
                        const memPct = result.total !== undefined ? `${(result.used * 100 / result.total).toFixed(1)}%` : '';
                        const memoryExpander = new Adw.ExpanderRow({
                            title: 'Memory',
                            subtitle: `${this.utils.formatBytes(result.used || 0)} / ${this.utils.formatBytes(result.total || 0)} (${memPct})`,
                            icon_name: 'auth-sim-symbolic',
                            show_enable_switch: false,
                        });
                        // Get detailed memory information from DataService
                        try {
                            const memInfo = this.dataService.getMemoryInfo();
                            // Add basic information
                            if (memInfo.total > 0) {
                                const totalRow = this.createDetailRow('Total', this.utils.formatBytes(memInfo.total * 1024));
                                memoryExpander.add_row(totalRow);
                            }
                            if (memInfo.used > 0) {
                                const usedRow = this.createDetailRow('Used', this.utils.formatBytes(memInfo.used * 1024));
                                memoryExpander.add_row(usedRow);
                            }
                            if (memInfo.free > 0) {
                                const freeRow = this.createDetailRow('Free', this.utils.formatBytes(memInfo.free * 1024));
                                memoryExpander.add_row(freeRow);
                            }
                            if (memInfo.available > 0) {
                                const availableRow = this.createDetailRow('Available', this.utils.formatBytes(memInfo.available * 1024));
                                memoryExpander.add_row(availableRow);
                            }
                            if (memInfo.buffers > 0) {
                                const buffersRow = this.createDetailRow('Buffers', this.utils.formatBytes(memInfo.buffers * 1024));
                                memoryExpander.add_row(buffersRow);
                            }
                            if (memInfo.cached > 0) {
                                const cachedRow = this.createDetailRow('Cached', this.utils.formatBytes(memInfo.cached * 1024));
                                memoryExpander.add_row(cachedRow);
                            }
                            if (memInfo.shared > 0) {
                                const sharedRow = this.createDetailRow('Shared', this.utils.formatBytes(memInfo.shared * 1024), 'Shared memory between processes');
                                memoryExpander.add_row(sharedRow);
                            }
                            if (memInfo.slab > 0) {
                                const slabRow = this.createDetailRow('Slab', this.utils.formatBytes(memInfo.slab * 1024), 'Kernel slab allocator cache');
                                memoryExpander.add_row(slabRow);
                            }
                            if (memInfo.active > 0) {
                                const activeRow = this.createDetailRow('Active', this.utils.formatBytes(memInfo.active * 1024), 'Recently accessed memory');
                                memoryExpander.add_row(activeRow);
                            }
                            if (memInfo.inactive > 0) {
                                const inactiveRow = this.createDetailRow('Inactive', this.utils.formatBytes(memInfo.inactive * 1024), 'Not recently accessed memory');
                                memoryExpander.add_row(inactiveRow);
                            }
                            if (memInfo.dirty > 0) {
                                const dirtyRow = this.createDetailRow('Dirty', this.utils.formatBytes(memInfo.dirty * 1024), 'Modified pages waiting to be written');
                                memoryExpander.add_row(dirtyRow);
                            }
                            if (memInfo.writeback > 0) {
                                const writebackRow = this.createDetailRow('Writeback', this.utils.formatBytes(memInfo.writeback * 1024), 'Memory being written to disk');
                                memoryExpander.add_row(writebackRow);
                            }
                            if (memInfo.mapped > 0) {
                                const mappedRow = this.createDetailRow('Mapped', this.utils.formatBytes(memInfo.mapped * 1024), 'Memory-mapped files');
                                memoryExpander.add_row(mappedRow);
                            }
                            if (memInfo.pageTables > 0) {
                                const pageTablesRow = this.createDetailRow('Page Tables', this.utils.formatBytes(memInfo.pageTables * 1024), 'Memory used by page tables');
                                memoryExpander.add_row(pageTablesRow);
                            }
                            if (memInfo.kernelStack > 0) {
                                const kernelStackRow = this.createDetailRow('Kernel Stack', this.utils.formatBytes(memInfo.kernelStack * 1024), 'Memory used by kernel stacks');
                                memoryExpander.add_row(kernelStackRow);
                            }
                            // Add swap information
                            if (memInfo.swapTotal > 0) {
                                const swapTotalRow = this.createDetailRow('Swap Total', this.utils.formatBytes(memInfo.swapTotal * 1024));
                                memoryExpander.add_row(swapTotalRow);
                                const swapUsedRow = this.createDetailRow('Swap Used', this.utils.formatBytes(memInfo.swapUsed * 1024));
                                memoryExpander.add_row(swapUsedRow);
                                if (memInfo.swapCached > 0) {
                                    const swapCachedRow = this.createDetailRow('Swap Cached', this.utils.formatBytes(memInfo.swapCached * 1024), 'Swap pages cached in memory');
                                    memoryExpander.add_row(swapCachedRow);
                                }
                            }
                        }
                        catch (error) {
                            console.error('Error reading /proc/meminfo:', error);
                            // Fallback to fastfetch data if /proc/meminfo fails
                            if (result.used !== undefined) {
                                const usedRow = this.createDetailRow('Used', this.utils.formatBytes(result.used));
                                memoryExpander.add_row(usedRow);
                            }
                            if (result.total !== undefined && result.used !== undefined) {
                                const freeRow = this.createDetailRow('Available', this.utils.formatBytes(result.total - result.used));
                                memoryExpander.add_row(freeRow);
                            }
                            if (result.total !== undefined) {
                                const totalRow = this.createDetailRow('Total', this.utils.formatBytes(result.total));
                                memoryExpander.add_row(totalRow);
                            }
                        }
                        memoryGroup.add(memoryExpander);
                        // Wrap in a box and listboxrow to add to hardware expander
                        const memoryWrapper = new Gtk.Box({
                            orientation: Gtk.Orientation.VERTICAL,
                        });
                        memoryWrapper.append(memoryGroup);
                        const memoryGroupRow = new Gtk.ListBoxRow();
                        memoryGroupRow.set_child(memoryWrapper);
                        memoryGroupRow.set_activatable(false);
                        memoryGroupRow.set_selectable(false);
                        this.hardwareExpander.add_row(memoryGroupRow);
                        continue;
                    case 'Swap':
                        // Store swap data to add to mount points later
                        this.swapData = result;
                        continue;
                    case 'Disk':
                        // Create PreferencesGroup for disks
                        const disksGroup = new Adw.PreferencesGroup();
                        disksGroup.set_margin_start(40);
                        disksGroup.set_margin_end(12);
                        disksGroup.set_margin_top(6);
                        disksGroup.set_margin_bottom(6);
                        // Calculate total disk space
                        let totalDiskSpace = 0;
                        let totalDiskUsed = 0;
                        result.forEach((mount) => {
                            if (mount.bytes && mount.bytes.total) {
                                totalDiskSpace += mount.bytes.total;
                                totalDiskUsed += mount.bytes.used || 0;
                            }
                        });
                        const diskPct = totalDiskSpace > 0 ? `${(totalDiskUsed * 100 / totalDiskSpace).toFixed(1)}%` : '';
                        const disksExpander = new Adw.ExpanderRow({
                            title: 'Disks',
                            subtitle: `${this.utils.formatBytes(totalDiskUsed)} / ${this.utils.formatBytes(totalDiskSpace)} (${diskPct})`,
                            icon_name: 'drive-harddisk-symbolic',
                            show_enable_switch: false,
                        });
                        // Check if swap exists
                        const swapData = this.swapData;
                        const hasSwap = swapData && swapData.total > 0;
                        const mountCount = result.length + (hasSwap ? 1 : 0);
                        // Create nested mount points expander
                        const mountExpander = new Adw.ExpanderRow({
                            title: 'Mount points',
                            subtitle: `${mountCount} mount point${mountCount !== 1 ? 's' : ''}`,
                            icon_name: 'folder-symbolic',
                            show_enable_switch: false,
                        });
                        result.forEach((mount) => {
                            const mountPct = mount.bytes.total > 0 ? `(${(mount.bytes.used * 100 / mount.bytes.total).toFixed(1)}%)` : '';
                            const mountRow = this.createDetailRow(mount.mountpoint, `${this.utils.formatBytes(mount.bytes.used || 0)} / ${this.utils.formatBytes(mount.bytes.total || 0)} ${mountPct}`);
                            mountExpander.add_row(mountRow);
                        });
                        // Add swap if available and total > 0 (inside mount points)
                        if (hasSwap) {
                            const swapPct = `(${(swapData.used * 100 / swapData.total).toFixed(1)}%)`;
                            const swapSubtitle = `${this.utils.formatBytes(swapData.used || 0)} / ${this.utils.formatBytes(swapData.total || 0)} ${swapPct}`;
                            const swapRow = this.createDetailRow('Swap', swapSubtitle, 'Virtual memory on disk');
                            mountExpander.add_row(swapRow);
                        }
                        // Add mount points expander to disks expander
                        disksExpander.add_row(mountExpander);
                        // Create physical drives expander
                        const physicalDrivesExpander = new Adw.ExpanderRow({
                            title: 'Physical drives',
                            subtitle: 'Hardware disk information',
                            icon_name: 'drive-harddisk-symbolic',
                            show_enable_switch: false,
                        });
                        // Get list of physical drives
                        try {
                            const [lsblkOut] = this.utils.executeCommand('lsblk', ['-d', '-o', 'NAME,MODEL,SIZE,ROTA,TYPE', '-n']);
                            const lines = lsblkOut.trim().split('\n');
                            let driveCount = 0;
                            for (const line of lines) {
                                const parts = line.trim().split(/\s+/);
                                if (parts.length >= 4) {
                                    const device = parts[0];
                                    const type = parts[parts.length - 1];
                                    // Only show disk type (not partitions)
                                    if (type === 'disk') {
                                        driveCount++;
                                        const model = parts.slice(1, parts.length - 3).join(' ') || 'Unknown';
                                        const size = parts[parts.length - 3];
                                        const rota = parts[parts.length - 2];
                                        const driveType = rota === '1' ? 'HDD' : 'SSD';
                                        // Create expander for each drive
                                        const driveExpander = new Adw.ExpanderRow({
                                            title: `/dev/${device}`,
                                            subtitle: `${model} - ${size}`,
                                            show_enable_switch: false,
                                        });
                                        // Drive Type (HDD/SSD)
                                        const typeRow = this.createDetailRow('Type', driveType, 'Storage technology');
                                        driveExpander.add_row(typeRow);
                                        // Model
                                        const modelRow = this.createDetailRow('Model', model, 'Disk model identifier');
                                        driveExpander.add_row(modelRow);
                                        // Size
                                        const sizeRow = this.createDetailRow('Size', size, 'Total capacity');
                                        driveExpander.add_row(sizeRow);
                                        // Get partitions for this drive
                                        try {
                                            const [partOut] = this.utils.executeCommand('lsblk', ['-o', 'NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT', '-n', `/dev/${device}`]);
                                            const partLines = partOut.trim().split('\n');
                                            if (partLines.length > 1) {
                                                const partitionsExpander = new Adw.ExpanderRow({
                                                    title: 'Partitions',
                                                    subtitle: `${partLines.length - 1} partition${partLines.length - 1 !== 1 ? 's' : ''}`,
                                                    show_enable_switch: false,
                                                });
                                                for (let i = 1; i < partLines.length; i++) {
                                                    const partLine = partLines[i].trim();
                                                    const partParts = partLine.split(/\s+/);
                                                    if (partParts.length >= 3 && partParts[2] === 'part') {
                                                        const partName = partParts[0].replace(/[├─└─│\s]/g, '');
                                                        const partSize = partParts[1];
                                                        const fsType = partParts[3] || '-';
                                                        const mountPoint = partParts.slice(4).join(' ') || 'Not mounted';
                                                        const partRow = this.createDetailRow(`/dev/${partName}`, `${partSize} • ${fsType} • ${mountPoint}`);
                                                        partitionsExpander.add_row(partRow);
                                                    }
                                                }
                                                driveExpander.add_row(partitionsExpander);
                                            }
                                        }
                                        catch (e) {
                                            console.error(`Error getting partitions for ${device}:`, e);
                                        }
                                        // Try to get temperature if available
                                        try {
                                            const [tempOut] = this.utils.executeCommand('bash', ['-c', `cat /sys/block/${device}/device/hwmon/hwmon*/temp1_input 2>/dev/null || echo ""`]);
                                            if (tempOut && tempOut.trim()) {
                                                const temp = parseInt(tempOut.trim()) / 1000;
                                                if (!isNaN(temp)) {
                                                    const tempRow = this.createDetailRow('Temperature', `${temp.toFixed(1)}°C`, 'Current drive temperature');
                                                    driveExpander.add_row(tempRow);
                                                }
                                            }
                                        }
                                        catch {
                                            // Temperature not available
                                        }
                                        physicalDrivesExpander.add_row(driveExpander);
                                    }
                                }
                            }
                            // Update subtitle with drive count
                            if (driveCount > 0) {
                                physicalDrivesExpander.set_subtitle(`${driveCount} physical drive${driveCount !== 1 ? 's' : ''} detected`);
                            }
                        }
                        catch (error) {
                            console.error('Error loading physical drives:', error);
                        }
                        // Add physical drives expander to disks expander
                        disksExpander.add_row(physicalDrivesExpander);
                        disksGroup.add(disksExpander);
                        // Wrap in a box and listboxrow to add to hardware expander
                        const disksWrapper = new Gtk.Box({
                            orientation: Gtk.Orientation.VERTICAL,
                        });
                        disksWrapper.append(disksGroup);
                        const disksGroupRow = new Gtk.ListBoxRow();
                        disksGroupRow.set_child(disksWrapper);
                        disksGroupRow.set_activatable(false);
                        disksGroupRow.set_selectable(false);
                        this.hardwareExpander.add_row(disksGroupRow);
                        continue;
                    case 'LocalIP':
                    case 'PublicIP':
                    case 'WiFi':
                        // Skip - network interfaces are loaded separately
                        continue;
                    case 'Battery':
                        // Check if battery exists using DataService
                        if (!this.dataService.hasBattery()) {
                            continue;
                        }
                        // Battery data comes as an array, take the first battery  
                        const batteryArray = Array.isArray(result) ? result : [result];
                        if (batteryArray && batteryArray.length > 0) {
                            const battery = batteryArray[0];
                            const battPct = battery.capacity !== undefined ? `${battery.capacity.toFixed(1)}%` : 'N/A';
                            const batteryGroup = new Adw.PreferencesGroup();
                            batteryGroup.set_margin_start(40);
                            batteryGroup.set_margin_end(12);
                            batteryGroup.set_margin_top(6);
                            batteryGroup.set_margin_bottom(6);
                            const batteryExpander = new Adw.ExpanderRow({
                                title: 'Battery',
                                subtitle: `${battPct} - ${battery.status || 'Unknown'}`,
                                icon_name: battery.status && battery.status.includes('Charging') ? 'battery-full-charging-symbolic' : 'battery-symbolic',
                                show_enable_switch: false,
                            });
                            // Add battery details
                            if (battery.modelName) {
                                const modelRow = this.createDetailRow('Model', battery.modelName);
                                batteryExpander.add_row(modelRow);
                            }
                            if (battery.manufacturer) {
                                const mfgRow = this.createDetailRow('Manufacturer', battery.manufacturer);
                                batteryExpander.add_row(mfgRow);
                            }
                            if (battery.capacity !== undefined) {
                                const capacityRow = this.createDetailRow('Capacity', `${battery.capacity.toFixed(1)}%`, 'Current battery health');
                                batteryExpander.add_row(capacityRow);
                            }
                            if (battery.status) {
                                const statusRow = this.createDetailRow('Status', battery.status, 'Charging state');
                                batteryExpander.add_row(statusRow);
                            }
                            if (battery.technology) {
                                const techRow = this.createDetailRow('Technology', battery.technology, 'Battery chemistry type');
                                batteryExpander.add_row(techRow);
                            }
                            if (battery.cycleCount !== undefined) {
                                const cycleRow = this.createDetailRow('Cycle Count', battery.cycleCount.toString(), 'Number of charge cycles');
                                batteryExpander.add_row(cycleRow);
                            }
                            if (battery.voltage !== undefined) {
                                const voltageRow = this.createDetailRow('Voltage', `${battery.voltage.toFixed(2)} V`, 'Current voltage');
                                batteryExpander.add_row(voltageRow);
                            }
                            if (battery.temperature !== undefined && battery.temperature !== null) {
                                const tempRow = this.createDetailRow('Temperature', `${battery.temperature.toFixed(1)} °C`, 'Current temperature');
                                batteryExpander.add_row(tempRow);
                            }
                            batteryGroup.add(batteryExpander);
                            const batteryWrapper = new Gtk.Box({
                                orientation: Gtk.Orientation.VERTICAL,
                            });
                            batteryWrapper.append(batteryGroup);
                            const batteryGroupRow = new Gtk.ListBoxRow();
                            batteryGroupRow.set_child(batteryWrapper);
                            batteryGroupRow.set_activatable(false);
                            batteryGroupRow.set_selectable(false);
                            this.hardwareExpander.add_row(batteryGroupRow);
                        }
                        continue;
                    case 'Locale':
                        title = 'Locale';
                        subtitle = result.result;
                        icon = 'preferences-desktop-locale-symbolic';
                        category = 'system';
                        break;
                    default:
                        continue;
                }
                if (title && subtitle) {
                    this.addInfoRow(title, subtitle, icon, category);
                }
            }
        }
        catch (e) {
            console.error('Error loading system info:', e);
        }
    }
    addInfoRow(title, subtitle, iconName, category) {
        const description = this.getDescriptionForField(title);
        const infoRow = new InfoRow(title, subtitle, description);
        const row = infoRow.getWidget();
        // Add to appropriate category expander
        switch (category) {
            case 'system':
                this.systemExpander.add_row(row);
                break;
            case 'hardware':
                this.hardwareExpander.add_row(row);
                break;
            case 'software':
                this.softwareExpander.add_row(row);
                break;
            case 'network':
                this.networkExpander.add_row(row);
                break;
        }
    }
    getDescriptionForField(field) {
        const descriptions = {
            // System
            'OS': 'Operating system name and version',
            'Host': 'Computer manufacturer and model',
            'Kernel': 'Operating system kernel version',
            'Uptime': 'Time since last system boot',
            'Shell': 'Default command line interpreter',
            'Resolution': 'Current screen resolution',
            'DE': 'Desktop environment',
            'WM': 'Window manager',
            'WM Theme': 'Window manager theme',
            'Theme': 'GTK theme',
            'Icons': 'Icon theme',
            'Terminal': 'Default terminal emulator',
            'Terminal Font': 'Terminal font family',
            'Locale': 'System language and region',
            'Users': 'Number of user accounts',
            'Date': 'Current system date',
            'Datetime': 'Current date and time',
            // Hardware - Display
            'Name': 'Device identifier or model name',
            'Type': 'Connection type or category',
            'Refresh Rate': 'Screen refresh frequency',
            // Hardware - CPU
            'CPU': 'Central processing unit model',
            'Model': 'Processor model name',
            'Vendor': 'Manufacturer or brand',
            'Architecture': 'Processor architecture type',
            'Cores': 'Physical processor cores',
            'Logical Cores': 'Logical processors with hyperthreading',
            'Threads': 'Simultaneous execution threads',
            'Frequency': 'Current operating frequency',
            'Max Frequency': 'Maximum clock speed',
            'Family': 'Processor family identifier',
            'Model ID': 'Specific model identifier',
            'Stepping': 'CPU revision number',
            'L1d Cache': 'Level 1 data cache',
            'L1i Cache': 'Level 1 instruction cache',
            'L2 Cache': 'Level 2 cache',
            'L3 Cache': 'Level 3 cache',
            'Virtualization': 'Hardware virtualization support',
            'BogoMIPS': 'Performance measurement',
            // Hardware - GPU
            'GPU': 'Graphics processing unit model',
            'Driver': 'Graphics driver version',
            'Memory Total': 'Total graphics memory',
            'Memory Used': 'Currently used graphics memory',
            'Clock Speed': 'GPU operating frequency',
            'Temperature': 'Current GPU temperature',
            'Power Draw': 'Current power consumption',
            'PCI ID': 'PCI device identifier',
            // Hardware - Memory
            'Memory': 'Total system memory (RAM)',
            'Total': 'Total capacity',
            'Used': 'Currently in use',
            'Free': 'Available for use',
            'Available': 'Available including cache',
            'Buffers': 'Buffer memory',
            'Cached': 'Cache memory',
            'Swap Total': 'Total swap space',
            'Swap Used': 'Currently used swap',
            'Swap Free': 'Available swap space',
            // Hardware - Disk
            'Disk': 'Storage capacity and usage',
            'Filesystem': 'File system type',
            'Size': 'Total storage size',
            'Used Space': 'Currently used space',
            'Use Percentage': 'Percentage used',
            'Mounted On': 'Mount point location',
            // Hardware - Battery
            'Battery': 'Battery status and capacity',
            'Status': 'Current charging status',
            'Capacity': 'Battery health percentage',
            'Energy': 'Current energy level',
            // Network
            'Local IP': 'Internal network address',
            'Public IP': 'External network address',
            'Interface': 'Network interface name',
            'State': 'Connection status',
            'MTU': 'Maximum transmission unit',
            'MAC Address': 'Hardware address',
            'IPv4 Address': 'IPv4 network address',
            'IPv6 Address': 'IPv6 network address',
            // Media
            'Brightness': 'Current screen brightness',
            'Volume': 'System audio volume level',
            'Media': 'Currently playing media',
            'Player': 'Active media player',
            'Song': 'Current song or track',
        };
        return descriptions[field] || 'System information';
    }
    createDetailRow(title, value, description) {
        const descText = description || this.getDescriptionForField(title);
        const infoRow = new InfoRow(title, value, descText);
        return infoRow.getWidget();
    }
    loadNetworkInterfaces() {
        try {
            const [stdout, stderr] = this.utils.executeCommand('ip', ['addr', 'show']);
            if (stderr && stderr.trim()) {
                console.error('Error executing ip command:', stderr);
            }
            // Parse ip addr output
            const interfaces = this.parseIpAddr(stdout);
            console.log('Parsed interfaces:', interfaces.length);
            if (interfaces.length === 0) {
                const noIfaceRow = this.createDetailRow('No interfaces found', 'Could not detect network interfaces');
                noIfaceRow.set_margin_start(40);
                this.networkExpander.add_row(noIfaceRow);
                return;
            }
            // Create a PreferencesGroup for interfaces with a simple label header
            const interfacesGroup = new Adw.PreferencesGroup();
            interfacesGroup.set_title('Interfaces');
            interfacesGroup.set_description('');
            interfacesGroup.set_margin_start(40);
            interfacesGroup.set_margin_end(12);
            interfacesGroup.set_margin_top(6);
            interfacesGroup.set_margin_bottom(6);
            // Add expander for each interface
            for (const iface of interfaces) {
                console.log('Adding interface:', iface.name);
                const ifaceExpander = new Adw.ExpanderRow({
                    title: iface.name,
                    icon_name: this.getInterfaceIcon(iface.name),
                    show_enable_switch: false,
                });
                interfacesGroup.add(ifaceExpander);
                // Add state as first detail
                if (iface.state) {
                    const stateRow = this.createDetailRow('State', iface.state, 'Connection status');
                    ifaceExpander.add_row(stateRow);
                }
                // Add interface details
                if (iface.ipv4) {
                    const ipRow = this.createDetailRow('IPv4 Address', iface.ipv4);
                    ifaceExpander.add_row(ipRow);
                }
                if (iface.ipv6) {
                    const ipRow = this.createDetailRow('IPv6 Address', iface.ipv6);
                    ifaceExpander.add_row(ipRow);
                }
                if (iface.netmask) {
                    const maskRow = this.createDetailRow('Netmask', iface.netmask);
                    ifaceExpander.add_row(maskRow);
                }
                if (iface.mac) {
                    const macRow = this.createDetailRow('MAC Address', iface.mac);
                    ifaceExpander.add_row(macRow);
                }
                if (iface.mtu) {
                    const mtuRow = this.createDetailRow('MTU', iface.mtu, 'Maximum transmission unit');
                    ifaceExpander.add_row(mtuRow);
                }
                if (iface.rx) {
                    const rxRow = this.createDetailRow('RX bytes', iface.rx, 'Total bytes received');
                    ifaceExpander.add_row(rxRow);
                }
                if (iface.tx) {
                    const txRow = this.createDetailRow('TX bytes', iface.tx, 'Total bytes transmitted');
                    ifaceExpander.add_row(txRow);
                }
            }
            // Add the group as a row to network expander instead of set_child
            // Create a wrapper box for the group
            const groupWrapper = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
            });
            groupWrapper.append(interfacesGroup);
            const groupRow = new Gtk.ListBoxRow();
            groupRow.set_child(groupWrapper);
            groupRow.set_activatable(false);
            groupRow.set_selectable(false);
            this.networkExpander.add_row(groupRow);
            // Create a PreferencesGroup for other network info
            const otherNetworkGroup = new Adw.PreferencesGroup();
            otherNetworkGroup.set_title('Connectivity');
            otherNetworkGroup.set_description('');
            otherNetworkGroup.set_margin_start(40);
            otherNetworkGroup.set_margin_end(12);
            otherNetworkGroup.set_margin_top(6);
            otherNetworkGroup.set_margin_bottom(6);
            // Add Firewall information
            this.loadFirewallInfo(otherNetworkGroup);
            // Add WiFi information
            this.loadWiFiInfo(otherNetworkGroup);
            // Add Ethernet information
            this.loadEthernetInfo(otherNetworkGroup);
            // Add DNS information
            this.loadDNSInfo(otherNetworkGroup);
            // Add VPN information
            this.loadVPNInfo(otherNetworkGroup);
            // Add the other group as a row
            const otherGroupWrapper = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
            });
            otherGroupWrapper.append(otherNetworkGroup);
            const otherGroupRow = new Gtk.ListBoxRow();
            otherGroupRow.set_child(otherGroupWrapper);
            otherGroupRow.set_activatable(false);
            otherGroupRow.set_selectable(false);
            this.networkExpander.add_row(otherGroupRow);
        }
        catch (e) {
            console.error('Error loading network interfaces:', e);
        }
    }
    loadFirewallInfo(group) {
        try {
            const firewallExpander = new Adw.ExpanderRow({
                title: 'Firewall',
                icon_name: 'security-high-symbolic',
                show_enable_switch: false,
            });
            // Try to get firewall status
            let status = 'Unknown';
            let details = [];
            let needsAuth = false;
            try {
                const [stdout, stderr] = this.utils.executeCommand('ufw', ['status']);
                if (stderr && (stderr.includes('permission denied') || stderr.includes('ERROR'))) {
                    needsAuth = true;
                }
                else if (stdout.includes('Status: active')) {
                    status = 'Active';
                    const lines = stdout.split('\n');
                    for (const line of lines) {
                        if (line.trim() && !line.includes('Status:') && !line.includes('To') && !line.includes('--')) {
                            details.push(line.trim());
                        }
                    }
                }
                else if (stdout.includes('Status: inactive')) {
                    status = 'Inactive';
                }
            }
            catch (e) {
                // Try firewalld
                try {
                    const [stdout2, stderr2] = this.utils.executeCommand('firewall-cmd', ['--state']);
                    if (stderr2 && stderr2.includes('authorization')) {
                        needsAuth = true;
                    }
                    else {
                        status = stdout2.trim();
                    }
                }
                catch (e2) {
                    status = 'Not available';
                }
            }
            if (!this.isAuthenticated && needsAuth) {
                const authRow = this.createDetailRow('Authentication Required', 'Click "Authenticate" button to view firewall information');
                const lockIcon = new Gtk.Image({
                    icon_name: 'dialog-password-symbolic',
                    css_classes: ['dim-label'],
                });
                authRow.get_child().append(lockIcon);
                firewallExpander.add_row(authRow);
                group.add(firewallExpander);
                return;
            }
            const statusRow = this.createDetailRow('Status', status, 'Firewall state');
            firewallExpander.add_row(statusRow);
            if (details.length > 0 && details.length <= 5) {
                for (const detail of details) {
                    const row = this.createDetailRow('Rule', detail);
                    firewallExpander.add_row(row);
                }
            }
            group.add(firewallExpander);
        }
        catch (e) {
            console.error('Error loading firewall info:', e);
        }
    }
    loadWiFiInfo(group) {
        try {
            const wifiExpander = new Adw.ExpanderRow({
                title: 'WiFi',
                icon_name: 'network-wireless-symbolic',
                show_enable_switch: false,
            });
            // Try to get WiFi information using nmcli
            try {
                const [stdout] = this.utils.executeCommand('nmcli', ['-t', '-f', 'ACTIVE,SSID,SIGNAL,SECURITY', 'dev', 'wifi']);
                const lines = stdout.split('\n').filter(l => l.trim());
                let hasWifi = false;
                for (const line of lines) {
                    const parts = line.split(':');
                    if (parts.length >= 4 && parts[0] === 'yes') {
                        hasWifi = true;
                        const ssidRow = this.createDetailRow('Connected to', parts[1] || 'Unknown', 'WiFi network name (SSID)');
                        wifiExpander.add_row(ssidRow);
                        if (parts[2]) {
                            const signalRow = this.createDetailRow('Signal Strength', `${parts[2]}%`, 'WiFi signal quality');
                            wifiExpander.add_row(signalRow);
                        }
                        if (parts[3]) {
                            const securityRow = this.createDetailRow('Security', parts[3], 'WiFi encryption type');
                            wifiExpander.add_row(securityRow);
                        }
                        break;
                    }
                }
                if (!hasWifi) {
                    const noWifiRow = this.createDetailRow('Status', 'Not connected');
                    wifiExpander.add_row(noWifiRow);
                }
            }
            catch (e) {
                const errorRow = this.createDetailRow('Status', 'Information not available');
                wifiExpander.add_row(errorRow);
            }
            group.add(wifiExpander);
        }
        catch (e) {
            console.error('Error loading WiFi info:', e);
        }
    }
    loadEthernetInfo(group) {
        try {
            const ethernetExpander = new Adw.ExpanderRow({
                title: 'Ethernet',
                icon_name: 'network-wired-symbolic',
                show_enable_switch: false,
            });
            // Try to get Ethernet information using nmcli
            try {
                const [stdout] = this.utils.executeCommand('nmcli', ['-t', '-f', 'DEVICE,TYPE,STATE,CONNECTION', 'dev']);
                const lines = stdout.split('\n').filter(l => l.trim());
                let hasEthernet = false;
                for (const line of lines) {
                    const parts = line.split(':');
                    if (parts.length >= 4 && parts[1] === 'ethernet') {
                        hasEthernet = true;
                        const deviceRow = this.createDetailRow('Device', parts[0], 'Network interface name');
                        ethernetExpander.add_row(deviceRow);
                        const stateRow = this.createDetailRow('State', parts[2], 'Connection status');
                        ethernetExpander.add_row(stateRow);
                        if (parts[3]) {
                            const connectionRow = this.createDetailRow('Connection', parts[3], 'Active network connection');
                            ethernetExpander.add_row(connectionRow);
                        }
                    }
                }
                if (!hasEthernet) {
                    const noEthRow = this.createDetailRow('Status', 'No ethernet devices found');
                    ethernetExpander.add_row(noEthRow);
                }
            }
            catch (e) {
                const errorRow = this.createDetailRow('Status', 'Information not available');
                ethernetExpander.add_row(errorRow);
            }
            group.add(ethernetExpander);
        }
        catch (e) {
            console.error('Error loading Ethernet info:', e);
        }
    }
    loadDNSInfo(group) {
        try {
            const dnsExpander = new Adw.ExpanderRow({
                title: 'DNS',
                icon_name: 'network-server-symbolic',
                show_enable_switch: false,
            });
            // Try to get DNS servers from resolv.conf and systemd-resolve
            try {
                const [stdout] = this.utils.executeCommand('cat', ['/etc/resolv.conf']);
                const lines = stdout.split('\n');
                let ipv4Servers = [];
                let ipv6Servers = [];
                let searchDomains = [];
                let options = [];
                for (const line of lines) {
                    const trimmed = line.trim();
                    if (trimmed.startsWith('nameserver')) {
                        const parts = trimmed.split(/\s+/);
                        if (parts.length >= 2) {
                            const ip = parts[1];
                            if (ip.includes(':')) {
                                ipv6Servers.push(ip);
                            }
                            else {
                                ipv4Servers.push(ip);
                            }
                        }
                    }
                    else if (trimmed.startsWith('search')) {
                        const domains = trimmed.substring(6).trim().split(/\s+/);
                        searchDomains.push(...domains);
                    }
                    else if (trimmed.startsWith('options')) {
                        const opts = trimmed.substring(7).trim().split(/\s+/);
                        options.push(...opts);
                    }
                }
                if (ipv4Servers.length === 0 && ipv6Servers.length === 0 && searchDomains.length === 0) {
                    const noDnsRow = this.createDetailRow('Status', 'No DNS configuration found');
                    dnsExpander.add_row(noDnsRow);
                }
                else {
                    // Always show IPv6 row
                    const ipv6Row = this.createDetailRow('Nameserver IPv6', ipv6Servers.length > 0 ? ipv6Servers.join(', ') : 'Not configured', 'IPv6 DNS servers');
                    dnsExpander.add_row(ipv6Row);
                    // Always show IPv4 row
                    const ipv4Row = this.createDetailRow('Nameserver IPv4', ipv4Servers.length > 0 ? ipv4Servers.join(', ') : 'Not configured', 'IPv4 DNS servers');
                    dnsExpander.add_row(ipv4Row);
                    // Show search domains
                    if (searchDomains.length > 0) {
                        const searchRow = this.createDetailRow('Search Domains', searchDomains.join(', '), 'DNS search suffixes');
                        dnsExpander.add_row(searchRow);
                    }
                    // Show options if present
                    if (options.length > 0) {
                        const optionsRow = this.createDetailRow('Options', options.join(', '), 'DNS resolver options');
                        dnsExpander.add_row(optionsRow);
                    }
                }
            }
            catch (e) {
                const errorRow = this.createDetailRow('Status', 'Information not available');
                dnsExpander.add_row(errorRow);
            }
            group.add(dnsExpander);
        }
        catch (e) {
            console.error('Error loading DNS info:', e);
        }
    }
    loadVPNInfo(group) {
        try {
            const vpnExpander = new Adw.ExpanderRow({
                title: 'VPN',
                icon_name: 'network-vpn-symbolic',
                show_enable_switch: false,
            });
            // Try to detect active VPN connections
            try {
                const [stdout] = this.utils.executeCommand('nmcli', ['-t', '-f', 'NAME,TYPE,STATE', 'con', 'show', '--active']);
                const lines = stdout.split('\n').filter(l => l.trim());
                let hasVPN = false;
                for (const line of lines) {
                    const parts = line.split(':');
                    if (parts.length >= 3 && (parts[1].includes('vpn') || parts[1].includes('tun') || parts[1].includes('wireguard'))) {
                        hasVPN = true;
                        const nameRow = this.createDetailRow('Connection', parts[0], 'VPN connection name');
                        vpnExpander.add_row(nameRow);
                        const typeRow = this.createDetailRow('Type', parts[1], 'VPN protocol type');
                        vpnExpander.add_row(typeRow);
                        const stateRow = this.createDetailRow('State', parts[2], 'Connection status');
                        vpnExpander.add_row(stateRow);
                    }
                }
                if (!hasVPN) {
                    const noVpnRow = this.createDetailRow('Status', 'No active VPN connections');
                    vpnExpander.add_row(noVpnRow);
                }
            }
            catch (e) {
                const errorRow = this.createDetailRow('Status', 'Information not available');
                vpnExpander.add_row(errorRow);
            }
            group.add(vpnExpander);
        }
        catch (e) {
            console.error('Error loading VPN info:', e);
        }
    }
    loadSoftwareInfo() {
        // Installed packages count
        try {
            let packagesCount = 'Unknown';
            let packageManager = '';
            // Try different package managers
            try {
                const [dpkgOut] = this.utils.executeCommand('dpkg', ['-l']);
                const count = dpkgOut.split('\n').filter(line => line.startsWith('ii')).length;
                packagesCount = count.toString();
                packageManager = 'dpkg';
            }
            catch (e) {
                try {
                    const [rpmOut] = this.utils.executeCommand('rpm', ['-qa']);
                    const count = rpmOut.split('\n').filter(line => line.trim()).length;
                    packagesCount = count.toString();
                    packageManager = 'rpm';
                }
                catch (e2) {
                    try {
                        const [pacmanOut] = this.utils.executeCommand('pacman', ['-Q']);
                        const count = pacmanOut.split('\n').filter(line => line.trim()).length;
                        packagesCount = count.toString();
                        packageManager = 'pacman';
                    }
                    catch (e3) {
                        // No package manager found
                    }
                }
            }
            if (packageManager) {
                this.addInfoRow('Packages', `${packagesCount} (${packageManager})`, 'application-x-addon-symbolic', 'software');
            }
        }
        catch (e) {
            console.error('Error loading package count:', e);
        }
        // Shell
        try {
            const [shellOut] = this.utils.executeCommand('sh', ['-c', 'echo $SHELL']);
            if (shellOut.trim()) {
                const shell = shellOut.trim().split('/').pop() || shellOut.trim();
                this.addInfoRow('Shell', shell, 'utilities-terminal-symbolic', 'software');
            }
        }
        catch (e) {
            console.error('Error loading shell:', e);
        }
        // Python version
        try {
            const [pythonOut] = this.utils.executeCommand('python3', ['--version']);
            if (pythonOut.trim()) {
                const version = pythonOut.replace('Python ', '').trim();
                this.addInfoRow('Python', version, 'application-x-executable-symbolic', 'software');
            }
        }
        catch (e) {
            // Python not installed
        }
        // Node.js version
        try {
            const [nodeOut] = this.utils.executeCommand('node', ['--version']);
            if (nodeOut.trim()) {
                const version = nodeOut.trim().replace('v', '');
                this.addInfoRow('Node.js', version, 'application-x-executable-symbolic', 'software');
            }
        }
        catch (e) {
            // Node not installed
        }
        // GCC version
        try {
            const [gccOut] = this.utils.executeCommand('gcc', ['--version']);
            const firstLine = gccOut.split('\n')[0];
            const match = firstLine.match(/gcc.*?(\d+\.\d+\.\d+)/);
            if (match) {
                this.addInfoRow('GCC', match[1], 'application-x-executable-symbolic', 'software');
            }
        }
        catch (e) {
            // GCC not installed
        }
        // Git version
        try {
            const [gitOut] = this.utils.executeCommand('git', ['--version']);
            const match = gitOut.match(/git version ([\d.]+)/);
            if (match) {
                this.addInfoRow('Git', match[1], 'application-x-executable-symbolic', 'software');
            }
        }
        catch (e) {
            // Git not installed
        }
        // Docker version
        try {
            const [dockerOut] = this.utils.executeCommand('docker', ['--version']);
            const match = dockerOut.match(/Docker version ([\d.]+)/);
            if (match) {
                this.addInfoRow('Docker', match[1], 'application-x-executable-symbolic', 'software');
            }
        }
        catch (e) {
            // Docker not installed
        }
    }
    parseIpAddr(output) {
        const interfaces = [];
        let currentIface = null;
        if (!output || output.trim() === '') {
            console.error('Empty output from ip command');
            return interfaces;
        }
        console.log('Parsing ip addr output, length:', output.length);
        const lines = output.split('\n');
        console.log('Total lines:', lines.length);
        for (const line of lines) {
            // New interface - format: "2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500"
            // Also handle: "2: eth0@if3: <BROADCAST..." for virtual interfaces
            if (line.match(/^\d+:\s+[a-z0-9@]+:/i)) {
                if (currentIface) {
                    interfaces.push(currentIface);
                }
                const match = line.match(/^\d+:\s+([^:@]+)/);
                if (match) {
                    currentIface = {
                        name: match[1].trim(),
                    };
                    console.log('Found interface:', currentIface.name);
                }
                // Extract flags
                const flagMatch = line.match(/<([^>]+)>/);
                if (flagMatch) {
                    currentIface.state = flagMatch[1].includes('UP') ? 'UP' : 'DOWN';
                }
                // Extract MTU
                const mtuMatch = line.match(/mtu (\d+)/);
                if (mtuMatch) {
                    currentIface.mtu = mtuMatch[1];
                }
            }
            else if (currentIface) {
                const trimmed = line.trim();
                // MAC address - format: "link/ether 00:11:22:33:44:55"
                if (trimmed.startsWith('link/ether')) {
                    const match = trimmed.match(/link\/ether\s+([a-f0-9:]+)/i);
                    if (match) {
                        currentIface.mac = match[1];
                    }
                }
                // IPv4 address - format: "inet 192.168.1.100/24"
                if (trimmed.startsWith('inet ') && !trimmed.startsWith('inet6')) {
                    const match = trimmed.match(/inet\s+([0-9.]+)\/?(\d+)?/);
                    if (match) {
                        currentIface.ipv4 = match[1];
                        if (match[2]) {
                            currentIface.netmask = `/${match[2]}`;
                        }
                    }
                }
                // IPv6 address - format: "inet6 fe80::1/64"
                if (trimmed.startsWith('inet6')) {
                    const match = trimmed.match(/inet6\s+([a-f0-9:]+)/);
                    if (match && !currentIface.ipv6) {
                        currentIface.ipv6 = match[1];
                    }
                }
            }
        }
        if (currentIface) {
            interfaces.push(currentIface);
        }
        // Get RX/TX statistics from /proc/net/dev
        try {
            const [stats] = this.utils.executeCommand('cat', ['/proc/net/dev']);
            const statLines = stats.split('\n');
            for (const iface of interfaces) {
                for (const statLine of statLines) {
                    if (statLine.includes(iface.name + ':')) {
                        const parts = statLine.split(/\s+/).filter(p => p);
                        if (parts.length >= 10) {
                            iface.rx = this.utils.formatBytes(parseInt(parts[1]));
                            iface.tx = this.utils.formatBytes(parseInt(parts[9]));
                        }
                        break;
                    }
                }
            }
        }
        catch (e) {
            console.error('Error reading network stats:', e);
        }
        return interfaces;
    }
    getInterfaceIcon(name) {
        if (name.startsWith('wl') || name.startsWith('wifi')) {
            return 'network-wireless-symbolic';
        }
        else if (name.startsWith('en') || name.startsWith('eth')) {
            return 'network-wired-symbolic';
        }
        else if (name.startsWith('lo')) {
            return 'network-server-symbolic';
        }
        else if (name.startsWith('docker') || name.startsWith('br')) {
            return 'network-workgroup-symbolic';
        }
        return 'network-wired-symbolic';
    }
    formatUptime(milliseconds) {
        const seconds = Math.floor(milliseconds / 1000);
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const mins = Math.floor((seconds % 3600) / 60);
        const parts = [];
        if (days > 0)
            parts.push(`${days} days`);
        if (hours > 0)
            parts.push(`${hours} hours`);
        if (mins > 0)
            parts.push(`${mins} mins`);
        return parts.join(', ') || '0 mins';
    }
    exportToJSON() {
        try {
            // Collect all system information
            const systemData = {
                exportDate: new Date().toISOString(),
                hostname: '',
                system: {},
                hardware: {},
                software: {},
                network: {},
                processes: []
            };
            // Get system and software info from DataService
            try {
                const sysInfo = this.dataService.getSystemInfo();
                systemData.hostname = sysInfo.hostname;
                systemData.system = {
                    os: sysInfo.os,
                    kernel: sysInfo.kernel,
                    uptime: sysInfo.uptime
                };
                if (sysInfo.displays && sysInfo.displays.length > 0) {
                    systemData.hardware.displays = sysInfo.displays;
                }
            }
            catch (e) {
                console.error('Error getting system info:', e);
            }
            try {
                const softInfo = this.dataService.getSoftwareInfo();
                systemData.software = softInfo;
            }
            catch (e) {
                console.error('Error getting software info:', e);
            }
            // Get CPU info
            try {
                const cpuInfo = this.dataService.getCpuInfo();
                systemData.hardware.cpu = cpuInfo;
            }
            catch (e) {
                console.error('Error getting CPU info:', e);
            }
            // Get GPU info
            try {
                const gpuInfo = this.dataService.getGpuInfo();
                systemData.hardware.gpu = gpuInfo;
            }
            catch (e) {
                console.error('Error getting GPU info:', e);
            }
            // Get Memory info
            try {
                const memoryInfo = this.dataService.getMemoryInfo();
                systemData.hardware.memory = memoryInfo;
            }
            catch (e) {
                console.error('Error getting memory info:', e);
            }
            // Get Battery info if available
            try {
                if (this.dataService.hasBattery()) {
                    const [stdout] = this.utils.executeCommand('fastfetch', ['--format', 'json']);
                    const fastfetchData = JSON.parse(stdout);
                    const batteryModule = fastfetchData.find((item) => item.type === 'Battery');
                    if (batteryModule?.result) {
                        const batteryArray = Array.isArray(batteryModule.result) ? batteryModule.result : [batteryModule.result];
                        if (batteryArray.length > 0 && batteryArray[0]) {
                            systemData.hardware.battery = batteryArray[0];
                        }
                    }
                }
            }
            catch (e) {
                console.error('Error getting battery info:', e);
            }
            // Get Disk info
            try {
                const [stdout] = this.utils.executeCommand('lsblk', ['-J', '-o', 'NAME,SIZE,TYPE,MOUNTPOINT,FSTYPE,MODEL,SERIAL,VENDOR']);
                const diskData = JSON.parse(stdout);
                systemData.hardware.disks = diskData;
            }
            catch (e) {
                console.error('Error getting disk info:', e);
            }
            // Get Network interfaces
            try {
                const [stdout] = this.utils.executeCommand('ip', ['-j', 'addr', 'show']);
                const networkData = JSON.parse(stdout);
                systemData.network.interfaces = networkData;
            }
            catch (e) {
                console.error('Error getting network info:', e);
            }
            // Get Network statistics
            try {
                const [stdout] = this.utils.executeCommand('cat', ['/proc/net/dev']);
                const lines = stdout.split('\n').slice(2);
                systemData.network.statistics = [];
                for (const line of lines) {
                    if (line.trim()) {
                        const parts = line.trim().split(/\s+/);
                        if (parts.length >= 10) {
                            systemData.network.statistics.push({
                                interface: parts[0].replace(':', ''),
                                rx_bytes: parseInt(parts[1]),
                                rx_packets: parseInt(parts[2]),
                                tx_bytes: parseInt(parts[9]),
                                tx_packets: parseInt(parts[10])
                            });
                        }
                    }
                }
            }
            catch (e) {
                console.error('Error getting network statistics:', e);
            }
            // Get Process list
            try {
                const [stdout] = this.utils.executeCommand('ps', ['aux', '--sort=-pcpu']);
                const lines = stdout.split('\n');
                systemData.processes = lines.slice(1, 21).map((line) => {
                    const parts = line.trim().split(/\s+/);
                    if (parts.length >= 11) {
                        return {
                            user: parts[0],
                            pid: parts[1],
                            cpu: parts[2],
                            mem: parts[3],
                            vsz: parts[4],
                            rss: parts[5],
                            stat: parts[7],
                            start: parts[8],
                            time: parts[9],
                            command: parts.slice(10).join(' ')
                        };
                    }
                    return null;
                }).filter((p) => p !== null);
            }
            catch (e) {
                console.error('Error getting process info:', e);
            }
            // Convert to JSON string
            const jsonContent = JSON.stringify(systemData, null, 2);
            // Show save file dialog
            const fileDialog = new Gtk.FileDialog();
            fileDialog.set_title('Export System Information');
            fileDialog.set_initial_name('system-info.json');
            // Create file filter for JSON
            const filter = new Gtk.FileFilter();
            filter.set_name('JSON files');
            filter.add_mime_type('application/json');
            filter.add_pattern('*.json');
            const filterList = new Gio.ListStore({ item_type: Gtk.FileFilter.$gtype });
            filterList.append(filter);
            fileDialog.set_filters(filterList);
            // Show save dialog
            fileDialog.save(this.container.get_root(), null, (dialog, result) => {
                try {
                    const file = fileDialog.save_finish(result);
                    if (file) {
                        // Write JSON to file
                        const [success] = file.replace_contents(jsonContent, null, false, Gio.FileCreateFlags.REPLACE_DESTINATION, null);
                        if (success) {
                            // Show success notification
                            const toast = new Adw.Toast({
                                title: 'System information exported successfully',
                                timeout: 3
                            });
                            // Find the AdwToastOverlay parent if available
                            let widget = this.container.get_parent();
                            while (widget && !(widget instanceof Adw.ToastOverlay)) {
                                widget = widget.get_parent();
                            }
                            if (widget instanceof Adw.ToastOverlay) {
                                widget.add_toast(toast);
                            }
                        }
                    }
                }
                catch (e) {
                    // Check if user cancelled the dialog
                    if (e.matches && e.matches(Gtk.DialogError, Gtk.DialogError.DISMISSED)) {
                        // User cancelled, do nothing
                        return;
                    }
                    console.error('Error saving file:', e);
                    // Show error dialog only for real errors
                    const errorDialog = new Adw.MessageDialog({
                        heading: 'Export Failed',
                        body: 'Could not save the file. Please try again.',
                    });
                    errorDialog.add_response('ok', 'OK');
                    errorDialog.set_transient_for(this.container.get_root());
                    errorDialog.present();
                }
            });
        }
        catch (e) {
            console.error('Error exporting to JSON:', e);
            const errorDialog = new Adw.MessageDialog({
                heading: 'Export Failed',
                body: `An error occurred while exporting: ${e}`,
            });
            errorDialog.add_response('ok', 'OK');
            errorDialog.set_transient_for(this.container.get_root());
            errorDialog.present();
        }
    }
    getWidget() {
        return this.container;
    }
}
 SystemInfoComponent;
class BatteryComponent {
    constructor() {
        this.updateTimeoutId = null;
        this.hourlyData = new Map(); // hour -> [levels]
        this.hoursToShow = 24;
        this.utils = UtilsService.instance;
        this.dataService = DataService.instance;
        this.processesService = ProcessesService.instance;
        const builder = Gtk.Builder.new();
        try {
            try {
                builder.add_from_file('/usr/share/com.obision.app.system/ui/battery.ui');
            }
            catch (e) {
                builder.add_from_file('data/ui/battery.ui');
            }
        }
        catch (e) {
            console.error('Could not load battery.ui:', e);
            this.container = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
                spacing: 12,
            });
            const label = new Gtk.Label({
                label: 'Error loading battery UI',
            });
            this.container.append(label);
            return;
        }
        this.container = builder.get_object('battery_container');
        this.batteryChart = builder.get_object('battery_chart');
        this.batteryLevelBar = builder.get_object('battery_level_bar');
        this.batteryLevelTitle = builder.get_object('battery_level_title');
        this.batteryLevelPercent = builder.get_object('battery_level_percent');
        this.batteryStatusValue = builder.get_object('battery_status_value');
        this.batteryCapacityValue = builder.get_object('battery_capacity_value');
        this.batteryHealthValue = builder.get_object('battery_health_value');
        this.batteryTechnologyValue = builder.get_object('battery_technology_value');
        this.batteryVoltageValue = builder.get_object('battery_voltage_value');
        this.batteryCyclesValue = builder.get_object('battery_cycles_value');
        this.batteryManufacturerValue = builder.get_object('battery_manufacturer_value');
        this.batteryModelValue = builder.get_object('battery_model_value');
        this.batteryTemperatureValue = builder.get_object('battery_temperature_value');
        this.batteryTimeRemainingValue = builder.get_object('battery_time_remaining_value');
        // Create and add TopProcessesList
        this.topProcessesList = new TopProcessesList('cpu', 8);
        const topProcessesContainer = builder.get_object('top_processes_container');
        if (topProcessesContainer) {
            topProcessesContainer.append(this.topProcessesList.getWidget());
        }
        // Load historical battery data
        this.loadHistoricalData();
        // Setup drawing function for chart
        this.batteryChart.set_draw_func((area, cr, width, height) => {
            this.drawBarChart(cr, width, height);
        });
        // Load battery info
        this.loadBatteryInfo();
        // Initial update
        this.updateData();
        // Update every 5 minutes
        this.updateTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 300000, () => {
            this.updateData();
            this.loadHistoricalData(); // Refresh historical data
            return GLib.SOURCE_CONTINUE;
        });
    }
    loadHistoricalData() {
        // Clear existing data
        this.hourlyData.clear();
        // Get battery history from DataService
        const history = this.dataService.getBatteryHistory();
        if (history.length === 0) {
            // If no historical data, create empty buckets for last 24 hours
            const now = new Date();
            for (let i = 23; i >= 0; i--) {
                const hour = new Date(now.getTime() - i * 60 * 60 * 1000).getHours();
                this.hourlyData.set(hour, []);
            }
            return;
        }
        // Group battery levels by hour
        for (const entry of history) {
            const date = new Date(entry.timestamp);
            const hour = date.getHours();
            if (!this.hourlyData.has(hour)) {
                this.hourlyData.set(hour, []);
            }
            this.hourlyData.get(hour).push(entry.level);
        }
        // Update top processes
        this.updateTopProcesses();
        // Redraw chart
        this.batteryChart.queue_draw();
    }
    updateTopProcesses() {
        try {
            const allProcesses = this.processesService['loadProcesses']();
            const processInfoList = allProcesses.map(p => ({
                name: p.command.split(' ')[0].split('/').pop() || p.command,
                cpu: parseFloat(p.cpu) || 0,
                memory: parseFloat(p.rss) || 0
            }));
            this.topProcessesList.updateProcesses(processInfoList);
        }
        catch (error) {
            console.error('Error updating top processes:', error);
        }
    }
    loadBatteryInfo() {
        try {
            const [stdout, stderr] = this.utils.executeCommand('fastfetch', ['--format', 'json']);
            if (!stdout) {
                console.error('No output from fastfetch');
                return;
            }
            const data = JSON.parse(stdout);
            if (!data || !Array.isArray(data)) {
                return;
            }
            // Find Battery module
            const batteryModule = data.find((item) => item.type === 'Battery');
            if (!batteryModule || !batteryModule.result) {
                console.log('No battery information found');
                return;
            }
            const batteryArray = Array.isArray(batteryModule.result) ? batteryModule.result : [batteryModule.result];
            if (batteryArray.length === 0) {
                return;
            }
            const battery = batteryArray[0];
            // Update static battery information
            if (battery.manufacturer) {
                this.batteryManufacturerValue.set_label(battery.manufacturer);
            }
            if (battery.modelName) {
                this.batteryModelValue.set_label(battery.modelName);
            }
            if (battery.technology) {
                this.batteryTechnologyValue.set_label(battery.technology);
            }
            if (battery.cycleCount !== undefined) {
                this.batteryCyclesValue.set_label(battery.cycleCount.toString());
            }
        }
        catch (error) {
            console.error('Error loading battery info:', error);
        }
    }
    updateData() {
        try {
            const [stdout, stderr] = this.utils.executeCommand('fastfetch', ['--format', 'json']);
            if (!stdout) {
                return;
            }
            const data = JSON.parse(stdout);
            if (!data || !Array.isArray(data)) {
                return;
            }
            // Find Battery module
            const batteryModule = data.find((item) => item.type === 'Battery');
            if (!batteryModule || !batteryModule.result) {
                return;
            }
            const batteryArray = Array.isArray(batteryModule.result) ? batteryModule.result : [batteryModule.result];
            if (batteryArray.length === 0) {
                return;
            }
            const battery = batteryArray[0];
            // Update dynamic battery information
            const capacity = battery.capacity !== undefined ? battery.capacity : 0;
            // Update level bar and labels
            if (this.batteryLevelBar) {
                this.batteryLevelBar.set_value(capacity / 100);
            }
            if (this.batteryLevelTitle) {
                this.batteryLevelTitle.set_label('Battery Level');
            }
            if (this.batteryLevelPercent) {
                this.batteryLevelPercent.set_label(`${capacity.toFixed(1)}%`);
            }
            // Update status
            if (this.batteryStatusValue && battery.status) {
                this.batteryStatusValue.set_label(battery.status);
            }
            // Update capacity
            if (this.batteryCapacityValue) {
                this.batteryCapacityValue.set_label(`${capacity.toFixed(1)}%`);
            }
            // Calculate health (design capacity vs current full capacity)
            if (this.batteryHealthValue) {
                // Health is typically 100% when new and decreases with age
                // We use capacity as a proxy if health is not directly available
                const health = battery.health !== undefined ? battery.health : capacity;
                this.batteryHealthValue.set_label(`${health.toFixed(1)}%`);
            }
            // Update voltage
            if (this.batteryVoltageValue && battery.voltage !== undefined) {
                this.batteryVoltageValue.set_label(`${battery.voltage.toFixed(2)} V`);
            }
            // Update temperature
            if (this.batteryTemperatureValue && battery.temperature !== undefined && battery.temperature !== null) {
                this.batteryTemperatureValue.set_label(`${battery.temperature.toFixed(1)} °C`);
            }
            // Calculate time remaining (approximate)
            if (this.batteryTimeRemainingValue) {
                if (battery.status && battery.status.includes('Charging')) {
                    // Estimate time to full charge (rough calculation)
                    const remaining = 100 - capacity;
                    const estimatedMinutes = Math.round((remaining / 100) * 120); // Assume 2 hours for full charge
                    const hours = Math.floor(estimatedMinutes / 60);
                    const minutes = estimatedMinutes % 60;
                    this.batteryTimeRemainingValue.set_label(`${hours}h ${minutes}m (charging)`);
                }
                else if (battery.status && battery.status.includes('Discharging')) {
                    // Estimate time remaining (rough calculation)
                    const estimatedMinutes = Math.round((capacity / 100) * 240); // Assume 4 hours at full capacity
                    const hours = Math.floor(estimatedMinutes / 60);
                    const minutes = estimatedMinutes % 60;
                    this.batteryTimeRemainingValue.set_label(`${hours}h ${minutes}m remaining`);
                }
                else {
                    this.batteryTimeRemainingValue.set_label('N/A');
                }
            }
            // Update hourly data with current capacity
            const currentHour = new Date().getHours();
            if (!this.hourlyData.has(currentHour)) {
                this.hourlyData.set(currentHour, []);
            }
            this.hourlyData.get(currentHour).push(capacity);
            // Redraw chart
            this.batteryChart.queue_draw();
        }
        catch (error) {
            console.error('Error updating battery data:', error);
        }
    }
    drawBarChart(cr, width, height) {
        const padding = 40;
        const bottomPadding = 50;
        const chartWidth = width - 2 * padding;
        const chartHeight = height - padding - bottomPadding;
        // Clear background with transparent color
        cr.setSourceRGBA(0, 0, 0, 0);
        cr.paint();
        // Draw grid lines
        cr.setSourceRGBA(0.8, 0.8, 0.8, 0.3);
        cr.setLineWidth(1);
        // Horizontal grid lines (0%, 25%, 50%, 75%, 100%)
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight * i / 4);
            cr.moveTo(padding, y);
            cr.lineTo(width - padding, y);
            cr.stroke();
            // Draw percentage labels
            cr.setSourceRGB(0.5, 0.5, 0.5);
            cr.setFontSize(10);
            const percentage = 100 - (i * 25);
            cr.moveTo(padding - 30, y + 4);
            cr.showText(`${percentage}%`);
        }
        // Draw axes
        cr.setSourceRGB(0.5, 0.5, 0.5);
        cr.setLineWidth(2);
        cr.moveTo(padding, padding);
        cr.lineTo(padding, height - bottomPadding);
        cr.lineTo(width - padding, height - bottomPadding);
        cr.stroke();
        if (this.hourlyData.size === 0) {
            // No data message
            cr.setSourceRGB(0.5, 0.5, 0.5);
            cr.setFontSize(14);
            const msg = 'No historical data available';
            const extents = cr.textExtents(msg);
            cr.moveTo((width - extents.width) / 2, height / 2);
            cr.showText(msg);
            return;
        }
        // Calculate bar width
        const barCount = this.hoursToShow;
        const barSpacing = 4;
        const barWidth = (chartWidth - (barCount - 1) * barSpacing) / barCount;
        // Get hours in order (last 24 hours)
        const currentHour = new Date().getHours();
        const hours = [];
        for (let i = 0; i < this.hoursToShow; i++) {
            const hour = (currentHour - this.hoursToShow + 1 + i + 24) % 24;
            hours.push(hour);
        }
        // Draw bars
        hours.forEach((hour, index) => {
            const levels = this.hourlyData.get(hour) || [];
            if (levels.length === 0) {
                // Draw empty bar
                const x = padding + index * (barWidth + barSpacing);
                cr.setSourceRGBA(0.7, 0.7, 0.7, 0.2);
                cr.rectangle(x, height - bottomPadding - 5, barWidth, 5);
                cr.fill();
            }
            else {
                // Calculate average level for this hour
                const avgLevel = levels.reduce((sum, val) => sum + val, 0) / levels.length;
                const barHeight = (avgLevel / 100) * chartHeight;
                const x = padding + index * (barWidth + barSpacing);
                const y = height - bottomPadding - barHeight;
                // Color based on battery level
                if (avgLevel > 50) {
                    cr.setSourceRGB(0.2, 0.8, 0.2); // Green
                }
                else if (avgLevel > 20) {
                    cr.setSourceRGB(0.9, 0.7, 0.2); // Yellow/Orange
                }
                else {
                    cr.setSourceRGB(0.9, 0.2, 0.2); // Red
                }
                // Draw bar
                cr.rectangle(x, y, barWidth, barHeight);
                cr.fill();
                // Draw border
                cr.setSourceRGB(0.3, 0.3, 0.3);
                cr.setLineWidth(1);
                cr.rectangle(x, y, barWidth, barHeight);
                cr.stroke();
            }
            // Draw hour label (every 3 hours to avoid crowding)
            if (index % 3 === 0 || index === hours.length - 1) {
                cr.setSourceRGB(0.5, 0.5, 0.5);
                cr.setFontSize(10);
                const label = `${hour}h`;
                const x = padding + index * (barWidth + barSpacing);
                const extents = cr.textExtents(label);
                cr.moveTo(x + (barWidth - extents.width) / 2, height - bottomPadding + 20);
                cr.showText(label);
            }
        });
        // Draw title
        cr.setSourceRGB(0.3, 0.3, 0.3);
        cr.setFontSize(12);
        const title = 'Battery Level - Last 24 Hours';
        const extents = cr.textExtents(title);
        cr.moveTo((width - extents.width) / 2, padding - 10);
        cr.showText(title);
    }
    getWidget() {
        return this.container;
    }
    destroy() {
        if (this.updateTimeoutId !== null) {
            GLib.source_remove(this.updateTimeoutId);
        }
        if (this.topProcessesList) {
            this.topProcessesList.destroy();
        }
    }
}
 BatteryComponent;
class ResourcesComponent {
    constructor() {
        this.updateTimeoutId = null;
        this.cpuCoreProgressBars = [];
        this.cpuCoreLabels = [];
        this.cpuHistory = { values: [], maxPoints: 60 };
        this.prevIdle = [];
        this.prevTotal = [];
        this.memoryHistory = { values: [], maxPoints: 60 };
        this.diskReadHistory = { values: [], maxPoints: 60 };
        this.diskWriteHistory = { values: [], maxPoints: 60 };
        this.prevDiskRead = 0;
        this.prevDiskWrite = 0;
        this.networkDownloadHistory = { values: [], maxPoints: 60 };
        this.networkUploadHistory = { values: [], maxPoints: 60 };
        this.prevNetworkRx = 0;
        this.prevNetworkTx = 0;
        this.utils = UtilsService.instance;
        const builder = Gtk.Builder.new();
        try {
            try {
                builder.add_from_file('/usr/share/com.obision.app.system/ui/resources.ui');
            }
            catch (e) {
                builder.add_from_file('data/ui/resources.ui');
            }
        }
        catch (e) {
            console.error('Could not load resources.ui:', e);
            this.container = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
                spacing: 12,
            });
            return;
        }
        this.container = builder.get_object('resources_container');
        // Get widgets
        this.cpuCoresContainer = builder.get_object('cpu_cores_container');
        this.cpuHistoryChart = builder.get_object('cpu_history_chart');
        this.memoryLabel = builder.get_object('memory_label');
        this.memoryPercent = builder.get_object('memory_percent');
        this.memoryProgress = builder.get_object('memory_progress');
        this.memoryHistoryChart = builder.get_object('memory_history_chart');
        this.swapLabel = builder.get_object('swap_label');
        this.swapPercent = builder.get_object('swap_percent');
        this.swapProgress = builder.get_object('swap_progress');
        this.diskReadLabel = builder.get_object('disk_read_label');
        this.diskWriteLabel = builder.get_object('disk_write_label');
        this.diskHistoryChart = builder.get_object('disk_history_chart');
        this.networkDownloadLabel = builder.get_object('network_download_label');
        this.networkUploadLabel = builder.get_object('network_upload_label');
        this.networkHistoryChart = builder.get_object('network_history_chart');
        this.gpuSection = builder.get_object('gpu_section');
        this.gpuLabel = builder.get_object('gpu_label');
        this.gpuPercent = builder.get_object('gpu_percent');
        this.gpuProgress = builder.get_object('gpu_progress');
        this.temperaturesContainer = builder.get_object('temperatures_container');
        // Setup CPU cores
        this.setupCpuCores();
        // Setup drawing functions
        this.cpuHistoryChart.set_draw_func((area, cr, width, height) => {
            this.drawHistory(cr, width, height, this.cpuHistory, 'CPU', 0.2, 0.6, 0.9);
        });
        this.memoryHistoryChart.set_draw_func((area, cr, width, height) => {
            this.drawHistory(cr, width, height, this.memoryHistory, 'Memory', 0.9, 0.6, 0.2);
        });
        this.diskHistoryChart.set_draw_func((area, cr, width, height) => {
            this.drawDualHistory(cr, width, height, this.diskReadHistory, this.diskWriteHistory, 'Disk I/O', 0.2, 0.7, 0.3, 0.9, 0.3, 0.3);
        });
        this.networkHistoryChart.set_draw_func((area, cr, width, height) => {
            this.drawDualHistory(cr, width, height, this.networkDownloadHistory, this.networkUploadHistory, 'Network I/O', 0.2, 0.4, 0.8, 0.2, 0.8, 0.3);
        });
        // Initial update
        this.updateData();
        // Update every 2 seconds
        this.updateTimeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2000, () => {
            this.updateData();
            return GLib.SOURCE_CONTINUE;
        });
    }
    setupCpuCores() {
        const numCores = this.getNumCores();
        for (let i = 0; i < numCores; i++) {
            const label = new Gtk.Label({
                label: `Core ${i}`,
                halign: Gtk.Align.START,
                hexpand: true,
            });
            const percent = new Gtk.Label({
                label: '--%',
                halign: Gtk.Align.END,
            });
            const progress = new Gtk.ProgressBar({
                hexpand: true,
                show_text: false,
            });
            const container = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
                spacing: 3,
            });
            const labelBox = new Gtk.Box({
                orientation: Gtk.Orientation.HORIZONTAL,
                spacing: 6,
            });
            labelBox.append(label);
            labelBox.append(percent);
            container.append(labelBox);
            container.append(progress);
            this.cpuCoresContainer.append(container);
            this.cpuCoreLabels.push(percent);
            this.cpuCoreProgressBars.push(progress);
            this.prevIdle.push(0);
            this.prevTotal.push(0);
        }
    }
    getNumCores() {
        try {
            const [stdout] = this.utils.executeCommand('nproc', []);
            return parseInt(stdout.trim()) || 1;
        }
        catch {
            return 1;
        }
    }
    updateData() {
        this.updateCPU();
        this.updateMemory();
        this.updateSwap();
        this.updateDiskIO();
        this.updateNetworkIO();
        this.updateGPU();
        this.updateTemperatures();
    }
    updateCPU() {
        try {
            const [stdout] = this.utils.executeCommand('cat', ['/proc/stat']);
            const lines = stdout.split('\n');
            let totalUsage = 0;
            let validCores = 0;
            for (let i = 0; i < this.cpuCoreProgressBars.length; i++) {
                const cpuLine = lines.find(line => line.startsWith(`cpu${i} `));
                if (!cpuLine)
                    continue;
                const values = cpuLine.split(/\s+/).slice(1).map(v => parseInt(v));
                const idle = values[3] + values[4];
                const total = values.reduce((a, b) => a + b, 0);
                if (this.prevTotal[i] !== 0) {
                    const diffIdle = idle - this.prevIdle[i];
                    const diffTotal = total - this.prevTotal[i];
                    const usage = diffTotal > 0 ? ((diffTotal - diffIdle) / diffTotal) * 100 : 0;
                    this.cpuCoreLabels[i].set_label(`${Math.round(usage)}%`);
                    this.cpuCoreProgressBars[i].set_fraction(usage / 100);
                    totalUsage += usage;
                    validCores++;
                }
                this.prevIdle[i] = idle;
                this.prevTotal[i] = total;
            }
            if (validCores > 0) {
                const avgUsage = totalUsage / validCores;
                this.addToHistory(this.cpuHistory, avgUsage);
                this.cpuHistoryChart.queue_draw();
            }
        }
        catch (e) {
            console.error('Error updating CPU:', e);
        }
    }
    updateMemory() {
        try {
            const [stdout] = this.utils.executeCommand('free', ['-m']);
            const lines = stdout.split('\n');
            const memLine = lines.find(line => line.startsWith('Mem:'));
            if (memLine) {
                const values = memLine.split(/\s+/);
                const total = parseInt(values[1]);
                const used = parseInt(values[2]);
                const percentage = (used / total) * 100;
                this.memoryLabel.set_label(`Used: ${used} MB / ${total} MB`);
                this.memoryPercent.set_label(`${Math.round(percentage)}%`);
                this.memoryProgress.set_fraction(percentage / 100);
                this.addToHistory(this.memoryHistory, percentage);
                this.memoryHistoryChart.queue_draw();
            }
        }
        catch (e) {
            console.error('Error updating memory:', e);
        }
    }
    updateSwap() {
        try {
            const [stdout] = this.utils.executeCommand('free', ['-m']);
            const lines = stdout.split('\n');
            const swapLine = lines.find(line => line.startsWith('Swap:'));
            if (swapLine) {
                const values = swapLine.split(/\s+/);
                const total = parseInt(values[1]);
                const used = parseInt(values[2]);
                if (total > 0) {
                    const percentage = (used / total) * 100;
                    this.swapLabel.set_label(`Used: ${used} MB / ${total} MB`);
                    this.swapPercent.set_label(`${Math.round(percentage)}%`);
                    this.swapProgress.set_fraction(percentage / 100);
                }
                else {
                    this.swapLabel.set_label('No swap configured');
                    this.swapPercent.set_label('--');
                    this.swapProgress.set_fraction(0);
                }
            }
        }
        catch (e) {
            console.error('Error updating swap:', e);
        }
    }
    updateDiskIO() {
        try {
            const [stdout] = this.utils.executeCommand('cat', ['/proc/diskstats']);
            const lines = stdout.split('\n');
            let totalRead = 0;
            let totalWrite = 0;
            for (const line of lines) {
                if (!line.trim())
                    continue;
                const parts = line.trim().split(/\s+/);
                if (parts.length < 14)
                    continue;
                const device = parts[2];
                // Only count physical devices (sda, nvme0n1, etc.)
                if (!device.match(/^(sd[a-z]|nvme\d+n\d+)$/))
                    continue;
                const sectorsRead = parseInt(parts[5]) || 0;
                const sectorsWritten = parseInt(parts[9]) || 0;
                totalRead += sectorsRead;
                totalWrite += sectorsWritten;
            }
            if (this.prevDiskRead !== 0) {
                const readDelta = totalRead - this.prevDiskRead;
                const writeDelta = totalWrite - this.prevDiskWrite;
                // Convert sectors to MB (assuming 512 bytes per sector, over 2 seconds)
                const readMBps = (readDelta * 512) / (2 * 1024 * 1024);
                const writeMBps = (writeDelta * 512) / (2 * 1024 * 1024);
                this.diskReadLabel.set_label(`Read: ${readMBps.toFixed(2)} MB/s`);
                this.diskWriteLabel.set_label(`Write: ${writeMBps.toFixed(2)} MB/s`);
                this.addToHistory(this.diskReadHistory, readMBps);
                this.addToHistory(this.diskWriteHistory, writeMBps);
                this.diskHistoryChart.queue_draw();
            }
            this.prevDiskRead = totalRead;
            this.prevDiskWrite = totalWrite;
        }
        catch (e) {
            console.error('Error updating disk I/O:', e);
        }
    }
    updateNetworkIO() {
        try {
            const [stdout] = this.utils.executeCommand('cat', ['/proc/net/dev']);
            const lines = stdout.split('\n').slice(2);
            let totalRx = 0;
            let totalTx = 0;
            for (const line of lines) {
                if (!line.trim())
                    continue;
                const parts = line.trim().split(/\s+/);
                if (parts.length < 10)
                    continue;
                const iface = parts[0].replace(':', '');
                if (iface === 'lo')
                    continue;
                totalRx += parseInt(parts[1]) || 0;
                totalTx += parseInt(parts[9]) || 0;
            }
            if (this.prevNetworkRx !== 0) {
                const rxDelta = totalRx - this.prevNetworkRx;
                const txDelta = totalTx - this.prevNetworkTx;
                // Convert to MB/s (over 2 seconds)
                const downloadMBps = rxDelta / (2 * 1024 * 1024);
                const uploadMBps = txDelta / (2 * 1024 * 1024);
                this.networkDownloadLabel.set_label(`Download: ${downloadMBps.toFixed(2)} MB/s`);
                this.networkUploadLabel.set_label(`Upload: ${uploadMBps.toFixed(2)} MB/s`);
                this.addToHistory(this.networkDownloadHistory, downloadMBps);
                this.addToHistory(this.networkUploadHistory, uploadMBps);
                this.networkHistoryChart.queue_draw();
            }
            this.prevNetworkRx = totalRx;
            this.prevNetworkTx = totalTx;
        }
        catch (e) {
            console.error('Error updating network I/O:', e);
        }
    }
    updateGPU() {
        try {
            // Try nvidia-smi for NVIDIA GPUs
            const [stdout] = this.utils.executeCommand('nvidia-smi', ['--query-gpu=utilization.gpu', '--format=csv,noheader,nounits']);
            const usage = parseInt(stdout.trim());
            if (!isNaN(usage)) {
                this.gpuLabel.set_label(`Usage: ${usage}%`);
                this.gpuPercent.set_label(`${usage}%`);
                this.gpuProgress.set_fraction(usage / 100);
                this.gpuSection.set_visible(true);
                return;
            }
        }
        catch (e) {
            // nvidia-smi not available
        }
        // Hide GPU section if not available
        this.gpuSection.set_visible(false);
    }
    updateTemperatures() {
        // Clear existing temperature widgets
        let child = this.temperaturesContainer.get_first_child();
        while (child) {
            const next = child.get_next_sibling();
            this.temperaturesContainer.remove(child);
            child = next;
        }
        try {
            const [stdout] = this.utils.executeCommand('sensors', []);
            const lines = stdout.split('\n');
            const temps = [];
            for (const line of lines) {
                if (line.includes('°C') && line.includes(':')) {
                    const match = line.match(/([^:]+):\s*\+?([\d.]+)°C/);
                    if (match) {
                        const label = match[1].trim();
                        const value = match[2];
                        // Filter out irrelevant sensors
                        if (!label.includes('crit') && !label.includes('high') && !label.includes('hyst')) {
                            temps.push({ label, value: `${value}°C` });
                        }
                    }
                }
            }
            for (const temp of temps) {
                const box = new Gtk.Box({
                    orientation: Gtk.Orientation.HORIZONTAL,
                    spacing: 6,
                });
                const nameLabel = new Gtk.Label({
                    label: temp.label,
                    halign: Gtk.Align.START,
                    hexpand: true,
                });
                const valueLabel = new Gtk.Label({
                    label: temp.value,
                    halign: Gtk.Align.END,
                });
                box.append(nameLabel);
                box.append(valueLabel);
                this.temperaturesContainer.append(box);
            }
            if (temps.length === 0) {
                const noDataLabel = new Gtk.Label({
                    label: 'No temperature sensors found',
                    halign: Gtk.Align.START,
                });
                this.temperaturesContainer.append(noDataLabel);
            }
        }
        catch (e) {
            const errorLabel = new Gtk.Label({
                label: 'sensors command not available (install lm-sensors)',
                halign: Gtk.Align.START,
            });
            this.temperaturesContainer.append(errorLabel);
        }
    }
    addToHistory(history, value) {
        history.values.push(value);
        if (history.values.length > history.maxPoints) {
            history.values.shift();
        }
    }
    drawHistory(cr, width, height, history, title, r, g, b) {
        // Background
        cr.setSourceRGBA(0, 0, 0, 0);
        cr.rectangle(0, 0, width, height);
        cr.fill();
        if (history.values.length < 2)
            return;
        const padding = 20;
        const chartWidth = width - 2 * padding;
        const chartHeight = height - 2 * padding;
        // Grid
        cr.setSourceRGBA(0.3, 0.3, 0.3, 0.3);
        cr.setLineWidth(1);
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight / 4) * i;
            cr.moveTo(padding, y);
            cr.lineTo(width - padding, y);
            cr.stroke();
        }
        // Find max value
        const maxValue = Math.max(...history.values, 10);
        // Draw line
        cr.setSourceRGBA(r, g, b, 1);
        cr.setLineWidth(2);
        cr.moveTo(padding, height - padding);
        for (let i = 0; i < history.values.length; i++) {
            const x = padding + (chartWidth / (history.maxPoints - 1)) * i;
            const y = height - padding - (history.values[i] / maxValue) * chartHeight;
            cr.lineTo(x, y);
        }
        cr.stroke();
    }
    drawDualHistory(cr, width, height, history1, history2, title, r1, g1, b1, r2, g2, b2) {
        // Background
        cr.setSourceRGBA(0, 0, 0, 0);
        cr.rectangle(0, 0, width, height);
        cr.fill();
        if (history1.values.length < 2)
            return;
        const padding = 20;
        const chartWidth = width - 2 * padding;
        const chartHeight = height - 2 * padding;
        // Grid
        cr.setSourceRGBA(0.3, 0.3, 0.3, 0.3);
        cr.setLineWidth(1);
        for (let i = 0; i <= 4; i++) {
            const y = padding + (chartHeight / 4) * i;
            cr.moveTo(padding, y);
            cr.lineTo(width - padding, y);
            cr.stroke();
        }
        // Find max value
        const maxValue = Math.max(...history1.values, ...history2.values, 1);
        // Draw first line
        cr.setSourceRGBA(r1, g1, b1, 1);
        cr.setLineWidth(2);
        cr.moveTo(padding, height - padding);
        for (let i = 0; i < history1.values.length; i++) {
            const x = padding + (chartWidth / (history1.maxPoints - 1)) * i;
            const y = height - padding - (history1.values[i] / maxValue) * chartHeight;
            cr.lineTo(x, y);
        }
        cr.stroke();
        // Draw second line
        cr.setSourceRGBA(r2, g2, b2, 1);
        cr.setLineWidth(2);
        cr.moveTo(padding, height - padding);
        for (let i = 0; i < history2.values.length; i++) {
            const x = padding + (chartWidth / (history2.maxPoints - 1)) * i;
            const y = height - padding - (history2.values[i] / maxValue) * chartHeight;
            cr.lineTo(x, y);
        }
        cr.stroke();
    }
    getWidget() {
        return this.container;
    }
    destroy() {
        if (this.updateTimeoutId !== null) {
            GLib.source_remove(this.updateTimeoutId);
            this.updateTimeoutId = null;
        }
    }
}
 ResourcesComponent;
class ProcessesComponent {
    constructor() {
        this.processes = [];
        this.sortColumn = '';
        this.sortAscending = false;
        this.headerButtons = new Map();
        this.utils = UtilsService.instance;
        this.processesService = ProcessesService.instance;
        // Create container
        this.container = new Gtk.Box({
            orientation: Gtk.Orientation.VERTICAL,
            spacing: 6,
        });
        // Header row with sorting buttons
        const headerBox = new Gtk.Box({
            orientation: Gtk.Orientation.HORIZONTAL,
            spacing: 0,
            margin_start: 6,
            margin_end: 6,
            margin_bottom: 3,
        });
        headerBox.add_css_class('toolbar');
        const nameHeader = this.createHeaderButton('Name', 'name');
        nameHeader.set_hexpand(true);
        headerBox.append(nameHeader);
        const pidHeader = this.createHeaderButton('PID', 'pid');
        pidHeader.set_size_request(100, -1);
        headerBox.append(pidHeader);
        const cpuHeader = this.createHeaderButton('CPU', 'cpu');
        cpuHeader.set_size_request(100, -1);
        headerBox.append(cpuHeader);
        const memHeader = this.createHeaderButton('Memory', 'memory');
        memHeader.set_size_request(120, -1);
        headerBox.append(memHeader);
        this.container.append(headerBox);
        // Create list box for processes
        this.listBox = new Gtk.ListBox({
            selection_mode: Gtk.SelectionMode.NONE,
        });
        this.listBox.add_css_class('boxed-list');
        // Scrolled window - vexpand to fill available space
        const scrolled = new Gtk.ScrolledWindow({
            vexpand: true,
            hexpand: true,
        });
        scrolled.set_child(this.listBox);
        this.container.append(scrolled);
        // Bottom panel with totals in a card
        const totalsCard = new Gtk.Frame({
            margin_top: 12,
            vexpand: false,
        });
        totalsCard.add_css_class('view');
        const bottomPanel = new Gtk.Box({
            orientation: Gtk.Orientation.HORIZONTAL,
            spacing: 24,
            margin_start: 12,
            margin_end: 12,
            margin_top: 12,
            margin_bottom: 12,
            halign: Gtk.Align.CENTER,
            vexpand: false,
        });
        const cpuTotalBox = new Gtk.Box({
            orientation: Gtk.Orientation.HORIZONTAL,
            spacing: 6,
        });
        const cpuIcon = new Gtk.Image({
            icon_name: 'drive-harddisk-solidstate-symbolic',
            pixel_size: 16,
        });
        cpuTotalBox.append(cpuIcon);
        this.totalCpuLabel = new Gtk.Label({
            label: 'Total CPU: 0.0%',
        });
        cpuTotalBox.append(this.totalCpuLabel);
        bottomPanel.append(cpuTotalBox);
        const memTotalBox = new Gtk.Box({
            orientation: Gtk.Orientation.HORIZONTAL,
            spacing: 6,
        });
        const memIcon = new Gtk.Image({
            icon_name: 'auth-sim-symbolic',
            pixel_size: 16,
        });
        memTotalBox.append(memIcon);
        this.totalMemoryLabel = new Gtk.Label({
            label: 'Total Memory: 0 MB',
        });
        memTotalBox.append(this.totalMemoryLabel);
        bottomPanel.append(memTotalBox);
        totalsCard.set_child(bottomPanel);
        this.container.append(totalsCard);
        // Subscribe to processes service
        this.dataCallback = this.onDataUpdate.bind(this);
        this.processesService.subscribeToUpdates(this.dataCallback);
        // Set sort preferences
        this.sortColumn = 'cpu';
        this.sortAscending = false;
        this.processesService.setSortColumn('cpu', false);
    }
    createHeaderButton(label, column) {
        const box = new Gtk.Box({
            orientation: Gtk.Orientation.HORIZONTAL,
            spacing: 6,
            halign: Gtk.Align.CENTER,
        });
        const labelWidget = new Gtk.Label({
            label: label,
        });
        box.append(labelWidget);
        const icon = new Gtk.Image({
            icon_name: 'pan-down-symbolic',
            visible: column === this.sortColumn,
        });
        box.append(icon);
        const button = new Gtk.Button();
        button.set_child(box);
        button.add_css_class('flat');
        button.connect('clicked', () => {
            if (this.sortColumn === column) {
                this.sortAscending = !this.sortAscending;
            }
            else {
                this.sortColumn = column;
                this.sortAscending = true;
            }
            this.processesService.setSortColumn(column, this.sortAscending);
            this.updateHeaderIcons();
        });
        this.headerButtons.set(column, button);
        return button;
    }
    updateHeaderIcons() {
        this.headerButtons.forEach((button, column) => {
            const box = button.get_child();
            const icon = box.get_last_child();
            if (column === this.sortColumn) {
                icon.set_visible(true);
                icon.set_from_icon_name(this.sortAscending ? 'pan-up-symbolic' : 'pan-down-symbolic');
            }
            else {
                icon.set_visible(false);
            }
        });
    }
    onDataUpdate(data) {
        this.processes = data.processes;
        this.displayProcesses();
        // Calculate totals from process data
        let totalCpu = 0;
        let totalMemoryKB = 0;
        for (const process of data.processes) {
            totalCpu += parseFloat(process.cpu) || 0;
            totalMemoryKB += parseInt(process.rss) || 0;
        }
        this.totalCpuLabel.set_label(`Total CPU: ${totalCpu.toFixed(1)}%`);
        this.totalMemoryLabel.set_label(`Total Memory: ${this.formatMemory(totalMemoryKB)}`);
    }
    displayProcesses() {
        // Note: Sorting is now handled by the service, no need to sort here
        // Clear current list
        while (this.listBox.get_first_child()) {
            const child = this.listBox.get_first_child();
            if (child) {
                this.listBox.remove(child);
            }
        }
        // Add processes to list
        for (const process of this.processes) {
            const row = this.createProcessRow(process);
            this.listBox.append(row);
        }
    }
    formatMemory(kb) {
        if (kb >= 1024 * 1024) {
            return `${(kb / (1024 * 1024)).toFixed(1)} GB`;
        }
        else if (kb >= 1024) {
            return `${(kb / 1024).toFixed(1)} MB`;
        }
        else {
            return `${kb.toFixed(0)} KB`;
        }
    }
    getIconForProcess(processName) {
        const iconTheme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default());
        // Search in desktop files for matching process
        const desktopDirs = [
            '/usr/share/applications',
            `${GLib.get_home_dir()}/.local/share/applications`
        ];
        for (const dir of desktopDirs) {
            const dirFile = Gio.File.new_for_path(dir);
            if (dirFile.query_exists(null)) {
                try {
                    const enumerator = dirFile.enumerate_children('standard::name', Gio.FileQueryInfoFlags.NONE, null);
                    let fileInfo;
                    while ((fileInfo = enumerator.next_file(null)) !== null) {
                        const fileName = fileInfo.get_name();
                        if (fileName.endsWith('.desktop')) {
                            const desktopFile = dirFile.get_child(fileName);
                            const [success, contents] = desktopFile.load_contents(null);
                            if (success) {
                                const text = new TextDecoder().decode(contents);
                                const lines = text.split('\n');
                                let execLine = '';
                                let iconLine = '';
                                for (const line of lines) {
                                    if (line.startsWith('Exec=')) {
                                        execLine = line.substring(5);
                                    }
                                    else if (line.startsWith('Icon=')) {
                                        iconLine = line.substring(5);
                                    }
                                }
                                // Check if the Exec line contains our process name
                                if (execLine && iconLine) {
                                    const execLower = execLine.toLowerCase();
                                    const processLower = processName.toLowerCase();
                                    // Match if process name appears in the exec path or command
                                    if (execLower.includes(`/${processLower}`) ||
                                        execLower.includes(` ${processLower} `) ||
                                        execLower.startsWith(`${processLower} `)) {
                                        // Verify icon exists in theme
                                        if (iconTheme.has_icon(iconLine)) {
                                            return iconLine;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                catch (e) {
                    // Continue to next directory
                }
            }
        }
        return null;
    }
    createProcessRow(process) {
        const row = new Gtk.ListBoxRow();
        const box = new Gtk.Box({
            orientation: Gtk.Orientation.HORIZONTAL,
            spacing: 0,
            margin_start: 12,
            margin_end: 12,
            margin_top: 6,
            margin_bottom: 6,
        });
        // Try to get icon from desktop files, fallback to generic
        const iconName = this.getIconForProcess(process.command) || 'application-x-executable';
        const icon = new Gtk.Image({
            icon_name: iconName,
            pixel_size: 24,
            margin_end: 8,
        });
        box.append(icon);
        const nameLabel = new Gtk.Label({
            label: process.command,
            halign: Gtk.Align.START,
            hexpand: true,
            ellipsize: Pango.EllipsizeMode.END,
        });
        box.append(nameLabel);
        const pidLabel = new Gtk.Label({
            label: process.pid,
            halign: Gtk.Align.END,
            xalign: 1.0,
        });
        pidLabel.set_size_request(100, -1);
        box.append(pidLabel);
        const cpuLabel = new Gtk.Label({
            label: `${parseFloat(process.cpu).toFixed(1)}%`,
            halign: Gtk.Align.END,
            xalign: 1.0,
        });
        cpuLabel.set_size_request(100, -1);
        box.append(cpuLabel);
        const memLabel = new Gtk.Label({
            label: this.formatMemory(parseInt(process.rss) || 0),
            halign: Gtk.Align.END,
            xalign: 1.0,
        });
        memLabel.set_size_request(120, -1);
        box.append(memLabel);
        row.set_child(box);
        return row;
    }
    getWidget() {
        return this.container;
    }
    destroy() {
        this.processesService.unsubscribe(this.dataCallback);
    }
}
 ProcessesComponent;
class ServicesComponent {
    constructor() {
        this.serviceRows = new Map();
        this.stats = { total: 0, active: 0, inactive: 0, failed: 0 };
        this.utils = UtilsService.instance;
        const builder = Gtk.Builder.new();
        // Load UI file with fallback
        try {
            try {
                builder.add_from_file('/usr/share/com.obision.app.system/ui/services.ui');
            }
            catch (e) {
                builder.add_from_file('data/ui/services.ui');
            }
        }
        catch (e) {
            console.error('Could not load services.ui:', e);
            this.container = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
                spacing: 12,
            });
            return;
        }
        this.container = builder.get_object('services_container');
        this.listBox = builder.get_object('services_list');
        this.searchEntry = builder.get_object('services_search');
        this.totalServicesLabel = builder.get_object('total_services_label');
        this.activeServicesLabel = builder.get_object('active_services_label');
        this.inactiveServicesLabel = builder.get_object('inactive_services_label');
        this.failedServicesLabel = builder.get_object('failed_services_label');
        // Setup search
        this.searchEntry.connect('search-changed', () => {
            this.filterServices();
        });
        // Load services
        this.loadServices();
    }
    loadServices() {
        // Reset statistics
        this.stats = { total: 0, active: 0, inactive: 0, failed: 0 };
        try {
            // Get list of systemd services
            const [stdout] = this.utils.executeCommand('systemctl', [
                'list-units',
                '--type=service',
                '--all',
                '--no-pager',
                '--no-legend'
            ]);
            const lines = stdout.trim().split('\n');
            for (const line of lines) {
                if (!line.trim())
                    continue;
                // Parse systemctl output
                const parts = line.trim().split(/\s+/);
                if (parts.length < 4)
                    continue;
                const serviceName = parts[0];
                const loadState = parts[1];
                const activeState = parts[2];
                const subState = parts[3];
                const description = parts.slice(4).join(' ');
                if (activeState === 'not-found') {
                    continue;
                }
                this.addServiceRow(serviceName, activeState, subState, description);
                // Update statistics
                this.stats.total++;
                if (activeState === 'active') {
                    this.stats.active++;
                }
                else if (activeState === 'failed') {
                    this.stats.failed++;
                }
                else {
                    this.stats.inactive++;
                }
            }
            // Update footer labels
            this.updateFooter();
        }
        catch (e) {
            console.error('Error loading services:', e);
            this.addErrorRow('Could not load system services');
        }
    }
    addServiceRow(name, activeState, subState, description) {
        const row = new Adw.ActionRow({
            title: name,
            subtitle: description || subState,
        });
        // Set icon based on state
        let iconName = 'media-playback-stop-symbolic';
        if (activeState === 'active') {
            iconName = 'emblem-ok-symbolic';
        }
        else if (activeState === 'failed') {
            iconName = 'dialog-error-symbolic';
        }
        const icon = new Gtk.Image({
            icon_name: iconName,
            pixel_size: 16,
        });
        row.add_prefix(icon);
        // Add status badge
        const statusLabel = new Gtk.Label({
            label: activeState.charAt(0).toUpperCase() + activeState.slice(1),
            valign: Gtk.Align.CENTER,
        });
        statusLabel.add_css_class('heading');
        if (activeState === 'active') {
            statusLabel.add_css_class('success');
        }
        else if (activeState === 'failed') {
            statusLabel.add_css_class('error');
        }
        else {
            statusLabel.add_css_class('dim-label');
        }
        row.add_suffix(statusLabel);
        // Add action buttons
        const actionBox = new Gtk.Box({
            orientation: Gtk.Orientation.HORIZONTAL,
            spacing: 6,
            valign: Gtk.Align.CENTER,
        });
        if (activeState === 'active') {
            const stopButton = new Gtk.Button({
                icon_name: 'media-playback-stop-symbolic',
                tooltip_text: 'Stop service',
            });
            stopButton.add_css_class('flat');
            stopButton.connect('clicked', () => {
                this.controlService(name, 'stop');
            });
            actionBox.append(stopButton);
            const restartButton = new Gtk.Button({
                icon_name: 'view-refresh-symbolic',
                tooltip_text: 'Restart service',
            });
            restartButton.add_css_class('flat');
            restartButton.connect('clicked', () => {
                this.controlService(name, 'restart');
            });
            actionBox.append(restartButton);
        }
        else {
            const startButton = new Gtk.Button({
                icon_name: 'media-playback-start-symbolic',
                tooltip_text: 'Start service',
            });
            startButton.add_css_class('flat');
            startButton.connect('clicked', () => {
                this.controlService(name, 'start');
            });
            actionBox.append(startButton);
        }
        row.add_suffix(actionBox);
        this.serviceRows.set(name.toLowerCase(), row);
        this.listBox.append(row);
    }
    addErrorRow(message) {
        const row = new Adw.ActionRow({
            title: 'Error',
            subtitle: message,
        });
        const icon = new Gtk.Image({
            icon_name: 'dialog-error-symbolic',
            pixel_size: 16,
        });
        row.add_prefix(icon);
        this.listBox.append(row);
    }
    controlService(serviceName, action) {
        try {
            // Use pkexec to run systemctl with elevated privileges
            const [stdout, stderr] = this.utils.executeCommand('pkexec', [
                'systemctl',
                action,
                serviceName
            ]);
            // Check if authentication was cancelled
            if (stderr && (stderr.includes('dismissed') || stderr.includes('Error executing command'))) {
                console.log('Service control cancelled: authentication required');
                return;
            }
            console.log(`Service ${serviceName} ${action}ed successfully`);
            // Reload services after a short delay
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 1000, () => {
                this.reloadServices();
                return GLib.SOURCE_REMOVE;
            });
        }
        catch (e) {
            console.error(`Error ${action}ing service ${serviceName}:`, e);
        }
    }
    reloadServices() {
        // Clear existing rows
        let child = this.listBox.get_first_child();
        while (child) {
            const next = child.get_next_sibling();
            this.listBox.remove(child);
            child = next;
        }
        this.serviceRows.clear();
        this.loadServices();
    }
    filterServices() {
        const searchText = this.searchEntry.get_text().toLowerCase();
        if (!searchText) {
            // Show all
            for (const row of this.serviceRows.values()) {
                row.set_visible(true);
            }
            return;
        }
        // Filter based on search text
        for (const [name, row] of this.serviceRows.entries()) {
            const title = (row.get_title() || '').toLowerCase();
            const subtitle = (row.get_subtitle() || '').toLowerCase();
            const matches = title.includes(searchText) || subtitle.includes(searchText);
            row.set_visible(matches);
        }
    }
    updateFooter() {
        this.totalServicesLabel.set_label(this.stats.total.toString());
        this.activeServicesLabel.set_label(this.stats.active.toString());
        this.inactiveServicesLabel.set_label(this.stats.inactive.toString());
        this.failedServicesLabel.set_label(this.stats.failed.toString());
    }
    getWidget() {
        return this.container;
    }
}
 ServicesComponent;
class DriversComponent {
    constructor() {
        this.utils = UtilsService.instance;
        const builder = Gtk.Builder.new();
        try {
            try {
                builder.add_from_file('/usr/share/com.obision.app.system/ui/drivers.ui');
            }
            catch (e) {
                builder.add_from_file('data/ui/drivers.ui');
            }
        }
        catch (e) {
            console.error('Could not load drivers.ui:', e);
            this.container = new Gtk.Box({
                orientation: Gtk.Orientation.VERTICAL,
                spacing: 12,
            });
            return;
        }
        this.container = builder.get_object('drivers_container');
        this.stack = builder.get_object('drivers_stack');
        this.refreshButton = builder.get_object('drivers_refresh_button');
        this.kernelDriversGroup = builder.get_object('kernel_drivers_group');
        this.graphicsDriversGroup = builder.get_object('graphics_drivers_group');
        this.networkDriversGroup = builder.get_object('network_drivers_group');
        this.storageDriversGroup = builder.get_object('storage_drivers_group');
        this.audioDriversGroup = builder.get_object('audio_drivers_group');
        this.usbDriversGroup = builder.get_object('usb_drivers_group');
        // Get refresh button
        this.refreshButton.connect('clicked', () => {
            this.loadDrivers(true);
        });
        // Load drivers on initial load
        GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
            this.stack.set_visible_child_name('loading');
            this.refreshButton.set_sensitive(false);
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, 100, () => {
                this.loadDriversInternal();
                return GLib.SOURCE_REMOVE;
            });
            return GLib.SOURCE_REMOVE;
        });
    }
    loadDrivers(showLoading = false) {
        if (showLoading) {
            // Show loading and disable refresh button
            this.stack.set_visible_child_name('loading');
            this.refreshButton.set_sensitive(false);
        }
        // Use GLib.timeout_add to ensure loading is visible before heavy work
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 100, () => {
            this.loadDriversInternal();
            return GLib.SOURCE_REMOVE;
        });
    }
    loadDriversInternal() {
        // Clear existing rows
        this.clearGroup(this.graphicsDriversGroup);
        this.clearGroup(this.networkDriversGroup);
        this.clearGroup(this.storageDriversGroup);
        this.clearGroup(this.audioDriversGroup);
        this.clearGroup(this.usbDriversGroup);
        this.clearGroup(this.kernelDriversGroup);
        // Load each category with delays
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 200, () => {
            this.loadGraphicsDrivers();
            return GLib.SOURCE_REMOVE;
        });
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 500, () => {
            this.loadNetworkDrivers();
            return GLib.SOURCE_REMOVE;
        });
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 800, () => {
            this.loadStorageDrivers();
            return GLib.SOURCE_REMOVE;
        });
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 1100, () => {
            this.loadAudioDrivers();
            return GLib.SOURCE_REMOVE;
        });
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 1400, () => {
            this.loadUSBDrivers();
            return GLib.SOURCE_REMOVE;
        });
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 1700, () => {
            this.loadKernelModules();
            return GLib.SOURCE_REMOVE;
        });
        // Show content after all loads complete - wait longer
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 2500, () => {
            this.stack.set_visible_child_name('content');
            this.refreshButton.set_sensitive(true);
            return GLib.SOURCE_REMOVE;
        });
    }
    clearGroup(listBox) {
        // Remove all rows from the list box
        listBox.remove_all();
    }
    addDriverRow(listBox, driver) {
        const row = new Adw.ActionRow({
            title: driver.name,
            subtitle: driver.description,
        });
        if (driver.version) {
            const versionLabel = new Gtk.Label({
                label: driver.version,
                css_classes: ['dim-label', 'caption'],
                halign: Gtk.Align.END,
                valign: Gtk.Align.CENTER,
            });
            row.add_suffix(versionLabel);
        }
        if (driver.used) {
            const usedLabel = new Gtk.Label({
                label: `Used: ${driver.used}`,
                css_classes: ['dim-label', 'caption'],
                halign: Gtk.Align.END,
                valign: Gtk.Align.CENTER,
            });
            row.add_suffix(usedLabel);
        }
        listBox.append(row);
    }
    loadGraphicsDrivers() {
        try {
            // Get GPU info from lspci
            const [lspciOut] = this.utils.executeCommand('lspci', ['-k']);
            const lines = lspciOut.split('\n');
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                if (line.includes('VGA') || line.includes('3D') || line.includes('Display')) {
                    const deviceName = line.split(':').slice(2).join(':').trim();
                    let driver = 'Unknown';
                    let version = '';
                    // Look for kernel driver in use
                    for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
                        if (lines[j].includes('Kernel driver in use:')) {
                            driver = lines[j].split(':')[1].trim();
                            // Try to get version
                            try {
                                const [modInfoOut] = this.utils.executeCommand('modinfo', [driver]);
                                const versionLine = modInfoOut.split('\n').find(l => l.includes('version:'));
                                if (versionLine) {
                                    version = versionLine.split(':')[1].trim();
                                }
                            }
                            catch (e) {
                                // Ignore if modinfo fails
                            }
                            break;
                        }
                    }
                    this.addDriverRow(this.graphicsDriversGroup, {
                        name: driver,
                        description: deviceName,
                        version: version || undefined,
                    });
                }
            }
        }
        catch (error) {
            console.error('Error loading graphics drivers:', error);
        }
    }
    loadNetworkDrivers() {
        try {
            const [lspciOut] = this.utils.executeCommand('lspci', ['-k']);
            const lines = lspciOut.split('\n');
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                if (line.includes('Network') || line.includes('Ethernet') || line.includes('Wireless')) {
                    const deviceName = line.split(':').slice(2).join(':').trim();
                    let driver = 'Unknown';
                    let version = '';
                    for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
                        if (lines[j].includes('Kernel driver in use:')) {
                            driver = lines[j].split(':')[1].trim();
                            try {
                                const [modInfoOut] = this.utils.executeCommand('modinfo', [driver]);
                                const versionLine = modInfoOut.split('\n').find(l => l.includes('version:'));
                                if (versionLine) {
                                    version = versionLine.split(':')[1].trim();
                                }
                            }
                            catch (e) {
                                // Ignore
                            }
                            break;
                        }
                    }
                    this.addDriverRow(this.networkDriversGroup, {
                        name: driver,
                        description: deviceName,
                        version: version || undefined,
                    });
                }
            }
        }
        catch (error) {
            console.error('Error loading network drivers:', error);
        }
    }
    loadStorageDrivers() {
        try {
            const [lspciOut] = this.utils.executeCommand('lspci', ['-k']);
            const lines = lspciOut.split('\n');
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                if (line.includes('SATA') || line.includes('RAID') || line.includes('NVMe') ||
                    line.includes('IDE') || line.includes('SCSI') || line.includes('Mass storage')) {
                    const deviceName = line.split(':').slice(2).join(':').trim();
                    let driver = 'Unknown';
                    let version = '';
                    for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
                        if (lines[j].includes('Kernel driver in use:')) {
                            driver = lines[j].split(':')[1].trim();
                            try {
                                const [modInfoOut] = this.utils.executeCommand('modinfo', [driver]);
                                const versionLine = modInfoOut.split('\n').find(l => l.includes('version:'));
                                if (versionLine) {
                                    version = versionLine.split(':')[1].trim();
                                }
                            }
                            catch (e) {
                                // Ignore
                            }
                            break;
                        }
                    }
                    this.addDriverRow(this.storageDriversGroup, {
                        name: driver,
                        description: deviceName,
                        version: version || undefined,
                    });
                }
            }
        }
        catch (error) {
            console.error('Error loading storage drivers:', error);
        }
    }
    loadAudioDrivers() {
        try {
            const [lspciOut] = this.utils.executeCommand('lspci', ['-k']);
            const lines = lspciOut.split('\n');
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                if (line.includes('Audio') || line.includes('Sound') || line.includes('Multimedia')) {
                    const deviceName = line.split(':').slice(2).join(':').trim();
                    let driver = 'Unknown';
                    let version = '';
                    for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
                        if (lines[j].includes('Kernel driver in use:')) {
                            driver = lines[j].split(':')[1].trim();
                            try {
                                const [modInfoOut] = this.utils.executeCommand('modinfo', [driver]);
                                const versionLine = modInfoOut.split('\n').find(l => l.includes('version:'));
                                if (versionLine) {
                                    version = versionLine.split(':')[1].trim();
                                }
                            }
                            catch (e) {
                                // Ignore
                            }
                            break;
                        }
                    }
                    this.addDriverRow(this.audioDriversGroup, {
                        name: driver,
                        description: deviceName,
                        version: version || undefined,
                    });
                }
            }
        }
        catch (error) {
            console.error('Error loading audio drivers:', error);
        }
    }
    loadUSBDrivers() {
        try {
            const [lspciOut] = this.utils.executeCommand('lspci', ['-k']);
            const lines = lspciOut.split('\n');
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                if (line.includes('USB')) {
                    const deviceName = line.split(':').slice(2).join(':').trim();
                    let driver = 'Unknown';
                    let version = '';
                    for (let j = i + 1; j < Math.min(i + 5, lines.length); j++) {
                        if (lines[j].includes('Kernel driver in use:')) {
                            driver = lines[j].split(':')[1].trim();
                            try {
                                const [modInfoOut] = this.utils.executeCommand('modinfo', [driver]);
                                const versionLine = modInfoOut.split('\n').find(l => l.includes('version:'));
                                if (versionLine) {
                                    version = versionLine.split(':')[1].trim();
                                }
                            }
                            catch (e) {
                                // Ignore
                            }
                            break;
                        }
                    }
                    this.addDriverRow(this.usbDriversGroup, {
                        name: driver,
                        description: deviceName,
                        version: version || undefined,
                    });
                }
            }
        }
        catch (error) {
            console.error('Error loading USB drivers:', error);
        }
    }
    loadKernelModules() {
        try {
            // Get top loaded modules by usage
            const [lsmodOut] = this.utils.executeCommand('lsmod', []);
            const lines = lsmodOut.split('\n').slice(1); // Skip header
            // Parse and sort by used count
            const modules = [];
            for (const line of lines) {
                if (!line.trim())
                    continue;
                const parts = line.trim().split(/\s+/);
                if (parts.length >= 3) {
                    modules.push({
                        name: parts[0],
                        size: parts[1],
                        used: parts[2],
                        by: parts.slice(3).join(' '),
                    });
                }
            }
            // Sort by usage (convert to number)
            modules.sort((a, b) => parseInt(b.used) - parseInt(a.used));
            // Show top 10 most used modules
            for (let i = 0; i < Math.min(10, modules.length); i++) {
                const module = modules[i];
                let version = '';
                let description = '';
                let author = '';
                let license = '';
                let filename = '';
                try {
                    const [modInfoOut] = this.utils.executeCommand('/usr/sbin/modinfo', [module.name]);
                    const infoLines = modInfoOut.split('\n');
                    for (const line of infoLines) {
                        if (line.startsWith('version:')) {
                            version = line.substring('version:'.length).trim();
                        }
                        else if (line.startsWith('description:')) {
                            description = line.substring('description:'.length).trim();
                        }
                        else if (line.startsWith('author:')) {
                            author = line.substring('author:'.length).trim();
                        }
                        else if (line.startsWith('license:')) {
                            license = line.substring('license:'.length).trim();
                        }
                        else if (line.startsWith('filename:')) {
                            filename = line.substring('filename:'.length).trim();
                        }
                    }
                }
                catch (e) {
                    // Ignore
                }
                this.addKernelModuleRow(this.kernelDriversGroup, {
                    name: module.name,
                    size: module.size,
                    used: module.used,
                    usedBy: module.by,
                    version: version,
                    description: description,
                    author: author,
                    license: license,
                    filename: filename,
                });
            }
        }
        catch (error) {
            console.error('Error loading kernel modules:', error);
        }
    }
    addKernelModuleRow(listBox, module) {
        const expanderRow = new Adw.ExpanderRow({
            title: module.name,
            subtitle: '',
        });
        // Asignar el subtítulo solo con texto plano
        expanderRow.set_subtitle(module.description || 'Kernel module');
        // Add version suffix if available
        if (module.version) {
            const versionLabel = new Gtk.Label({
                label: module.version,
                css_classes: ['dim-label', 'caption'],
                halign: Gtk.Align.END,
                valign: Gtk.Align.CENTER,
            });
            expanderRow.add_suffix(versionLabel);
        }
        // Add detailed information rows
        const usedRow = new Adw.ActionRow({
            title: 'Used',
            subtitle: '',
        });
        usedRow.set_subtitle(module.used);
        expanderRow.add_row(usedRow);
        if (module.usedBy) {
            const usedByRow = new Adw.ActionRow({
                title: 'Used by',
                subtitle: '',
            });
            usedByRow.set_subtitle(module.usedBy);
            expanderRow.add_row(usedByRow);
        }
        const sizeBytes = parseInt(module.size);
        const formattedSize = this.utils.formatBytes(sizeBytes);
        const sizeRow = new Adw.ActionRow({
            title: 'Size',
            subtitle: '',
        });
        sizeRow.set_subtitle(formattedSize);
        expanderRow.add_row(sizeRow);
        if (module.author) {
            // Mostrar el autor tal cual, permitiendo arroba y evitando markup
            const authorRow = new Adw.ActionRow({
                title: 'Author',
                subtitle: '',
            });
            authorRow.set_subtitle(module.author);
            expanderRow.add_row(authorRow);
        }
        if (module.license) {
            const licenseRow = new Adw.ActionRow({
                title: 'License',
                subtitle: '',
            });
            licenseRow.set_subtitle(module.license);
            expanderRow.add_row(licenseRow);
        }
        if (module.filename) {
            const filenameRow = new Adw.ActionRow({
                title: 'Filename',
                subtitle: '',
            });
            filenameRow.set_subtitle(module.filename);
            expanderRow.add_row(filenameRow);
        }
        listBox.append(expanderRow);
    }
    getWidget() {
        return this.container;
    }
}
 DriversComponent;
class UserLogsComponent {
    constructor() {
        this.utils = UtilsService.instance;
        this.logsService = LogsService.instance;
        this.container = new Gtk.Box({
            orientation: Gtk.Orientation.VERTICAL,
            spacing: 0,
        });
        this.setupUI();
        this.setupEventHandlers();
        // Subscribe to logs service
        this.dataCallback = this.onDataUpdate.bind(this);
        this.logsService.subscribeToUpdates(this.dataCallback);
    }
    setupUI() {
        // Filter controls
        this.filterBox = new Gtk.Box({
            orientation: Gtk.Orientation.HORIZONTAL,
            spacing: 12,
            margin_start: 12,
            margin_end: 12,
            margin_top: 12,
            margin_bottom: 12,
        });
        this.filterBox.append(new Gtk.Label({ label: 'Filter:' }));
        this.logFilterDropdown = new Gtk.DropDown();
        const filterModel = Gtk.StringList.new([
            'All Logs', 'User Services', 'Desktop Session', 'Applications', 'Shell'
        ]);
        this.logFilterDropdown.set_model(filterModel);
        this.logFilterDropdown.set_selected(0);
        this.filterBox.append(this.logFilterDropdown);
        this.filterBox.append(new Gtk.Label({ label: 'Priority:' }));
        this.priorityDropdown = new Gtk.DropDown();
        const priorityModel = Gtk.StringList.new([
            'All Priorities', 'Emergency', 'Alert', 'Critical',
            'Error', 'Warning', 'Notice', 'Info', 'Debug'
        ]);
        this.priorityDropdown.set_model(priorityModel);
        this.priorityDropdown.set_selected(0);
        this.filterBox.append(this.priorityDropdown);
        this.filterBox.append(new Gtk.Label({ label: 'Lines:' }));
        const linesAdjustment = new Gtk.Adjustment({
            lower: 50, upper: 1000, step_increment: 50,
            page_increment: 100, value: 200,
        });
        this.linesSpinner = new Gtk.SpinButton({ adjustment: linesAdjustment });
        this.filterBox.append(this.linesSpinner);
        this.container.append(this.filterBox);
        // Logs display
        const scrolledWindow = new Gtk.ScrolledWindow({
            vexpand: true,
            hexpand: true,
        });
        this.logsTextView = new Gtk.TextView({
            editable: false,
            monospace: true,
            wrap_mode: Gtk.WrapMode.WORD_CHAR,
            margin_start: 12,
            margin_end: 12,
            margin_top: 12,
            margin_bottom: 12,
        });
        this.logsBuffer = this.logsTextView.get_buffer();
        scrolledWindow.set_child(this.logsTextView);
        this.container.append(scrolledWindow);
    }
    onDataUpdate(data) {
        this.logsBuffer.set_text(data.userLogs, -1);
    }
    setupEventHandlers() {
        // Filter change handlers
        this.logFilterDropdown.connect('notify::selected', () => {
            this.updateLogsWithFilters();
        });
        this.priorityDropdown.connect('notify::selected', () => {
            this.updateLogsWithFilters();
        });
        this.linesSpinner.connect('value-changed', () => {
            this.updateLogsWithFilters();
        });
    }
    updateLogsWithFilters() {
        const selectedFilter = this.logFilterDropdown.get_selected();
        const selectedPriority = this.priorityDropdown.get_selected();
        const numLines = this.linesSpinner.get_value_as_int();
        this.logsService.setUserLogFilter(selectedFilter, selectedPriority, numLines);
    }
    getWidget() {
        return this.container;
    }
    destroy() {
        this.logsService.unsubscribe(this.dataCallback);
    }
}
 UserLogsComponent;
class ObisionStatusApplication {
    constructor() {
        // Create the application
        this.application = new Adw.Application({
            application_id: 'com.obision.app.system',
            flags: Gio.ApplicationFlags.DEFAULT_FLAGS,
        });
        // Connect signals
        this.application.connect('activate', this.onActivate.bind(this));
        this.application.connect('startup', this.onStartup.bind(this));
    }
    onStartup() {
        console.log('Application starting up...');
        // Add application actions for menu
        const aboutAction = new Gio.SimpleAction({ name: 'about' });
        aboutAction.connect('activate', () => {
            const windows = this.application.get_windows();
            if (windows.length > 0) {
                this.showAboutDialog(windows[0]);
            }
        });
        this.application.add_action(aboutAction);
        const preferencesAction = new Gio.SimpleAction({ name: 'preferences' });
        preferencesAction.connect('activate', () => {
            const windows = this.application.get_windows();
            if (windows.length > 0) {
                this.showPreferencesDialog(windows[0]);
            }
        });
        this.application.add_action(preferencesAction);
        const quitAction = new Gio.SimpleAction({ name: 'quit' });
        quitAction.connect('activate', () => {
            this.application.quit();
        });
        this.application.add_action(quitAction);
        // Set keyboard shortcuts
        this.application.set_accels_for_action('app.quit', ['<Ctrl>Q']);
        // Set resource path
        // this.application.set_resource_base_path('/data');
    }
    onActivate() {
        console.log('Application activated');
        // Load CSS
        const cssProvider = new Gtk.CssProvider();
        const installedPath = '/usr/share/com.obision.app.system/style.css';
        const devPath = 'data/style.css';
        // Check if installed version exists
        const installedFile = Gio.File.new_for_path(installedPath);
        if (installedFile.query_exists(null)) {
            cssProvider.load_from_path(installedPath);
        }
        else {
            cssProvider.load_from_path(devPath);
        }
        const display = Gdk.Display.get_default();
        if (display) {
            Gtk.StyleContext.add_provider_for_display(display, cssProvider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION);
        }
        // Create and show the main window
        const window = this.createMainWindow();
        console.log('Window created, presenting...');
        window.present();
    }
    createMainWindow() {
        // Load UI from resource
        const builder = Gtk.Builder.new();
        // Fallback: load from file
        try {
            // Try installed path first
            try {
                builder.add_from_file('/usr/share/com.obision.app.system/ui/main.ui');
            }
            catch (e) {
                builder.add_from_file('data/ui/main.ui');
            }
            console.log('Loaded UI from file');
        }
        catch (e2) {
            console.error('Could not load UI file:', e2);
            console.log('Using fallback UI');
            this.application.quit();
        }
        const window = builder.get_object('application_window');
        window.set_application(this.application);
        // Load window state from settings
        const settings = SettingsService.instance;
        const width = settings.getWindowWidth();
        const height = settings.getWindowHeight();
        const x = settings.getWindowX();
        const y = settings.getWindowY();
        const maximized = settings.getWindowMaximized();
        window.set_default_size(width, height);
        if (maximized) {
            window.maximize();
        }
        // Save window state on close
        window.connect('close-request', () => {
            const [currentWidth, currentHeight] = window.get_default_size();
            settings.setWindowWidth(currentWidth);
            settings.setWindowHeight(currentHeight);
            settings.setWindowMaximized(window.is_maximized());
            return false;
        });
        console.log('Setting up UI with loaded content');
        // Get UI elements
        const mainContent = builder.get_object('main_content');
        const contentTitle = builder.get_object('content_title');
        // Get navigation buttons
        const menuButton0 = builder.get_object('menu_option_0');
        const menuButton1 = builder.get_object('menu_option_1');
        const menuButton2 = builder.get_object('menu_option_2');
        const menuButton3 = builder.get_object('menu_option_3');
        const menuButton4 = builder.get_object('menu_option_4');
        const menuButton5 = builder.get_object('menu_option_5');
        const menuButton6 = builder.get_object('menu_option_6');
        const menuButton7 = builder.get_object('menu_option_7');
        const menuButton8 = builder.get_object('menu_option_8');
        const menuButton9 = builder.get_object('menu_option_9');
        const menuButton10 = builder.get_object('menu_option_10');
        const menuButton11 = builder.get_object('menu_option_11');
        // Detect if battery exists and hide button if not
        const dataService = DataService.instance;
        const hasBattery = dataService.hasBattery();
        if (!hasBattery) {
            menuButton6.set_visible(false);
        }
        // Store all menu buttons for selection management
        const allMenuButtons = hasBattery
            ? [menuButton0, menuButton1, menuButton2, menuButton3, menuButton4, menuButton5, menuButton6, menuButton7, menuButton8, menuButton9, menuButton10, menuButton11]
            : [menuButton0, menuButton1, menuButton2, menuButton3, menuButton4, menuButton5, menuButton8, menuButton9, menuButton10, menuButton11];
        // Setup navigation
        menuButton0.connect('clicked', () => {
            this.onNavigationItemSelected(0, mainContent, menuButton0, allMenuButtons, contentTitle);
        });
        menuButton1.connect('clicked', () => {
            this.onNavigationItemSelected(1, mainContent, menuButton1, allMenuButtons, contentTitle);
        });
        menuButton2.connect('clicked', () => {
            this.onNavigationItemSelected(2, mainContent, menuButton2, allMenuButtons, contentTitle);
        });
        menuButton3.connect('clicked', () => {
            this.onNavigationItemSelected(3, mainContent, menuButton3, allMenuButtons, contentTitle);
        });
        menuButton4.connect('clicked', () => {
            this.onNavigationItemSelected(4, mainContent, menuButton4, allMenuButtons, contentTitle);
        });
        menuButton5.connect('clicked', () => {
            this.onNavigationItemSelected(5, mainContent, menuButton5, allMenuButtons, contentTitle);
        });
        if (hasBattery) {
            menuButton6.connect('clicked', () => {
                this.onNavigationItemSelected(6, mainContent, menuButton6, allMenuButtons, contentTitle);
            });
        }
        menuButton7.connect('clicked', () => {
            this.onNavigationItemSelected(8, mainContent, menuButton7, allMenuButtons, contentTitle);
        });
        menuButton8.connect('clicked', () => {
            this.onNavigationItemSelected(7, mainContent, menuButton8, allMenuButtons, contentTitle);
        });
        menuButton9.connect('clicked', () => {
            this.onNavigationItemSelected(9, mainContent, menuButton9, allMenuButtons, contentTitle);
        });
        menuButton10.connect('clicked', () => {
            this.onNavigationItemSelected(10, mainContent, menuButton10, allMenuButtons, contentTitle);
        });
        menuButton11.connect('clicked', () => {
            this.onNavigationItemSelected(11, mainContent, menuButton11, allMenuButtons, contentTitle);
        });
        // Restore last selected menu (settings already defined above)
        const lastSelectedMenu = settings.getLastSelectedMenu();
        // Map of button indices to buttons and their actual view index
        const menuMapping = [
            { button: menuButton0, viewIndex: 0 },
            { button: menuButton1, viewIndex: 1 },
            { button: menuButton2, viewIndex: 2 },
            { button: menuButton3, viewIndex: 3 },
            { button: menuButton4, viewIndex: 4 },
            { button: menuButton5, viewIndex: 5 },
            { button: menuButton6, viewIndex: 6 },
            { button: menuButton7, viewIndex: 8 }, // System Info
            { button: menuButton8, viewIndex: 7 }, // Processes
            { button: menuButton9, viewIndex: 9 },
            { button: menuButton10, viewIndex: 10 },
            { button: menuButton11, viewIndex: 11 }, // User Logs
        ];
        // Find the menu item that matches the saved index
        const selectedMenu = menuMapping.find(m => m.viewIndex === lastSelectedMenu) || menuMapping[0];
        this.onNavigationItemSelected(selectedMenu.viewIndex, mainContent, selectedMenu.button, allMenuButtons, contentTitle);
        return window;
    }
    onNavigationItemSelected(index, contentBox, selectedButton, allButtons, titleLabel) {
        // Save selected menu index
        SettingsService.instance.setLastSelectedMenu(index);
        // Update button toggle state
        allButtons.forEach(button => {
            button.set_active(false);
        });
        selectedButton.set_active(true);
        // Get the label text from the button and set it as title
        const buttonChild = selectedButton.get_child();
        if (buttonChild) {
            let labelWidget = buttonChild.get_first_child();
            while (labelWidget) {
                if (labelWidget instanceof Gtk.Label) {
                    titleLabel.set_label(labelWidget.get_label() || '');
                    break;
                }
                labelWidget = labelWidget.get_next_sibling();
            }
        }
        // Clear current content
        let child = contentBox.get_first_child();
        while (child) {
            const next = child.get_next_sibling();
            contentBox.remove(child);
            child = next;
        }
        // Add content based on selection
        switch (index) {
            case 0: // Resume
                this.showResume(contentBox);
                break;
            case 1: // CPU
                this.showCpu(contentBox);
                break;
            case 2: // GPU
                this.showGpu(contentBox);
                break;
            case 3: // Memory
                this.showMemory(contentBox);
                break;
            case 4: // Disk
                this.showDisk(contentBox);
                break;
            case 5: // Network
                this.showNetwork(contentBox);
                break;
            case 6: // Battery
                this.showBattery(contentBox);
                break;
            case 7: // System Info
                this.showSystemInfo(contentBox);
                break;
            case 8: // Processes
                this.showProcesses(contentBox);
                break;
            case 9: // Services
                this.showServices(contentBox);
                break;
            case 10: // Drivers
                this.showDrivers(contentBox);
                break;
            case 11: // Logs
                this.showLogs(contentBox);
                break;
        }
    }
    showResume(contentBox) {
        const component = new ResumeComponent();
        contentBox.append(component.getWidget());
    }
    showCpu(contentBox) {
        const component = new CpuComponent();
        contentBox.append(component.getWidget());
    }
    showGpu(contentBox) {
        const component = new GpuComponent();
        contentBox.append(component.getWidget());
    }
    showMemory(contentBox) {
        const memoryComponent = new MemoryComponent();
        contentBox.append(memoryComponent.getWidget());
    }
    showDisk(contentBox) {
        const diskComponent = new DiskComponent();
        contentBox.append(diskComponent.getWidget());
    }
    showNetwork(contentBox) {
        const component = new NetworkComponent();
        contentBox.append(component.getWidget());
    }
    showSystemInfo(contentBox) {
        const component = new SystemInfoComponent();
        contentBox.append(component.getWidget());
    }
    showBattery(contentBox) {
        const component = new BatteryComponent();
        contentBox.append(component.getWidget());
    }
    showProcesses(contentBox) {
        const component = new ProcessesComponent();
        contentBox.append(component.getWidget());
    }
    showServices(contentBox) {
        const component = new ServicesComponent();
        contentBox.append(component.getWidget());
    }
    showDrivers(contentBox) {
        const component = new DriversComponent();
        contentBox.append(component.getWidget());
    }
    showLogs(contentBox) {
        const component = new UserLogsComponent();
        contentBox.append(component.getWidget());
    }
    showAboutDialog(parent) {
        const aboutDialog = new Adw.AboutWindow({
            transient_for: parent,
            modal: true,
            application_name: 'Obision System',
            application_icon: 'com.obision.app.system',
            developer_name: 'Jose Francisco Gonzalez',
            version: '0.0.0',
            developers: ['Jose Francisco Gonzalez <jfgs1609@gmail.com>'],
            copyright: `© ${new Date().getFullYear()} Jose Francisco Gonzalez`,
            license_type: Gtk.License.GPL_3_0,
            website: 'https://obision.com',
            issue_url: 'https://github.com/nirlob/obision-app-system/issues',
        });
        aboutDialog.present();
    }
    showPreferencesDialog(parent) {
        const builder = Gtk.Builder.new();
        try {
            try {
                builder.add_from_file('/usr/share/com.obision.app.system/ui/preferences.ui');
            }
            catch (e) {
                builder.add_from_file('data/ui/preferences.ui');
            }
        }
        catch (e) {
            console.error('Could not load preferences.ui:', e);
            return;
        }
        const prefsWindow = builder.get_object('preferences_window');
        const refreshIntervalSpin = builder.get_object('refresh_interval_spin');
        prefsWindow.set_transient_for(parent);
        // Load current settings
        const settings = SettingsService.instance;
        refreshIntervalSpin.set_value(settings.getRefreshInterval());
        // Save settings when changed
        refreshIntervalSpin.connect('value-changed', () => {
            const value = refreshIntervalSpin.get_value();
            settings.setRefreshInterval(value);
            console.log(`Refresh interval changed to ${value} seconds`);
        });
        prefsWindow.present();
    }
    run(argv) {
        return this.application.run(argv);
    }
}
// Main function
function main(argv) {
    const app = new ObisionStatusApplication();
    return app.run(argv);
}
// Run the application
if (typeof ARGV !== 'undefined') {
    main(ARGV);
}
else {
    main([]);
}
